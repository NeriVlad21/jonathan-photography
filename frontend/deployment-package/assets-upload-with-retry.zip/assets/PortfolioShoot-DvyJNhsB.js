import{f as A,r as n,p as j,j as e,L as f,e as N,a as S}from"./index-DwFWKgCp.js";import{E as w}from"./EditorialImage-CCBEUEAp.js";import{f as v}from"./format-_QWv5Va2.js";function T(){const{category:s,shoot:p}=A(),[i,d]=n.useState(null),[g,x]=n.useState(!1),[a,r]=n.useState(null);n.useEffect(()=>{d(null),x(!1),j.shoot(s,p).then(t=>{d(t),document.title=`Jonathan Photography — ${t.title}`}).catch(()=>x(!0))},[s,p]);const h=n.useRef(null),m=n.useRef(null);if(n.useEffect(()=>{var t,o,l;if(a){(t=m.current)==null||t.focus();return}(l=(o=h.current)==null?void 0:o.focus)==null||l.call(o)},[a]),n.useEffect(()=>{const t=o=>{o.key==="Escape"&&r(null)};return window.addEventListener("keydown",t),()=>window.removeEventListener("keydown",t)},[]),g)return e.jsx("section",{className:"section",style:{paddingTop:160,textAlign:"center"},children:e.jsxs("div",{className:"container",children:[e.jsx("h1",{className:"display",style:{fontSize:"2rem"},children:"Story not found."}),e.jsx(f,{to:"/portfolio",className:"text-link",style:{marginTop:20,display:"inline-flex"},children:"← Back to Portfolio"})]})});if(!i)return e.jsx(N,{label:"Loading the exhibition…"});const c=i.images||[],u=c.length;return e.jsxs("article",{style:{paddingBottom:0,backgroundColor:"#FAFAFA"},children:[e.jsx("style",{children:`
        .exhibition-header {
          padding: clamp(120px, 16vw, 180px) 0 80px 0;
          border-bottom: 1px solid #E5E5E5;
          margin-bottom: 80px;
        }

        .exhibition-container {
          display: flex;
          flex-direction: column;
          gap: 15vh; /* Massive breathing room between photos */
          padding: 0 5%;
          max-width: 1400px;
          margin: 0 auto;
        }

        .exhibition-item {
          display: flex;
          flex-direction: column;
          position: relative;
          width: 100%;
          max-width: 900px;
        }

        /* Artistic staggered alignment */
        .exhibition-item:nth-child(3n+1) { align-self: flex-start; }
        .exhibition-item:nth-child(3n+2) { align-self: flex-end; }
        .exhibition-item:nth-child(3n) { align-self: center; max-width: 1100px; }

        .exhibition-counter {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 16px;
          color: #999;
          font-family: monospace;
          font-size: 0.85rem;
          letter-spacing: 2px;
        }

        .exhibition-counter::after {
          content: '';
          display: block;
          width: 40px;
          height: 1px;
          background-color: #D1D1D1;
        }

        .exhibition-image-wrapper {
          display: block;
          width: 100%;
          padding: 0;
          border: 0;
          background: none;
          font: inherit;
          text-align: inherit;
          position: relative;
          cursor: zoom-in;
          overflow: hidden;
          background-color: #F0F0F0;
        }

        .exhibition-image-wrapper img {
          width: 100%;
          display: block;
          object-fit: cover;
          transition: transform 1.2s cubic-bezier(0.25, 0.46, 0.45, 0.94), filter 0.5s ease;
        }

        .exhibition-image-wrapper:hover img {
          transform: scale(1.02);
          filter: brightness(0.95);
        }
        
        .exhibition-caption {
          margin-top: 16px;
          font-size: 0.9rem;
          color: #666;
          font-weight: 300;
          letter-spacing: 0.5px;
        }

        /* Justin Le Style Marquee */
        .marquee-wrapper {
          overflow: hidden;
          white-space: nowrap;
          border-top: 1px solid #E5E5E5;
          border-bottom: 1px solid #E5E5E5;
          padding: 24px 0;
          margin-top: 15vh;
          background: #fff;
        }

        .marquee-content {
          display: inline-block;
          animation: marquee 25s linear infinite;
          font-family: var(--font-body);
          font-size: 1.5rem;
          color: #000;
          text-transform: uppercase;
          letter-spacing: 4px;
        }

        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }

        /* Lightbox (Unchanged - Keeps the 100MB viewing experience intact) */
        .lightbox-overlay {
          position: fixed; inset: 0; z-index: 9999;
          background: rgba(250, 250, 250, 0.98);
          backdrop-filter: blur(10px);
          display: flex; align-items: center; justify-content: center;
          padding: 40px; cursor: zoom-out;
        }
        .lightbox-image {
          max-width: 100%; max-height: 90vh;
          object-fit: contain; box-shadow: 0 30px 80px rgba(0,0,0,0.1);
          cursor: default;
        }
        .lightbox-close {
          position: absolute; top: 30px; right: 40px;
          background: none; border: none; font-size: 12px;
          font-weight: 600; text-transform: uppercase; letter-spacing: 2px;
          cursor: pointer; color: #000;
        }
      `}),e.jsx("header",{className:"exhibition-header",children:e.jsxs("div",{className:"container",style:{display:"flex",flexDirection:"column",gap:"8px"},children:[e.jsxs(f,{to:`/portfolio/${s}`,className:"text-link",style:{fontSize:"0.75rem",textTransform:"uppercase",letterSpacing:"4px",color:"#999",marginBottom:"20px"},children:["← ",i.category_name]}),e.jsx("h1",{className:"display",style:{fontSize:"clamp(2.5rem, 5vw, 4.5rem)",margin:0,fontWeight:400,letterSpacing:"-1px"},children:i.title}),e.jsxs("div",{style:{display:"flex",gap:40,flexWrap:"wrap",marginTop:"32px"},children:[i.shoot_date&&e.jsxs("div",{style:{display:"flex",flexDirection:"column"},children:[e.jsx("span",{style:{fontSize:"0.65rem",textTransform:"uppercase",letterSpacing:"2px",color:"#999"},children:"Date"}),e.jsx("span",{style:{fontSize:"0.9rem",color:"#000",marginTop:"4px"},children:v(i.shoot_date)})]}),i.location&&e.jsxs("div",{style:{display:"flex",flexDirection:"column"},children:[e.jsx("span",{style:{fontSize:"0.65rem",textTransform:"uppercase",letterSpacing:"2px",color:"#999"},children:"Location"}),e.jsx("span",{style:{fontSize:"0.9rem",color:"#000",marginTop:"4px"},children:i.location})]})]}),i.description&&e.jsx("p",{style:{maxWidth:"600px",marginTop:48,fontSize:"1.05rem",color:"#555",lineHeight:1.8,fontWeight:300},children:i.description})]})}),e.jsx("div",{className:"exhibition-container",children:c.length===0?e.jsx("p",{style:{textAlign:"center",color:"#999",fontStyle:"italic"},children:"Archive empty."}):c.map((t,o)=>{const l=String(o+1).padStart(2,"0"),b=String(u).padStart(2,"0");return e.jsxs("div",{className:"exhibition-item",children:[e.jsxs("div",{className:"exhibition-counter",children:[l," / ",b]}),e.jsx("button",{type:"button",className:"exhibition-image-wrapper",onClick:y=>{h.current=y.currentTarget,r(t)},"aria-label":`View ${t.title||i.title} full screen`,children:e.jsx(w,{src:t.image_path,alt:t.title||i.title})}),(t.title||t.caption)&&e.jsxs("div",{className:"exhibition-caption",children:[t.title&&e.jsx("strong",{style:{color:"#000",marginRight:"10px"},children:t.title}),t.caption]})]},t.id)})}),e.jsx("div",{className:"marquee-wrapper","aria-hidden":"true",children:e.jsx("div",{className:"marquee-content",children:"BOOK A SESSION AT JONATHAN PHOTOGRAPHY • INQUIRE FOR AVAILABILITY • BOOK A SESSION AT JONATHAN PHOTOGRAPHY • INQUIRE FOR AVAILABILITY • BOOK A SESSION AT JONATHAN PHOTOGRAPHY • INQUIRE FOR AVAILABILITY • BOOK A SESSION AT JONATHAN PHOTOGRAPHY • INQUIRE FOR AVAILABILITY •"})}),a&&e.jsxs("div",{className:"lightbox-overlay",role:"dialog","aria-modal":"true","aria-label":a.title||i.title,onClick:()=>r(null),children:[e.jsx("button",{type:"button",className:"lightbox-close",ref:m,onClick:()=>r(null),children:"Close [ESC]"}),e.jsx("img",{src:S(a.image_path),alt:a.title||i.title,className:"lightbox-image",onClick:t=>t.stopPropagation()})]})]})}export{T as default};
