const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/html2pdf-X78KZjKX.js","assets/index-ZwdCBnk2.js","assets/index-D7-cqVfO.css","assets/html2canvas-GsVsA2Tp.js"])))=>i.map(i=>d[i]);
import{i as S,b as Z,h as ee,l as U,r as n,j as e,e as W,k as q,_ as H,X as te,m as B,A as ae}from"./index-ZwdCBnk2.js";import{p as R,a as Y}from"./format-C7C3p2s4.js";import{E as V}from"./EmptyState-CwOvTTML.js";import{n as se}from"./adminDataSync-qIaoXYq1.js";import{S as ie}from"./search-DJYhVgX9.js";import{D as X}from"./download-BbMOI5pm.js";import{C as P}from"./circle-check-T0Tpa8A1.js";import{C as oe}from"./clock-3-BRzT-qJM.js";import{C as re}from"./chevron-right-Cj6ZrVvO.js";import{C as ne}from"./chevron-down-B3QNSg4X.js";import{S as M}from"./shield-check-BM8gRDKt.js";import{C as le}from"./calendar-check-Bik4zY78.js";/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const I=S("CircleX",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"m9 9 6 6",key:"z0biqf"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const de=S("Filter",[["polygon",{points:"22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3",key:"1yg77f"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ce=S("ReceiptText",[["path",{d:"M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z",key:"q3az6g"}],["path",{d:"M14 8H8",key:"1l3xfs"}],["path",{d:"M16 12H8",key:"1fr5h0"}],["path",{d:"M13 16H8",key:"wsln4y"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pe=S("SlidersHorizontal",[["line",{x1:"21",x2:"14",y1:"4",y2:"4",key:"obuewd"}],["line",{x1:"10",x2:"3",y1:"4",y2:"4",key:"1q6298"}],["line",{x1:"21",x2:"12",y1:"12",y2:"12",key:"1iu8h1"}],["line",{x1:"8",x2:"3",y1:"12",y2:"12",key:"ntss68"}],["line",{x1:"21",x2:"16",y1:"20",y2:"20",key:"14d8ph"}],["line",{x1:"12",x2:"3",y1:"20",y2:"20",key:"m0wm8r"}],["line",{x1:"14",x2:"14",y1:"2",y2:"6",key:"14e1ph"}],["line",{x1:"8",x2:"8",y1:"10",y2:"14",key:"1i6ji0"}],["line",{x1:"16",x2:"16",y1:"18",y2:"22",key:"1lctlv"}]]),me=["NEW","PENDING","CONFIRMED","COMPLETED","CANCELLED"],z={NEW:[{status:"PENDING",label:"Pending",icon:oe},{status:"CONFIRMED",label:"Confirm",icon:P},{status:"CANCELLED",label:"Cancel",icon:I}],PENDING:[{status:"CONFIRMED",label:"Confirm",icon:P},{status:"CANCELLED",label:"Cancel",icon:I}],CONFIRMED:[{status:"COMPLETED",label:"Complete",icon:P},{status:"CANCELLED",label:"Cancel",icon:I}]},G=[{value:"today",label:"Today"},{value:"last_week",label:"Last Week"},{value:"last_month",label:"Last Month"},{value:"last_3_months",label:"Last 3 Months"},{value:"last_quarter",label:"Last Quarter"},{value:"last_year",label:"Last Year"},{value:"all",label:"All Time / Archive"}];function he({readOnly:o=!1,detailBase:f="/admin/bookings"}){var F,O;const p=Z(),b=ee(),{showToast:u}=U(),[d,x]=n.useState(null),_=n.useRef(((F=p.state)==null?void 0:F.scrollY)??null);n.useEffect(()=>{if(!d||_.current===null)return;const t=Number(_.current)||0;_.current=null,window.requestAnimationFrame(()=>window.scrollTo({top:t,behavior:"auto"}))},[d]);const[s,k]=n.useState(()=>{var t,i;return((i=(t=p.state)==null?void 0:t.bookingFilters)==null?void 0:i.status)||""}),[y,A]=n.useState(()=>{var t,i;return((i=(t=p.state)==null?void 0:t.bookingFilters)==null?void 0:i.search)||""}),[g,L]=n.useState(()=>{var t,i;return((i=(t=p.state)==null?void 0:t.bookingFilters)==null?void 0:i.timeframe)||"today"}),[j,D]=n.useState(()=>{var t,i;return!!((i=(t=p.state)==null?void 0:t.bookingFilters)!=null&&i.priorityOnly)}),[C,E]=n.useState(!1),[a,l]=n.useState(null),[m,h]=n.useState(0),w=()=>{x(null);const t={};s&&(t.status=s),y.trim()&&(t.search=y.trim()),g&&g!=="all"&&(t.timeframe=g),q.list(t).then(i=>{let r=Array.isArray(i)?i:[];h(r.filter(c=>["NEW","PENDING"].includes(c.status)).length),j&&(r=r.filter(c=>["NEW","PENDING"].includes(c.status))),x(r)}).catch(()=>{x([])})};n.useEffect(()=>{document.title="Admin — Bookings"},[]),n.useEffect(()=>{const t=setTimeout(w,250);return()=>clearTimeout(t)},[s,y,g,j]);const T=async(t,i,r)=>{if(t.stopPropagation(),!(["CANCELLED","COMPLETED"].includes(r)&&!window.confirm(`Mark this booking as ${r.toLowerCase()}?`))){l(i.id);try{const c=await q.updateStatus(i.id,r,!0);x(v=>v.flatMap(N=>N.id!==i.id?[N]:s&&s!==c.status||j&&!["NEW","PENDING"].includes(c.status)?[]:[{...N,status:c.status}])),h(v=>{const N=["NEW","PENDING"].includes(i.status),Q=["NEW","PENDING"].includes(c.status);return Math.max(0,v+(Q?1:0)-(N?1:0))}),u(`Booking updated to ${r}.`),se({bookingId:i.id,type:"status"})}catch(c){u((c==null?void 0:c.message)||"Unable to update this booking.","error")}finally{l(null)}}},K=async()=>{const{default:t}=await H(async()=>{const{default:v}=await import("./html2pdf-X78KZjKX.js").then(N=>N.h);return{default:v}},__vite__mapDeps([0,1,2,3])),i=document.getElementById("bookings-export-container"),r=document.getElementById("bookings-pdf-header");if(!i||!d||d.length===0)return;E(!0),r&&(r.style.display="block");const c={margin:.5,filename:`Bookings_Report_${g}.pdf`,image:{type:"jpeg",quality:.98},html2canvas:{scale:2},jsPDF:{unit:"in",format:"letter",orientation:"landscape"}};try{await t().set(c).from(i).save()}finally{r&&(r.style.display="none"),E(!1)}},J=((O=G.find(t=>t.value===g))==null?void 0:O.label)||"All Time / Archive";return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`

        /*
        ============================================================
        BOOKINGS PAGE
        ============================================================
        */

        .bookings-page {
          width: 100%;
        }

        /*
        ============================================================
        CONTENT
        ============================================================
        */

        .bookings-content {
          width: 100%;
          max-width: 1200px;
        }

        /*
        ============================================================
        TOOLBAR
        ============================================================
        */

        .bookings-toolbar {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap: 12px;

          margin-bottom: 20px;

          padding: 12px;

          border:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            var(--c-bg, #fff);
        }

        .bookings-toolbar__filters {
          min-width: 0;

          flex: 1;

          display: flex;

          align-items: center;

          gap: 8px;

          flex-wrap: wrap;
        }

        /*
        ============================================================
        SEARCH
        ============================================================
        */

        .bookings-search {
          position: relative;

          flex: 1 1 280px;

          min-width: 220px;
        }

        .bookings-search__icon {
          position: absolute;

          left: 13px;

          top: 50%;

          transform:
            translateY(-50%);

          color:
            #999;

          pointer-events: none;
        }

        .bookings-search__input {
          width: 100%;

          min-height: 40px;

          box-sizing: border-box;

          padding:
            0 13px 0 40px;

          border:
            1px solid
            #d8d8d8;

          border-radius:
            7px;

          outline: none;

          background:
            #fafafa;

          color:
            var(--c-text, #111);

          font: inherit;

          transition:
            border-color 0.2s ease,
            background 0.2s ease,
            box-shadow 0.2s ease;
        }

        .bookings-search__input:hover {
          background:
            #fff;
        }

        .bookings-search__input:focus {
          background:
            #fff;

          border-color:
            var(--c-text, #111);

          box-shadow:
            0 0 0 3px
            rgba(
              0,
              0,
              0,
              0.04
            );
        }

        /*
        ============================================================
        SELECTS
        ============================================================
        */

        .bookings-select-wrap {
          position: relative;

          flex: 0 0 auto;

          display: flex;

          align-items: center;
        }

        .bookings-select-icon {
          position: absolute;

          left: 11px;

          color:
            #888;

          pointer-events: none;
        }

        .bookings-select {
          min-height: 40px;

          padding:
            0 12px 0 34px;

          border:
            1px solid
            #d8d8d8;

          border-radius:
            7px;

          background:
            #fafafa;

          color:
            var(--c-text, #111);

          outline: none;

          cursor: pointer;

          font: inherit;

          transition:
            border-color 0.2s ease,
            background 0.2s ease;
        }

        .bookings-select:hover {
          background:
            #fff;

          border-color:
            #c5c5c5;
        }

        .bookings-select:focus {
          background:
            #fff;

          border-color:
            var(--c-text, #111);

          box-shadow:
            0 0 0 3px
            rgba(
              0,
              0,
              0,
              0.04
            );
        }

        /*
        ============================================================
        EXPORT
        ============================================================
        */

        .bookings-export {
          display: inline-flex;

          align-items: center;
          justify-content: center;

          gap: 8px;

          min-height: 40px;

          padding:
            0 14px;

          white-space: nowrap;
        }

        .bookings-export:disabled {
          opacity:
            0.6;

          cursor:
            wait;
        }

        .bookings-priority-strip {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 18px;
          margin: -8px 0 20px;
          padding: 14px 16px;
          border-left: 4px solid var(--c-yellow, #f6ce00);
          background: #fff;
        }

        .bookings-priority-strip div { display: grid; gap: 3px; }
        .bookings-priority-strip span { color: #6b6b6b; font-size: .82rem; }
        .bookings-priority-toggle { border: 0; background: transparent; font: inherit; font-size: .8rem; font-weight: 800; text-decoration: underline; text-underline-offset: 4px; cursor: pointer; white-space: nowrap; }
        .bookings-priority-toggle.is-active { color: #8a6e00; }

        /*
        ============================================================
        DATA PANEL
        ============================================================
        */

        .bookings-panel {
          overflow: hidden;

          padding: 0;

          border:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            var(--c-bg, #fff);
        }

        /*
        ============================================================
        PDF HEADER
        ============================================================
        */

        .bookings-pdf-header {
          display: none;

          margin:
            22px;

          padding-bottom:
            15px;

          border-bottom:
            2px solid
            #111827;
        }

        .bookings-pdf-header h2 {
          margin: 0;

          color:
            #111827;
        }

        .bookings-pdf-header__meta {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap: 20px;

          margin-top: 8px;

          color:
            #4b5563;
        }

        /*
        ============================================================
        TABLE
        ============================================================
        */

        .bookings-table-wrap {
          width: 100%;

          overflow-x: auto;
        }

        .bookings-table {
          width: 100%;

          min-width: 850px;

          border-collapse:
            collapse;
        }

        .bookings-table th {
          padding:
            13px 16px;

          border-bottom:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            #fafafa;

          color:
            #777;

          text-align:
            left;

          text-transform:
            uppercase;

          white-space:
            nowrap;
        }

        .bookings-table td {
          padding:
            14px 16px;

          border-bottom:
            1px solid
            var(--c-hairline, #ededed);

          color:
            var(--c-text, #111);

          vertical-align:
            middle;
        }

        /*
        ============================================================
        BOOKING ROW
        ============================================================
        */

        .bookings-row {
          position: relative;

          cursor: pointer;

          transition:
            background 0.18s ease;
        }

        .bookings-row:hover {
          background:
            #fafafa;
        }

        .bookings-row:last-child td {
          border-bottom: 0;
        }

        .bookings-row__client {
          min-width:
            170px;
        }

        .bookings-row__email {
          display: block;

          margin-top: 3px;

          color:
            var(--c-gray, #777);
        }

        .bookings-row__shoot {
          min-width:
            120px;
        }

        .bookings-row__reference {
          white-space:
            nowrap;
        }

        .bookings-row__open {
          width: 32px;

          padding:
            0 8px;

          color:
            #aaa;

          transition:
            color 0.18s ease,
            transform 0.18s ease;
        }

        .bookings-row:hover
        .bookings-row__open {
          color:
            var(--c-text, #111);
        }

        .bookings-quick-actions { display: flex; align-items: center; justify-content: flex-end; gap: 5px; }
        .bookings-quick-actions button { display: inline-flex; align-items: center; gap: 5px; min-height: 30px; padding: 0 8px; border: 1px solid #d7d7d7; border-radius: 5px; background: #fff; color: #222; font: inherit; font-size: .7rem; font-weight: 750; cursor: pointer; white-space: nowrap; }
        .bookings-quick-actions button:hover:not(:disabled) { border-color: #111; background: #111; color: #fff; }
        .bookings-quick-actions button:disabled { opacity: .5; cursor: wait; }

        /*
        ============================================================
        MOBILE
        ============================================================
        */

        @media (max-width: 900px) {

          .bookings-toolbar {
            align-items:
              stretch;

            flex-direction:
              column;
          }

          .bookings-toolbar__filters {
            width: 100%;
          }

          .bookings-search {
            flex-basis:
              100%;
          }

          .bookings-select-wrap {
            flex: 1;
          }

          .bookings-select {
            width: 100%;
          }

          .bookings-export {
            width: 100%;
          }

          .bookings-priority-strip { align-items: flex-start; flex-direction: column; }

        }

        @media (max-width: 600px) {

          .bookings-toolbar {
            padding:
              10px;
          }

          .bookings-toolbar__filters {
            display: grid;

            grid-template-columns:
              1fr;

            gap: 8px;
          }

          .bookings-search {
            width: 100%;

            min-width: 0;
          }

          .bookings-select-wrap {
            width: 100%;
          }

          .bookings-pdf-header__meta {
            align-items:
              flex-start;

            flex-direction:
              column;

            gap: 5px;
          }

        }

        /*
        ============================================================
        REDUCED MOTION
        ============================================================
        */

        @media (
          prefers-reduced-motion: reduce
        ) {

          .bookings-search__input,
          .bookings-select,
          .bookings-row,
          .bookings-row__open {
            transition:
              none;
          }

        }

      `}),e.jsx("section",{className:"bookings-page",children:e.jsxs("div",{className:"admin-content bookings-content",children:[e.jsxs("div",{className:"bookings-toolbar",children:[e.jsxs("div",{className:"bookings-toolbar__filters",children:[e.jsxs("div",{className:"bookings-search",children:[e.jsx(ie,{size:17,className:"bookings-search__icon","aria-hidden":"true"}),e.jsx("input",{type:"text",className:"bookings-search__input",placeholder:"Search client, reference, service, or event date...",value:y,onChange:t=>A(t.target.value),"aria-label":"Search bookings"})]}),e.jsxs("div",{className:"bookings-select-wrap",children:[e.jsx(pe,{size:15,className:"bookings-select-icon","aria-hidden":"true"}),e.jsxs("select",{className:"bookings-select",value:s,onChange:t=>k(t.target.value),"aria-label":"Filter by status",children:[e.jsx("option",{value:"",children:"All statuses"}),me.map(t=>e.jsx("option",{value:t,children:t},t))]})]}),e.jsx("div",{className:"bookings-select-wrap",children:e.jsx("select",{className:"bookings-select",value:g,onChange:t=>L(t.target.value),"aria-label":"Filter by timeframe",style:{paddingLeft:12},children:G.map(t=>e.jsx("option",{value:t.value,children:t.label},t.value))})})]}),e.jsxs("button",{type:"button",onClick:K,disabled:C||!d||d.length===0,className:`\r
                btn\r
                btn--primary\r
                bookings-export\r
              `,children:[e.jsx(X,{size:16,"aria-hidden":"true"}),C?"Preparing…":"Download PDF"]})]}),e.jsxs("div",{className:"bookings-priority-strip",children:[e.jsxs("div",{children:[e.jsxs("strong",{children:[m," ",m===1?"request needs":"requests need"," attention"]}),e.jsx("span",{children:"New and pending requests that still need an owner decision."})]}),e.jsx("button",{type:"button",className:`bookings-priority-toggle${j?" is-active":""}`,onClick:()=>{k(""),D(t=>!t)},children:j?"Show all requests":"Show priority only"})]}),d===null&&e.jsx(W,{label:"Loading bookings…"}),d&&d.length===0&&e.jsx(V,{title:"No bookings found.",body:"Try adjusting your search or date filters."}),d&&d.length>0&&e.jsxs("div",{className:`\r
                  admin-panel\r
                  bookings-panel\r
                `,id:"bookings-export-container",children:[e.jsxs("div",{id:"bookings-pdf-header",className:"bookings-pdf-header",children:[e.jsx("h2",{children:"Jonathan Photography — Bookings Report"}),e.jsxs("div",{className:"bookings-pdf-header__meta",children:[e.jsxs("span",{children:[e.jsx("strong",{children:"Timeframe:"})," ",J]}),e.jsxs("span",{children:[e.jsx("strong",{children:"Generated:"})," ",new Date().toLocaleDateString()," ","at"," ",new Date().toLocaleTimeString()]})]})]}),e.jsx("div",{className:"bookings-table-wrap",children:e.jsxs("table",{className:"bookings-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Reference"}),e.jsx("th",{children:"Client"}),e.jsx("th",{children:"Shoot"}),e.jsx("th",{children:"Date"}),e.jsx("th",{children:"Agreed / Estimate"}),e.jsx("th",{children:"Balance"}),e.jsx("th",{children:"Status"}),e.jsx("th",{children:"Submitted"}),e.jsx("th",{})]})}),e.jsx("tbody",{children:d.map(t=>{var i;return e.jsxs("tr",{className:"bookings-row",onClick:()=>b(`${f}/${t.id}`,{state:{from:{...p,state:{...p.state||{},bookingFilters:{status:s,search:y,timeframe:g,priorityOnly:j},scrollY:window.scrollY}}}}),children:[e.jsx("td",{className:"bookings-row__reference","data-label":"Reference",children:t.reference_code||"—"}),e.jsxs("td",{className:"bookings-row__client","data-label":"Client",children:[e.jsx("strong",{children:t.name||"Unnamed Client"}),Number(t.open_flag_count)>0&&e.jsx("span",{className:"status-badge status-badge--FLAGGED",title:t.latest_flag_reason||"Oversight warning",children:"Flagged"}),e.jsx("span",{className:"bookings-row__email",children:t.email||"No email"})]}),e.jsx("td",{className:"bookings-row__shoot","data-label":"Shoot",children:t.shoot_type||"—"}),e.jsx("td",{"data-label":"Date",children:t.agreed_date||t.preferred_date||"—"}),e.jsx("td",{"data-label":"Agreed / Estimate",children:t.agreed_total||t.estimate_total?R(t.agreed_total||t.estimate_total):"—"}),e.jsx("td",{"data-label":"Balance",children:t.agreed_total?R(t.balance_due):"—"}),e.jsx("td",{"data-label":"Status",children:e.jsx("span",{className:`
                                  status-badge
                                  status-badge--${t.status}
                                `,children:t.status||"Unknown"})}),e.jsx("td",{"data-label":"Submitted",children:Y(t.created_at)}),e.jsx("td",{className:"bookings-row__open","data-label":"Actions",children:!o&&((i=z[t.status])!=null&&i.length)?e.jsx("div",{className:"bookings-quick-actions","aria-label":`Actions for ${t.name}`,children:z[t.status].map(r=>{const c=r.icon;return e.jsxs("button",{type:"button",onClick:v=>T(v,t,r.status),disabled:a===t.id,title:r.label,"aria-label":`${r.label} ${t.name}`,children:[e.jsx(c,{size:14,"aria-hidden":"true"}),e.jsx("span",{children:r.label})]},r.status)})}):e.jsx(re,{size:16,"aria-hidden":"true"})})]},t.id)})})]})})]})]})})]})}const $=[{value:"today",label:"Today"},{value:"last_week",label:"Last Week"},{value:"last_month",label:"Last Month"},{value:"last_3_months",label:"Last 3 Months"},{value:"last_quarter",label:"Last Quarter"},{value:"last_year",label:"Last Year"},{value:"all",label:"All Time / Archive"}];function ue(){var E;const[o,f]=n.useState(null),[p,b]=n.useState("today"),[u,d]=n.useState(null),[x,_]=n.useState(!1),[s,k]=n.useState(null),{showToast:y}=U();n.useEffect(()=>{document.title="Admin — Estimator Leads"},[]);const A=()=>{f(null),B.leads(p).then(a=>{f(Array.isArray(a)?a:[])}).catch(()=>{f([])})};n.useEffect(()=>{A()},[p]);const g=async()=>{if(!(s!=null&&s.status)||!(s!=null&&s.acknowledged))return;const{lead:a,status:l}=s,m=a.id;d(m);try{await B.updateLeadStatus(m,l,!0),y(`Lead finalized as ${l}.`,"success"),f(h=>Array.isArray(h)?h.map(w=>w.id===m?{...w,status:l}:w):h),k(null)}catch(h){y((h==null?void 0:h.message)||"Failed to update status.","error")}finally{d(null)}},L=a=>{switch(a){case"Booked":return"estimator-status estimator-status--booked";case"Lost":return"estimator-status estimator-status--lost";default:return"estimator-status estimator-status--new"}},j=a=>{try{const l=JSON.parse(a||"[]");return Array.isArray(l)?l:[]}catch{return[]}},D=async()=>{const{default:a}=await H(async()=>{const{default:w}=await import("./html2pdf-X78KZjKX.js").then(T=>T.h);return{default:w}},__vite__mapDeps([0,1,2,3])),l=document.getElementById("estimator-leads-export"),m=document.getElementById("estimator-leads-pdf-header");if(!l||!o||o.length===0)return;_(!0),m&&(m.style.display="block");const h={margin:.5,filename:`Estimator_Leads_${p}.pdf`,image:{type:"jpeg",quality:.98},html2canvas:{scale:2},jsPDF:{unit:"in",format:"letter",orientation:"landscape"}};try{await a().set(h).from(l).save()}finally{m&&(m.style.display="none"),_(!1)}},C=((E=$.find(a=>a.value===p))==null?void 0:E.label)||"All Time / Archive";return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`

        /*
        ============================================================
        ESTIMATOR LEADS
        ============================================================
        */

        .estimator-leads-page {
          width: 100%;
        }

        .estimator-leads-content {
          width: 100%;

          max-width:
            1100px;
        }

        /*
        ============================================================
        INTRO
        ============================================================
        */

        .estimator-leads-intro {
          margin-bottom:
            18px;

          color:
            var(--c-gray);
        }

        .estimator-leads-intro p {
          margin: 0;

          max-width:
            70ch;
        }

        /*
        ============================================================
        TOOLBAR
        ============================================================
        */

        .estimator-leads-toolbar {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap: 12px;

          margin-bottom:
            20px;

          padding:
            12px;

          border:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            var(--c-bg, #fff);
        }

        .estimator-leads-filter {
          display: flex;

          align-items: center;

          gap: 9px;

          min-width: 0;
        }

        .estimator-leads-filter__icon {
          flex: 0 0 auto;

          color:
            #777;
        }

        .estimator-leads-filter__label {
          color:
            var(--c-gray);
        }

        .estimator-leads-select-wrap {
          position: relative;

          display: flex;

          align-items: center;
        }

        .estimator-leads-select {
          min-height:
            40px;

          padding:
            0 34px 0 11px;

          border:
            1px solid
            #d8d8d8;

          border-radius:
            7px;

          background:
            #fafafa;

          color:
            var(--c-text, #111);

          outline:
            none;

          cursor:
            pointer;

          font:
            inherit;

          appearance:
            auto;

          transition:
            border-color 0.2s ease,
            background 0.2s ease,
            box-shadow 0.2s ease;
        }

        .estimator-leads-select:hover {
          background:
            #fff;

          border-color:
            #c5c5c5;
        }

        .estimator-leads-select:focus {
          background:
            #fff;

          border-color:
            var(--c-text, #111);

          box-shadow:
            0 0 0 3px
            rgba(
              0,
              0,
              0,
              0.04
            );
        }

        .estimator-leads-select-arrow {
          position: absolute;

          right:
            10px;

          pointer-events:
            none;

          color:
            #888;
        }

        /*
        ============================================================
        EXPORT
        ============================================================
        */

        .estimator-leads-export {
          display: inline-flex;

          align-items: center;
          justify-content: center;

          gap: 8px;

          min-height:
            40px;

          padding:
            0 15px;

          white-space:
            nowrap;
        }

        .estimator-leads-export:disabled {
          opacity:
            0.6;

          cursor:
            wait;
        }

        /*
        ============================================================
        DATA PANEL
        ============================================================
        */

        .estimator-leads-panel {
          overflow:
            hidden;

          padding:
            0;

          border:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            var(--c-bg, #fff);
        }

        /*
        ============================================================
        PDF HEADER
        ============================================================
        */

        .estimator-leads-pdf-header {
          display: none;

          margin:
            22px;

          padding-bottom:
            15px;

          border-bottom:
            2px solid
            #111827;
        }

        .estimator-leads-pdf-header h2 {
          margin:
            0;

          color:
            #111827;
        }

        .estimator-leads-pdf-header__meta {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap: 20px;

          margin-top:
            8px;

          color:
            #4b5563;
        }

        /*
        ============================================================
        TABLE
        ============================================================
        */

        .estimator-leads-table-wrap {
          width:
            100%;

          overflow-x:
            auto;
        }

        .estimator-leads-table {
          width:
            100%;

          min-width:
            900px;

          border-collapse:
            collapse;
        }

        .estimator-leads-table th {
          padding:
            13px 15px;

          border-bottom:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            #fafafa;

          color:
            #777;

          text-align:
            left;

          text-transform:
            uppercase;

          white-space:
            nowrap;
        }

        .estimator-leads-table td {
          padding:
            14px 15px;

          border-bottom:
            1px solid
            var(--c-hairline, #ededed);

          color:
            var(--c-text, #111);

          vertical-align:
            middle;
        }

        .estimator-leads-table tbody tr {
          transition:
            background 0.18s ease;
        }

        .estimator-leads-table tbody tr:hover {
          background:
            #fafafa;
        }

        .estimator-leads-table tbody tr:last-child td {
          border-bottom:
            0;
        }

        /*
        ============================================================
        CLIENT
        ============================================================
        */

        .estimator-lead-client {
          min-width:
            150px;
        }

        .estimator-lead-client__name {
          display: block;
        }

        .estimator-lead-client__email {
          display: block;

          margin-top:
            3px;

          color:
            var(--c-gray);
        }

        /*
        ============================================================
        ADD-ONS
        ============================================================
        */

        .estimator-lead-addons {
          display: block;

          max-width:
            230px;

          line-height:
            1.45;

          color:
            var(--c-gray);
        }

        /*
        ============================================================
        STATUS
        ============================================================
        */

        .estimator-status-control {
          position: relative;

          display: inline-flex;

          align-items: center;
        }

        .estimator-status {
          min-width:
            105px;

          min-height:
            36px;

          padding:
            0 30px 0 10px;

          border:
            1px solid
            #d6d6d6;

          border-radius:
            7px;

          outline:
            none;

          cursor:
            pointer;

          font:
            inherit;

          appearance:
            auto;

          transition:
            border-color 0.2s ease,
            background 0.2s ease,
            opacity 0.2s ease;
        }

        .estimator-status:hover:not(:disabled) {
          border-color:
            #bdbdbd;
        }

        .estimator-status:focus {
          border-color:
            #111;

          box-shadow:
            0 0 0 3px
            rgba(
              0,
              0,
              0,
              0.04
            );
        }

        .estimator-status:disabled {
          cursor:
            wait;

          opacity:
            0.6;
        }

        .estimator-status--new {
          background:
            #f3f4f6;

          color:
            #374151;
        }

        .estimator-status--contacted {
          background:
            #fef3c7;

          color:
            #92400e;
        }

        .estimator-status--booked {
          background:
            #dcfce7;

          color:
            #166534;
        }

        .estimator-status--lost {
          background:
            #fee2e2;

          color:
            #991b1b;
        }

        .estimator-status-spinner {
          position: absolute;

          right:
            10px;

          width:
            12px;

          height:
            12px;

          border:
            2px solid
            rgba(
              0,
              0,
              0,
              0.15
            );

          border-top-color:
            #111;

          border-radius:
            50%;

          animation:
            estimator-spin
            0.7s linear infinite;
        }

        @keyframes estimator-spin {
          to {
            transform:
              rotate(360deg);
          }
        }

        /*
        ============================================================
        EMPTY / LOADING SPACE
        ============================================================
        */

        .estimator-leads-table-count {
          padding:
            11px 15px;

          border-bottom:
            1px solid
            var(--c-hairline, #ededed);

          color:
            var(--c-gray);
        }

        /*
        ============================================================
        RESPONSIVE
        ============================================================
        */

        @media (max-width: 760px) {

          .estimator-leads-toolbar {
            align-items:
              stretch;

            flex-direction:
              column;
          }

          .estimator-leads-filter {
            width:
              100%;
          }

          .estimator-leads-select-wrap {
            flex:
              1;
          }

          .estimator-leads-select {
            width:
              100%;
          }

          .estimator-leads-export {
            width:
              100%;
          }

          .estimator-leads-pdf-header__meta {
            align-items:
              flex-start;

            flex-direction:
              column;

            gap:
              5px;
          }

        }

        @media (max-width: 500px) {

          .estimator-leads-toolbar {
            padding:
              10px;
          }

          .estimator-leads-filter {
            align-items:
              stretch;

            flex-direction:
              column;

            gap:
              7px;
          }

          .estimator-leads-filter__label {
            display:
              none;
          }

        }

        /*
        ============================================================
        REDUCED MOTION
        ============================================================
        */

        @media (
          prefers-reduced-motion: reduce
        ) {

          .estimator-leads-select,
          .estimator-leads-table tbody tr,
          .estimator-status {
            transition:
              none;
          }

          .estimator-status-spinner {
            animation:
              none;
          }

        }

      `}),e.jsx("section",{className:"estimator-leads-page",children:e.jsxs("div",{className:"admin-content estimator-leads-content",children:[e.jsx("div",{className:"estimator-leads-intro",children:e.jsx("p",{children:"People who priced a package but haven't necessarily submitted a booking yet."})}),e.jsxs("div",{className:"estimator-leads-toolbar",children:[e.jsxs("div",{className:"estimator-leads-filter",children:[e.jsx(de,{size:16,className:"estimator-leads-filter__icon","aria-hidden":"true"}),e.jsx("span",{className:"estimator-leads-filter__label",children:"Period"}),e.jsxs("div",{className:"estimator-leads-select-wrap",children:[e.jsx("select",{className:"estimator-leads-select",value:p,onChange:a=>b(a.target.value),"aria-label":"Filter estimator leads by timeframe",children:$.map(a=>e.jsx("option",{value:a.value,children:a.label},a.value))}),e.jsx(ne,{size:14,className:"estimator-leads-select-arrow","aria-hidden":"true"})]})]}),e.jsxs("button",{type:"button",onClick:D,disabled:x||!o||o.length===0,className:`
                btn
                btn--primary
                estimator-leads-export
              `,children:[e.jsx(X,{size:16,"aria-hidden":"true"}),x?"Preparing…":"Download PDF"]})]}),o===null&&e.jsx(W,{label:"Loading leads…"}),o&&o.length===0&&e.jsx(V,{title:"No estimator leads found.",body:"Try changing the date filter or wait for new leads."}),o&&o.length>0&&e.jsxs("div",{className:`
                  admin-panel
                  estimator-leads-panel
                `,id:"estimator-leads-export",children:[e.jsxs("div",{id:"estimator-leads-pdf-header",className:"estimator-leads-pdf-header",children:[e.jsx("h2",{children:"Jonathan Photography — Estimator Leads Report"}),e.jsxs("div",{className:"estimator-leads-pdf-header__meta",children:[e.jsxs("span",{children:[e.jsx("strong",{children:"Timeframe:"})," ",C]}),e.jsxs("span",{children:[e.jsx("strong",{children:"Generated:"})," ",new Date().toLocaleDateString()," ","at"," ",new Date().toLocaleTimeString()]})]})]}),e.jsxs("div",{className:"estimator-leads-table-count",children:[o.length," ",o.length===1?"lead":"leads"," ","found"]}),e.jsx("div",{className:"estimator-leads-table-wrap",children:e.jsxs("table",{className:"estimator-leads-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Name"}),e.jsx("th",{children:"Email"}),e.jsx("th",{children:"Hours"}),e.jsx("th",{children:"Service"}),e.jsx("th",{children:"Add-ons"}),e.jsx("th",{children:"Total"}),e.jsx("th",{children:"Status"}),e.jsx("th",{children:"Date"})]})}),e.jsx("tbody",{children:o.map(a=>{const l=j(a.addons),m=a.status||"New";return e.jsxs("tr",{children:[e.jsx("td",{className:"estimator-lead-client",children:e.jsx("strong",{className:"estimator-lead-client__name",children:a.name||"Unnamed Lead"})}),e.jsx("td",{children:a.email||"—"}),e.jsx("td",{children:a.hours||"—"}),e.jsx("td",{children:a.service_type||"—"}),e.jsx("td",{children:e.jsx("span",{className:"estimator-lead-addons",children:l.length?l.map(h=>h.label).join(", "):"—"})}),e.jsx("td",{children:R(a.total)}),e.jsx("td",{children:e.jsxs("div",{className:"estimator-status-control",children:[m==="New"?e.jsx("button",{type:"button",className:"estimator-status-action",disabled:u===a.id,onClick:()=>k({lead:a,status:"",acknowledged:!1}),children:"Set outcome"}):e.jsxs("span",{className:L(m),children:[e.jsx(M,{size:13}),m]}),u===a.id&&e.jsx("span",{className:"estimator-status-spinner","aria-hidden":"true"})]})}),e.jsx("td",{children:Y(a.created_at)})]},a.id)})})]})})]}),s&&e.jsx("div",{className:"lead-status-modal",role:"presentation",onMouseDown:()=>k(null),children:e.jsxs("section",{className:"lead-status-dialog",role:"dialog","aria-modal":"true","aria-labelledby":"lead-status-title",onMouseDown:a=>a.stopPropagation(),children:[e.jsx("button",{type:"button",className:"lead-status-dialog__close",onClick:()=>k(null),"aria-label":"Close status dialog",children:e.jsx(te,{size:18})}),e.jsx("span",{className:"lead-status-dialog__eyebrow",children:"Final lead outcome"}),e.jsxs("h2",{id:"lead-status-title",children:["Update ",s.lead.name||"this lead"]}),e.jsx("p",{children:"Keep the lead as New while contacting them. Choose an outcome only after they respond."}),e.jsx("div",{className:"lead-status-choices",role:"radiogroup","aria-label":"Final lead outcome",children:["Booked","Lost"].map(a=>e.jsxs("button",{type:"button",role:"radio","aria-checked":s.status===a,className:`lead-status-choice ${s.status===a?"lead-status-choice--active":""}`,onClick:()=>k(l=>({...l,status:a,acknowledged:!1})),children:[e.jsx("strong",{children:a}),e.jsx("span",{children:a==="Booked"?"The client is moving forward.":"The lead will not proceed."})]},a))}),e.jsxs("label",{className:`lead-final-toggle ${s.status?"":"lead-final-toggle--disabled"}`,children:[e.jsx("input",{type:"checkbox",checked:s.acknowledged,disabled:!s.status||u===s.lead.id,onChange:a=>k(l=>({...l,acknowledged:a.target.checked}))}),e.jsx("span",{className:"lead-final-toggle__track","aria-hidden":"true"}),e.jsxs("span",{children:[e.jsx("strong",{children:"I understand this update is final."}),e.jsx("small",{children:"Booked or lost leads cannot be changed afterward."})]})]}),e.jsxs("button",{type:"button",className:"btn btn--primary lead-status-submit",disabled:!s.status||!s.acknowledged||u===s.lead.id,onClick:g,children:[e.jsx(M,{size:16}),u===s.lead.id?"Finalizing…":`Finalize as ${s.status||"selected outcome"}`]})]})})]})})]})}function Ce({readOnly:o=!1}){const[f,p]=ae(),b=!o&&f.get("view")==="estimates"?"estimates":"bookings";n.useEffect(()=>{document.title="Admin — Client Requests"},[b]);const u=d=>{const x=new URLSearchParams(f);d==="bookings"?x.delete("view"):x.set("view","estimates"),p(x,{replace:!0})};return e.jsx("section",{className:"client-requests-page",children:e.jsxs("div",{className:"admin-content client-requests-content",children:[e.jsxs("header",{className:"client-requests-hero",children:[e.jsxs("div",{children:[e.jsx("span",{className:"client-requests-eyebrow",children:"One client journey"}),e.jsx("h2",{className:"display",children:o?"Booking Oversight":"Client Requests"}),e.jsx("p",{children:o?"Review owner-managed booking requests without changing studio records.":"Review saved estimates and complete booking requests without losing where each client is in the process."})]}),e.jsxs("div",{className:"client-requests-legend","aria-label":"Request stages",children:[e.jsx("span",{children:"Estimate saved"}),e.jsx("i",{"aria-hidden":"true"}),e.jsx("span",{children:"Booking requested"}),e.jsx("i",{"aria-hidden":"true"}),e.jsx("span",{children:"Confirmed"})]})]}),!o&&e.jsxs("div",{className:"client-requests-tabs",role:"tablist","aria-label":"Client request type",children:[e.jsxs("button",{type:"button",role:"tab","aria-selected":b==="bookings",className:b==="bookings"?"is-active":"",onClick:()=>u("bookings"),children:[e.jsx(le,{size:18}),e.jsxs("span",{children:[e.jsx("strong",{children:"Booking requests"}),e.jsx("small",{children:"Clients who selected a date and submitted their details"})]})]}),e.jsxs("button",{type:"button",role:"tab","aria-selected":b==="estimates",className:b==="estimates"?"is-active":"",onClick:()=>u("estimates"),children:[e.jsx(ce,{size:18}),e.jsxs("span",{children:[e.jsx("strong",{children:"Saved estimates"}),e.jsx("small",{children:"Potential clients who emailed themselves a package"})]})]})]}),e.jsx("div",{className:"client-requests-view",role:"tabpanel",children:b==="bookings"?e.jsx(he,{readOnly:o,detailBase:o?"/admin/oversight/bookings":"/admin/bookings"}):e.jsx(ue,{})})]})})}export{Ce as default};
