const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/html2pdf-DPFBub11.js","assets/index-DwFWKgCp.js","assets/index-D7-cqVfO.css","assets/html2canvas-CeW67R4n.js"])))=>i.map(i=>d[i]);
import{b as N,h as E,r as c,k as S,m as k,j as e,e as T,_ as L}from"./index-DwFWKgCp.js";import{p,a as u}from"./format-_QWv5Va2.js";import{E as D}from"./EmptyState-B-LsGAhm.js";import{CalendarArchivePanel as C}from"./AdminBookingCalendar-CHNsdER5.js";import"./useDialog-DroseHfc.js";import"./useReasonDialog-P5EpMZwJ.js";import"./AdminDialog-9dPws0kI.js";import"./MonthCalendar-14oEEjjn.js";import"./chevron-left-5p1vc4uS.js";import"./chevron-right-DSo6iEa9.js";import"./calendar-days-DYjZULSC.js";import"./plus-DsDCHajR.js";import"./download-c6ED4EcP.js";import"./map-pin-DmjL8CDi.js";import"./mail-DSclWBKU.js";import"./phone-9k874mB0.js";const f=[{value:"today",label:"Today"},{value:"last_week",label:"Last Week"},{value:"last_month",label:"Last Month"},{value:"last_3_months",label:"Last 3 Months"},{value:"last_quarter",label:"Last Quarter"},{value:"last_year",label:"Last Year"},{value:"all",label:"All Time / Archive"}];function Q(){var b;const n=N(),g=E(),[t,o]=c.useState(()=>{var a,r;return((r=(a=n.state)==null?void 0:a.archiveView)==null?void 0:r.activeTab)||"bookings"}),[l,j]=c.useState(()=>{var a,r;return((r=(a=n.state)==null?void 0:a.archiveView)==null?void 0:r.timeframe)||"today"}),[i,d]=c.useState(null),[m,x]=c.useState(!1);c.useEffect(()=>{document.title="Admin — Archive & Storage",y()},[t,l]);const y=async()=>{d(null);try{if(t==="calendar"){d([]);return}if(t==="bookings"){const a=await S.list({timeframe:l});d(Array.isArray(a)?a:[])}else{const a=await k.leads(l);d(Array.isArray(a)?a:[])}}catch(a){console.error("Archive load failed:",a),d([])}},w=async()=>{const{default:a}=await L(async()=>{const{default:_}=await import("./html2pdf-DPFBub11.js").then(A=>A.h);return{default:_}},__vite__mapDeps([0,1,2,3])),r=document.getElementById("archive-export-container"),s=document.getElementById("archive-pdf-header");if(!r)return;x(!0),s&&(s.style.display="block");const h={margin:.5,filename:`Archive_${t}_${l}.pdf`,image:{type:"jpeg",quality:.98},html2canvas:{scale:2},jsPDF:{unit:"in",format:"letter",orientation:"landscape"}};try{await a().set(h).from(r).save()}finally{s&&(s.style.display="none"),x(!1)}},v=((b=f.find(a=>a.value===l))==null?void 0:b.label)||"All Time / Archive";return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`

        /*
        ============================================================
        ARCHIVE PAGE
        ============================================================
        */

        .archive-page {
          width: 100%;
        }

        /*
        ============================================================
        TOOLBAR
        ============================================================
        */

        .archive-toolbar {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap: 18px;

          flex-wrap: wrap;

          margin-bottom: 20px;

          padding:
            14px;

          border:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            var(--c-bg, #fff);
        }

        /*
        ============================================================
        TABS
        ============================================================
        */

        .archive-tabs {
          display: grid;

          grid-template-columns:
            repeat(3, minmax(0, 1fr));

          align-items: center;

          gap: 5px;

          min-width: 0;

          width: 100%;

          padding: 4px;

          border:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            #f7f7f7;

          border-radius:
            8px;
        }

        .archive-tab {
          width: 100%;
          min-height: 38px;

          padding:
            0 14px;

          border: 0;

          border-radius:
            6px;

          background:
            transparent;

          color:
            #777;

          cursor: pointer;

          white-space: nowrap;

          transition:
            background 0.2s ease,
            color 0.2s ease;
        }

        .archive-tab:hover {
          color:
            var(--c-text, #111);

          background:
            #ececec;
        }

        .archive-tab--active {
          color:
            #fff;

          background:
            #111;
        }

        .archive-tab--active:hover {
          color:
            #fff;

          background:
            #111;
        }

        /*
        ============================================================
        FILTERS
        ============================================================
        */

        .archive-filters {
          display: flex;

          align-items: center;

          gap: 9px;

          flex: 0 0 auto;
        }

        .archive-filter-label {
          color:
            var(--c-gray, #777);
        }

        .archive-select {
          min-height: 40px;

          padding:
            0 34px 0 11px;

          border:
            1px solid
            #d8d8d8;

          border-radius:
            7px;

          background:
            #fafafa;

          color:
            var(--c-text, #111);

          outline: none;

          cursor: pointer;

          font: inherit;

          transition:
            border-color 0.2s ease,
            background 0.2s ease;
        }

        .archive-select:hover {
          background:
            #fff;

          border-color:
            #c5c5c5;
        }

        .archive-select:focus {
          background:
            #fff;

          border-color:
            var(--c-text, #111);

          box-shadow:
            0 0 0 3px
            rgba(
              0,
              0,
              0,
              0.04
            );
        }

        .archive-export {
          min-height: 40px;

          padding:
            0 15px;
        }

        .archive-export:disabled {
          opacity:
            0.6;

          cursor:
            wait;
        }

        /*
        ============================================================
        DATA PANEL
        ============================================================
        */

        .archive-panel {
          overflow: hidden;

          padding: 0;

          border:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            var(--c-bg, #fff);
        }

        /*
        ============================================================
        PDF HEADER
        ============================================================
        */

        .archive-pdf-header {
          display: none;

          margin:
            22px;

          padding-bottom:
            15px;

          border-bottom:
            2px solid
            #111827;
        }

        .archive-pdf-header h2 {
          margin: 0;

          color:
            #111827;
        }

        .archive-pdf-header__meta {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap: 20px;

          margin-top: 8px;

          color:
            #4b5563;
        }

        /*
        ============================================================
        TABLE
        ============================================================
        */

        .archive-table-wrap {
          width: 100%;

          overflow-x: auto;
        }

        .archive-table {
          width: 100%;

          min-width: 880px;

          border-collapse:
            collapse;
        }

        .archive-table th {
          padding:
            13px 16px;

          border-bottom:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            #fafafa;

          color:
            #777;

          text-align:
            left;

          text-transform:
            uppercase;

          white-space:
            nowrap;
        }

        .archive-table td {
          padding:
            14px 16px;

          border-bottom:
            1px solid
            var(--c-hairline, #ededed);

          color:
            var(--c-text, #111);

          vertical-align:
            middle;
        }

        .archive-table tbody tr {
          transition:
            background 0.18s ease;
        }

        .archive-table tbody tr:hover {
          background:
            #fafafa;
        }

        .archive-table tbody tr:last-child td {
          border-bottom: 0;
        }

        .archive-table__secondary {
          display: block;

          margin-top: 3px;

          color:
            var(--c-gray, #777);
        }

        .archive-table__muted {
          color:
            #999;
        }

        .archive-table__addons {
          max-width:
            240px;

          line-height:
            1.45;
        }

        /*
        ============================================================
        RESPONSIVE
        ============================================================
        */

        @media (max-width: 900px) {

          .archive-toolbar {
            align-items:
              stretch;

            flex-direction:
              column;
          }

          .archive-tabs {
            width:
              fit-content;
          }

          .archive-filters {
            flex-wrap:
              wrap;
          }

        }

        @media (max-width: 600px) {

          .archive-toolbar {
            padding:
              11px;
          }

          .archive-tabs {
            width: 100%;

            display: grid;

            grid-template-columns:
              1fr;
          }

          .archive-tab {
            width: 100%;

            padding:
              0 8px;
          }

          .archive-filters {
            display: grid;

            grid-template-columns:
              1fr;

            gap: 8px;
          }

          .archive-filter-label {
            display: none;
          }

          .archive-select,
          .archive-export {
            width: 100%;
          }

          .archive-pdf-header__meta {
            align-items:
              flex-start;

            flex-direction:
              column;

            gap: 5px;
          }

        }

        /*
        ============================================================
        REDUCED MOTION
        ============================================================
        */

        @media (
          prefers-reduced-motion: reduce
        ) {

          .archive-tab,
          .archive-select,
          .archive-table tbody tr {
            transition:
              none;
          }

        }

      `}),e.jsx("section",{className:"archive-page",children:e.jsxs("div",{className:"admin-content",style:{maxWidth:1200},children:[e.jsxs("div",{className:"archive-toolbar",children:[e.jsxs("div",{className:"archive-tabs",children:[e.jsx("button",{type:"button",className:`
                  archive-tab
                  ${t==="bookings"?"archive-tab--active":""}
                `,onClick:()=>o("bookings"),children:"Archived Bookings"}),e.jsx("button",{type:"button",className:`
                  archive-tab
                  ${t==="leads"?"archive-tab--active":""}
                `,onClick:()=>o("leads"),children:"Archived Estimator Leads"}),e.jsx("button",{type:"button",className:`archive-tab ${t==="calendar"?"archive-tab--active":""}`,onClick:()=>o("calendar"),children:"Calendar Archive"})]}),t!=="calendar"&&e.jsxs("div",{className:"archive-filters",children:[e.jsx("span",{className:"archive-filter-label",children:"Period"}),e.jsx("select",{"aria-label":"Period",className:"archive-select",value:l,onChange:a=>j(a.target.value),children:f.map(a=>e.jsx("option",{value:a.value,children:a.label},a.value))}),e.jsx("button",{type:"button",onClick:w,disabled:m||!i||i.length===0,className:`
                  btn
                  btn--primary
                  archive-export
                `,children:m?"Preparing…":"Download PDF"})]})]}),t==="calendar"&&e.jsx(C,{}),t!=="calendar"&&i===null&&e.jsx(T,{label:"Loading archive data…"}),t!=="calendar"&&i&&i.length===0&&e.jsx(D,{title:"No archived records found.",body:`No results for ${v.toLowerCase()}.`}),t!=="calendar"&&i&&i.length>0&&e.jsxs("div",{className:"admin-panel archive-panel",id:"archive-export-container",children:[e.jsxs("div",{id:"archive-pdf-header",className:"archive-pdf-header",children:[e.jsxs("h2",{children:["Jonathan Photography —"," ",t==="bookings"?"Bookings":"Estimator Leads"," ","Archive"]}),e.jsxs("div",{className:"archive-pdf-header__meta",children:[e.jsxs("span",{children:[e.jsx("strong",{children:"Timeframe:"})," ",v]}),e.jsxs("span",{children:[e.jsx("strong",{children:"Generated:"})," ",new Date().toLocaleDateString()," ","at"," ",new Date().toLocaleTimeString()]})]})]}),e.jsx("div",{className:"archive-table-wrap",children:e.jsx("table",{className:"archive-table",children:t==="bookings"?e.jsxs(e.Fragment,{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Reference"}),e.jsx("th",{children:"Client"}),e.jsx("th",{children:"Shoot"}),e.jsx("th",{children:"Date"}),e.jsx("th",{children:"Agreed / Estimate"}),e.jsx("th",{children:"Balance"}),e.jsx("th",{children:"Status"}),e.jsx("th",{children:"Submitted"})]})}),e.jsx("tbody",{children:i.map(a=>e.jsxs("tr",{className:"bookings-row",onClick:()=>g(`/admin/bookings/${a.id}`,{state:{from:{...n,state:{...n.state||{},archiveView:{activeTab:t,timeframe:l},scrollY:window.scrollY}}}}),children:[e.jsx("td",{"data-label":"Reference",children:a.reference_code||"—"}),e.jsxs("td",{"data-label":"Client",children:[e.jsx("strong",{children:a.name||"Unnamed Client"}),e.jsx("span",{className:"archive-table__secondary",children:a.email||"No email"})]}),e.jsx("td",{"data-label":"Shoot",children:a.shoot_type||"—"}),e.jsx("td",{"data-label":"Date",children:a.agreed_date||a.preferred_date||"—"}),e.jsx("td",{"data-label":"Agreed / Estimate",children:a.agreed_total||a.estimate_total?p(a.agreed_total||a.estimate_total):"—"}),e.jsx("td",{"data-label":"Balance",children:a.agreed_total?p(a.balance_due):"—"}),e.jsx("td",{"data-label":"Status",children:e.jsx("span",{className:`
                                      status-badge
                                      status-badge--${a.status}
                                    `,children:a.status||"Unknown"})}),e.jsx("td",{"data-label":"Submitted",children:u(a.created_at)})]},a.id))})]}):e.jsxs(e.Fragment,{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Name"}),e.jsx("th",{children:"Email"}),e.jsx("th",{children:"Hours"}),e.jsx("th",{children:"Service"}),e.jsx("th",{children:"Add-ons"}),e.jsx("th",{children:"Total"}),e.jsx("th",{children:"Status"}),e.jsx("th",{children:"Submitted"})]})}),e.jsx("tbody",{children:i.map(a=>{let r=[];try{r=JSON.parse(a.addons||"[]")}catch{r=[]}const s=a.status||(a.booked_live?"Booked":"New");return e.jsxs("tr",{children:[e.jsx("td",{"data-label":"Name",children:e.jsx("strong",{children:a.name||"Unnamed Lead"})}),e.jsx("td",{"data-label":"Email",children:a.email||"—"}),e.jsx("td",{"data-label":"Hours",children:a.hours||"—"}),e.jsx("td",{"data-label":"Service",children:a.service_type||"—"}),e.jsx("td",{"data-label":"Add-ons",children:e.jsx("span",{className:"archive-table__addons",children:r.length?r.map(h=>h.label).join(", "):"—"})}),e.jsx("td",{"data-label":"Total",children:p(a.total)}),e.jsx("td",{"data-label":"Status",children:e.jsx("span",{className:"status-badge",children:s})}),e.jsx("td",{"data-label":"Submitted",children:u(a.created_at)})]},a.id)})})]})})})]})]})})]})}export{Q as default};
