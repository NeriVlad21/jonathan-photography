const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/html2pdf-X78KZjKX.js","assets/index-ZwdCBnk2.js","assets/index-D7-cqVfO.css","assets/html2canvas-GsVsA2Tp.js"])))=>i.map(i=>d[i]);
import{i as F,f as Xe,h as Je,b as Qe,l as Ze,r as p,j as e,e as ea,C as Ne,k as M,B as aa,_ as ta}from"./index-ZwdCBnk2.js";import{u as sa}from"./useDialog-BRPQSVDI.js";import{u as na}from"./useReasonDialog-C6eL57Ol.js";import{p as i,f as B,a as Y}from"./format-C7C3p2s4.js";import{p as ia,f as U,F as oa}from"./billing-ByEFYPR2.js";import{n as G}from"./adminDataSync-qIaoXYq1.js";import{A as we,C as la}from"./check-Ccuhh0L7.js";import{S as W}from"./shield-check-BM8gRDKt.js";import{P as ra}from"./pencil-CLA_XYXX.js";import{E as Ce}from"./eye-DEQCkNaR.js";import{D as da}from"./download-BbMOI5pm.js";import{S as ca}from"./send-C2q1HJC7.js";import{U as Ee}from"./user-Cllqh9M3.js";import{M as pa}from"./mail-nVvp0Xdw.js";import{P as ga}from"./phone-D_lxkqaQ.js";import{F as ma}from"./facebook-AEmTq_Dm.js";import{C as Pe}from"./calendar-days-DHsoeBVF.js";import{M as ba}from"./map-pin-CoYXx_Zk.js";import"./AdminDialog-0MHyKvab.js";/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ha=F("CreditCard",[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ae=F("Database",[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3",key:"msslwz"}],["path",{d:"M3 5V19A9 3 0 0 0 21 19V5",key:"1wlel7"}],["path",{d:"M3 12A9 3 0 0 0 21 12",key:"mv7ke4"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Te=F("MessageSquare",[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",key:"1lielz"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const De=F("Receipt",[["path",{d:"M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z",key:"q3az6g"}],["path",{d:"M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8",key:"1h4pet"}],["path",{d:"M12 17.5v-11",key:"1jc1ny"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _a=F("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]]),ua={NEW:["PENDING","CONFIRMED","CANCELLED"],PENDING:["CONFIRMED","CANCELLED"],CONFIRMED:["COMPLETED","CANCELLED"]},Ie={PENDING:["Mark pending","Keep this request visible while you contact the client."],CONFIRMED:["Confirm booking","The client accepted the final arrangement."],COMPLETED:["Mark completed","The photography service has been delivered."],CANCELLED:["Cancel booking","The booking will not proceed."]};function $a({readOnly:k=!1}){var je,ye;const{id:b}=Xe(),ne=Je(),Me=Qe(),{showToast:m}=Ze(),[t,v]=p.useState(null),[$,ie]=p.useState(!1),[h,oe]=p.useState(""),[V,H]=p.useState(!1),[le,K]=p.useState(!1),[X,re]=p.useState(!1),[de,O]=p.useState(!1),[N,ce]=p.useState(!1),[Se,pe]=p.useState(!1),[d,T]=p.useState(null),Le=sa(!!d,()=>{N||T(null)}),[ge,me]=p.useState(!1),[J,be]=p.useState(!1),[l,_]=p.useState({total:"",fee_responsibility:"",pass_platform_fee_to_client:null,coverage:"",hours:"",date:"",location:"",notes:"",addonsText:""}),[u,R]=p.useState({amount:"",date:new Date().toISOString().slice(0,10),note:""}),w=((je=Me.state)==null?void 0:je.from)||(k?"/admin/oversight/bookings":"/admin/bookings"),he=()=>{typeof w=="string"?ne(w):(ne({pathname:w.pathname,search:w.search,hash:w.hash},{state:w.state}),window.setTimeout(()=>{var a;return window.scrollTo({top:Number(((a=w.state)==null?void 0:a.scrollY)||0),behavior:"auto"})},0))},_e=()=>{M.details(b).then(a=>{v(a||!1)}).catch(()=>{v(!1)})},Fe=async()=>{if(!J){be(!0);try{v(await M.details(b,!0)),m("Contact details revealed and recorded in the access log.")}catch(a){m(a.message||"Unable to reveal contact details.","error")}finally{be(!1)}}},[$e,Oe]=na(),Re=()=>$e({title:"Flag this booking",summary:[{label:"Booking",value:t==null?void 0:t.reference_code},{label:"Service",value:t==null?void 0:t.shoot_type},{label:"Current state",value:t!=null&&t.status?`${t.status.toLowerCase()} · no open flag`:""}],onSubmit:async a=>{me(!0);try{const s=await aa.createFlag({entity_type:"BOOKING",entity_id:Number(b),reason:a});v(o=>({...o,flags:[...o.flags||[],{entity_type:"BOOKING",entity_id:Number(b),reason:a,status:"OPEN"}]})),m(s.message)}finally{me(!1)}}});p.useEffect(()=>{_e()},[b]),p.useEffect(()=>{document.title="Admin — Booking Details"},[]);const qe=async()=>{if(!(!h||!V)){ie(!0);try{const a=await M.updateStatus(b,h,!0);m(`Booking and calendar updated to ${h}.`),oe(""),H(!1),v(s=>({...s,status:a.status})),G({bookingId:b,type:"status"})}catch(a){m((a==null?void 0:a.message)||"Unable to update booking status.","error")}finally{ie(!1)}}},Q=async a=>{var r;const s=B(((r=t.agreed_details)==null?void 0:r.date)||t.preferred_date),o={acknowledge:`Hi ${t.name}, we received your ${t.shoot_type} booking request (${t.reference_code}) for ${s}. We will review the details and contact you shortly. This is still a request and is not yet a confirmed booking.`,confirm:`Hi ${t.name}, your ${t.shoot_type} booking for ${s} is confirmed under reference ${t.reference_code}. Please contact us if any agreed event detail changes.`,cancel:`Hi ${t.name}, we are sorry to let you know that booking request ${t.reference_code} for ${s} will not proceed. Please contact us if you would like to discuss another date or service.`};try{await navigator.clipboard.writeText(o[a]),m("Response copied. You can paste it into Messenger, email, or SMS.")}catch{m("Unable to copy the response in this browser.","error")}},ze=()=>{var s,o;const a=t.agreed_details||{};_({total:a.total??(t.estimate_total?Math.round(Number(t.estimate_total)):""),coverage:a.coverage??"",fee_responsibility:a.fee_responsibility||((o=(s=t.platform_fee)==null?void 0:s.settings)!=null&&o.pass_platform_fee_to_client_default?"CLIENT":"STUDIO"),pass_platform_fee_to_client:t.pass_platform_fee_to_client===null||t.pass_platform_fee_to_client===void 0?null:!!Number(t.pass_platform_fee_to_client),hours:a.hours??"",date:a.date??t.preferred_date??"",location:a.location??t.location??"",notes:a.notes??"",addonsText:(a.addons||[]).map(r=>`${r.label}|${r.amount}|${r.quantity||1}`).join(`
`)}),K(!0)},Be=async a=>{var x,f,I,j;a.preventDefault();const s=((x=t.agreed_details)==null?void 0:x.fee_responsibility)==="CLIENT",o=l.pass_platform_fee_to_client===null?!!((I=(f=t.platform_fee)==null?void 0:f.settings)!=null&&I.pass_platform_fee_to_client_default):l.pass_platform_fee_to_client;if((t.invoices||[]).some(c=>c.sent_at&&!c.voided_at)&&s!==o&&!window.confirm("This changes who pays the platform fee. The existing sent invoice will remain preserved and a revised draft will be created. Continue?"))return;const r=l.addonsText.split(`
`).map(c=>c.trim()).filter(Boolean).map(c=>{const[A,y="0",g="1"]=c.split("|").map(L=>L.trim());return{label:A,amount:y,quantity:g}});re(!0);try{const c=await M.updateAgreedDetails({id:b,...l,pass_platform_fee_to_client:l.pass_platform_fee_to_client,addons:r});v(A=>({...A,...c,invoices:[...c.revised_invoices||[],...(A.invoices||[]).map(y=>y.voided_at?y:{...y,voided_at:new Date().toISOString()})]})),K(!1),O(!1),_e(),G({bookingId:b,type:"agreed-details"}),m((j=c.revised_invoices)!=null&&j.length?"Agreed details saved. Earlier invoices were preserved and revised drafts were created.":"Agreed booking details saved.")}catch(c){m((c==null?void 0:c.message)||"Unable to save agreed details.","error")}finally{re(!1)}},Ye=a=>{var o;a.preventDefault();const s=(o=t.payments)!=null&&o.some(r=>r.payment_type==="DOWN_PAYMENT")?"FINAL_PAYMENT":"DOWN_PAYMENT";T({draftPayment:!0,payment_type:s,amount:Number(u.amount),date:u.date,note:u.note})},Ue=async()=>{const a=d==null?void 0:d.payment_type;if(a){ce(!0);try{const s=await M.recordPayment({id:b,payment_type:a,...u});v(o=>({...o,payments:s.payments,invoices:[s.invoice,...o.invoices||[]],total_paid:s.total_paid,balance_due:s.balance_due,financials:s.financials||o.financials})),O(!1),T(null),G({bookingId:b,type:"payment"}),m(s.message||"Payment recorded.")}catch(s){m((s==null?void 0:s.message)||"Unable to record payment.","error")}finally{ce(!1)}}},Ge=async a=>{pe(!0);try{const s=await M.sendInvoice(a);v(o=>({...o,invoices:o.invoices.map(r=>r.id===a?{...r,sent_at:s.sent_at}:r)})),G({bookingId:b,type:"invoice"}),m(s.message||"Invoice sent successfully.")}catch(s){m((s==null?void 0:s.message)||"Unable to send invoice.","error")}finally{pe(!1)}},We=async a=>{var j,c,A,y;const s=a.snapshot,o=document.createElement("div");o.style.cssText="font-family:Arial,sans-serif;padding:38px;color:#111;max-width:760px";const r=s.agreed_details||{},x=s.platform_fee||{},f=s.service_total!==void 0;[((j=s.studio)==null?void 0:j.name)||"Jonathan Photography",a.invoice_number,a.voided_at?`VOID — ${s.status_label}`:s.status_label,`Issued: ${s.issued_on||"—"}`,`Booking: ${(c=s.booking)==null?void 0:c.reference_code}`,`Client: ${(A=s.client)==null?void 0:A.name}`,`Package: ${(y=s.booking)==null?void 0:y.shoot_type}`,`Coverage: ${r.coverage||"—"}${r.hours?` · ${r.hours} hours`:""}`,...(r.addons||[]).map(g=>`Add-on: ${g.quantity||1}× ${g.label} — ${i(Number(g.amount||0)*Number(g.quantity||1))}`),...f?[`Agreed service price: ${i(s.service_total)}`,...x.charged_to_client?[`Platform service fee (${U(x.rate)}): ${i(x.amount)}`]:[]]:[],`${f?"Total payable":"Agreed total"}: ${i(s.agreed_total)}`,...f&&s.invoice_type==="DOWN_PAYMENT"?[`Required down payment (50%): ${i(s.required_down_payment)}`]:[],...(s.payments||[]).map(g=>`${g.payment_type==="FINAL_PAYMENT"?"Final payment":"Down payment"} received (${g.received_at}): ${i(g.amount)}`),`Balance due: ${i(s.balance_due)}`,...f?x.charged_to_client?["As agreed, the platform service fee is included in the total payable."]:[]:[`Platform service fee included: ${i(x.amount||0)}`,"The platform service fee is already included in the agreed total and is not charged separately."]].forEach((g,L)=>{const z=document.createElement(L<3?"h2":"p");z.textContent=g,o.appendChild(z)}),document.body.appendChild(o);try{const{default:g}=await ta(async()=>{const{default:L}=await import("./html2pdf-X78KZjKX.js").then(z=>z.h);return{default:L}},__vite__mapDeps([0,1,2,3]));await g().set({margin:.5,filename:`${a.invoice_number}.pdf`,html2canvas:{scale:2},jsPDF:{unit:"in",format:"letter"}}).from(o).save()}finally{o.remove()}};if(t===null)return e.jsx(ea,{label:"Loading booking…"});if(t===!1)return e.jsxs("div",{className:"booking-details-empty",children:[e.jsx("style",{children:`

          .booking-details-empty {
            min-height: 40vh;

            display: flex;

            flex-direction: column;

            align-items: center;
            justify-content: center;

            padding:
              40px 20px;

            text-align:
              center;
          }

          .booking-details-empty__title {
            margin:
              0 0 8px;
          }

          .booking-details-empty__text {
            margin:
              0 0 18px;

            color:
              var(--c-gray);
          }

        `}),e.jsx("h2",{className:"booking-details-empty__title",children:"Booking not found."}),e.jsx("p",{className:"booking-details-empty__text",children:"The booking may have been removed or is no longer available."}),e.jsxs("button",{type:"button",onClick:he,className:"text-link",children:[e.jsx(we,{size:15,style:{verticalAlign:"middle",marginRight:5}}),"Go back"]})]});const Z=Array.isArray(t.addons)?t.addons:[],ue=Array.isArray(t.payments)?t.payments:[],q=Array.isArray(t.invoices)?t.invoices:[],S=ue.some(a=>a.payment_type==="DOWN_PAYMENT"),ee=ue.some(a=>a.payment_type==="FINAL_PAYMENT"),ae=q.some(a=>a.invoice_type==="DOWN_PAYMENT"&&!a.voided_at&&a.sent_at),Ve=q.some(a=>a.invoice_type==="FINAL_PAYMENT"&&!a.voided_at&&a.sent_at),C=S?"FINAL_PAYMENT":"DOWN_PAYMENT",He=S?"Record Final Payment":"Record Down Payment",Ke=!S||ae&&!ee,n=t.financials||null,te=((ye=t.platform_fee)==null?void 0:ye.settings)||{},xe=l.pass_platform_fee_to_client===null?te.pass_platform_fee_to_client_default?"CLIENT":"STUDIO":l.pass_platform_fee_to_client?"CLIENT":"STUDIO",D=ia(l.total,xe,te),E=Number((n==null?void 0:n.balance_due)??t.balance_due??0),P=Number((n==null?void 0:n.required_down_payment)||0),fe=Math.max(0,Math.floor(E)-1),ke=C==="FINAL_PAYMENT"?E:Math.max(1,P),se=C==="FINAL_PAYMENT"?E:fe,ve=C==="FINAL_PAYMENT"||ke<=se;return e.jsxs(e.Fragment,{children:[Oe,e.jsx("style",{children:`

        /*
        ============================================================
        BOOKING DETAILS
        ============================================================
        */

        .booking-details-page {
          width: 100%;
        }

        .booking-details-content {
          width: 100%;

          max-width:
            1000px;
        }

        /*
        ============================================================
        BACK NAVIGATION
        ============================================================
        */

        .booking-details-back {
          display: inline-flex;

          align-items: center;

          gap: 7px;

          margin-bottom:
            18px;

          color:
            var(--c-gray);

          text-decoration:
            none;

          transition:
            color 0.2s ease,
            transform 0.2s ease;
        }

        .booking-details-back:hover {
          color:
            var(--c-text);

          transform:
            translateX(-2px);
        }

        /*
        ============================================================
        RECORD HEADER
        ============================================================
        */

        .booking-details-hero {
          display: flex;

          align-items: flex-start;
          justify-content: space-between;

          gap: 20px;

          margin-bottom:
            20px;

          padding:
            22px;

          border:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            var(--c-bg, #fff);
        }

        .booking-details-hero__copy {
          min-width: 0;
        }

        .booking-details-hero__eyebrow {
          display: block;

          margin-bottom:
            6px;

          color:
            var(--c-gray);

          text-transform:
            uppercase;
        }

        .booking-details-hero__title {
          margin:
            0;
        }

        .booking-details-hero__reference {
          margin:
            6px 0 0;

          color:
            var(--c-gray);
        }

        .booking-details-hero__status {
          flex: 0 0 auto;
        }

        /*
        ============================================================
        PANELS
        ============================================================
        */

        .booking-details-panel {
          margin-bottom:
            16px;

          border:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            var(--c-bg, #fff);

          overflow:
            hidden;
        }

        .booking-details-panel__head {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap: 15px;

          padding:
            17px 20px;

          border-bottom:
            1px solid
            var(--c-hairline, #e5e5e5);
        }

        .booking-details-panel__title-wrap {
          display: flex;

          align-items: center;

          gap: 9px;

          min-width: 0;
        }

        .booking-details-panel__icon {
          display: inline-flex;

          align-items: center;
          justify-content: center;

          flex: 0 0 auto;

          color:
            #777;
        }

        .booking-details-panel__title {
          margin: 0;
        }

        .booking-details-panel__body {
          padding:
            20px;
        }

        /*
        ============================================================
        STATUS
        ============================================================
        */

        .booking-status-actions {
          display: flex;

          align-items: center;

          gap: 8px;

          flex-wrap:
            wrap;
        }

        .booking-status-button {
          min-height:
            38px;

          padding:
            0 13px;

          border:
            1px solid
            #d6d6d6;

          border-radius:
            7px;

          background:
            #fafafa;

          color:
            var(--c-text, #111);

          cursor:
            pointer;

          font:
            inherit;

          transition:
            background 0.2s ease,
            color 0.2s ease,
            border-color 0.2s ease,
            opacity 0.2s ease;
        }

        .booking-status-button:hover:not(:disabled) {
          background:
            #f0f0f0;

          border-color:
            #c8c8c8;
        }

        .booking-status-button--active {
          background:
            #111;

          border-color:
            #111;

          color:
            #fff;
        }

        .booking-status-button--active:hover:not(:disabled) {
          background:
            #111;

          border-color:
            #111;

          color:
            #fff;
        }

        .booking-status-button:disabled {
          cursor:
            default;

          opacity:
            0.55;
        }

        .booking-status-workflow {
          display: grid;
          gap: 18px;
        }

        .booking-status-workflow__intro {
          max-width: 680px;
        }

        .booking-status-workflow__intro > span {
          display: block;
          margin-bottom: 4px;
          color: var(--c-gray);
          font-size: 0.68rem;
          font-weight: 700;
          letter-spacing: 0.12em;
          text-transform: uppercase;
        }

        .booking-status-workflow__intro > strong {
          display: block;
          font-size: 1.15rem;
        }

        .booking-status-workflow__intro p,
        .booking-status-final p {
          margin: 5px 0 0;
          color: var(--c-gray);
          line-height: 1.55;
        }

        .booking-status-button {
          min-width: 230px;
          padding: 14px 16px;
          text-align: left;
        }

        .booking-status-button span,
        .booking-status-button small {
          display: block;
        }

        .booking-status-button span {
          font-weight: 700;
        }

        .booking-status-button small {
          margin-top: 3px;
          color: var(--c-gray);
          font-size: 0.74rem;
        }

        .booking-status-button--active {
          background: var(--c-yellow);
          border-color: var(--c-black);
          color: var(--c-black);
        }

        .booking-status-button--active small {
          color: rgba(17, 17, 15, 0.68);
        }

        .booking-final-toggle {
          display: flex;
          align-items: center;
          gap: 12px;
          width: fit-content;
          cursor: pointer;
        }

        .booking-final-toggle--disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .booking-final-toggle input {
          position: absolute;
          opacity: 0;
          pointer-events: none;
        }

        .booking-final-toggle__track {
          position: relative;
          width: 42px;
          height: 24px;
          flex: 0 0 42px;
          border: 1px solid #aaa;
          border-radius: 999px;
          background: #dddcd7;
          transition: background 0.2s ease;
        }

        .booking-final-toggle__track::after {
          content: '';
          position: absolute;
          top: 3px;
          left: 3px;
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: #fff;
          transition: transform 0.2s ease;
        }

        .booking-final-toggle input:checked + .booking-final-toggle__track {
          background: var(--c-black);
        }

        .booking-final-toggle input:checked + .booking-final-toggle__track::after {
          transform: translateX(18px);
        }

        .booking-final-toggle input:focus-visible + .booking-final-toggle__track {
          outline: 3px solid rgba(242, 203, 5, 0.42);
          outline-offset: 2px;
        }

        .booking-final-toggle strong,
        .booking-final-toggle small {
          display: block;
        }

        .booking-final-toggle small {
          margin-top: 2px;
          color: var(--c-gray);
        }

        .booking-status-submit {
          width: fit-content;
        }

        .booking-status-submit:disabled {
          opacity: 0.42;
          cursor: not-allowed;
        }

        .booking-status-final {
          display: flex;
          gap: 14px;
          align-items: flex-start;
          padding: 18px;
          border-left: 4px solid var(--c-yellow);
          background: #f5f4ef;
        }

        .booking-status-final__icon {
          display: grid;
          place-items: center;
          width: 40px;
          height: 40px;
          flex: 0 0 40px;
          border-radius: 50%;
          background: var(--c-black);
          color: var(--c-yellow);
        }

        /*
        ============================================================
        INFORMATION GRID
        ============================================================
        */

        .booking-info-grid {
          display: grid;

          grid-template-columns:
            repeat(
              2,
              minmax(0, 1fr)
            );

          gap:
            20px 30px;
        }

        .booking-info-item {
          min-width: 0;
        }

        .booking-info-item__label {
          display: flex;

          align-items: center;

          gap: 7px;

          margin-bottom:
            5px;

          color:
            var(--c-gray);

          text-transform:
            uppercase;
        }

        .booking-info-item__value {
          margin: 0;

          color:
            var(--c-text);
        }

        .booking-info-item__value a {
          color:
            inherit;

          text-decoration:
            none;
        }

        .booking-info-item__value a:hover {
          text-decoration:
            underline;
        }

        /*
        ============================================================
        MESSAGE
        ============================================================
        */

        .booking-message {
          margin-top:
            20px;

          padding-top:
            20px;

          border-top:
            1px solid
            var(--c-hairline, #e5e5e5);
        }

        .booking-template-actions {
          display: flex;
          flex-wrap: wrap;
          gap: 9px;
          margin-top: 16px;
        }

        .booking-message__label {
          display: flex;

          align-items: center;

          gap: 7px;

          margin-bottom:
            8px;

          color:
            var(--c-gray);

          text-transform:
            uppercase;
        }

        .booking-message__text {
          margin: 0;

          color:
            var(--c-text);

          white-space:
            pre-wrap;

          line-height:
            1.65;
        }

        /*
        ============================================================
        ESTIMATE
        ============================================================
        */

        .booking-estimate-list {
          display: flex;

          flex-direction:
            column;
        }

        .booking-estimate-row {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap: 20px;

          padding:
            10px 0;

          border-bottom:
            1px solid
            var(--c-hairline, #ededed);
        }

        .booking-estimate-row:last-child {
          border-bottom:
            0;
        }

        .booking-estimate-row__label {
          min-width: 0;
        }

        .booking-estimate-row__price {
          flex: 0 0 auto;

          white-space:
            nowrap;
        }

        .booking-estimate-total {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap: 20px;

          margin-top:
            8px;

          padding-top:
            15px;

          border-top:
            2px solid
            var(--c-text);
        }

        .booking-estimate-total__label {
          font-weight:
            700;
        }

        .booking-estimate-total__price {
          font-weight:
            700;
        }

        /*
        ============================================================
        METADATA
        ============================================================
        */

        .booking-consent {
          display: inline-flex;

          align-items: center;

          gap: 6px;
        }

        .booking-consent--yes {
          color:
            #247447;
        }

        .booking-consent--no {
          color:
            #9a3838;
        }

        /*
        ============================================================
        TWO-COLUMN LAYOUT
        ============================================================
        */

        .booking-details-columns {
          display: grid;

          grid-template-columns:
            repeat(
              2,
              minmax(0, 1fr)
            );

          gap:
            16px;
        }

        .booking-details-columns
        .booking-details-panel {
          margin-bottom:
            0;
        }

        /*
        ============================================================
        RESPONSIVE
        ============================================================
        */

        @media (max-width: 760px) {

          .booking-details-content {
            max-width:
              none;
          }

          .booking-details-hero {
            align-items:
              flex-start;

            flex-direction:
              column;
          }

          .booking-details-hero__status {
            width:
              100%;
          }

          .booking-info-grid {
            grid-template-columns:
              1fr;
          }

          .booking-details-columns {
            grid-template-columns:
              1fr;
          }

          .booking-status-actions {
            display: grid;

            grid-template-columns:
              repeat(
                2,
                minmax(0, 1fr)
              );

            width:
              100%;
          }

          .booking-status-button {
            width:
              100%;
          }

        }

        @media (max-width: 500px) {

          .booking-details-panel__head,
          .booking-details-panel__body,
          .booking-details-hero {
            padding:
              16px;
          }

          .booking-status-actions {
            grid-template-columns:
              1fr;
          }

          .booking-estimate-row,
          .booking-estimate-total {
            align-items:
              flex-start;

            flex-direction:
              column;

            gap:
              4px;
          }

        }

        /*
        ============================================================
        REDUCED MOTION
        ============================================================
        */

        @media (
          prefers-reduced-motion: reduce
        ) {

          .booking-details-back,
          .booking-status-button {
            transition:
              none;
          }

        }

      `}),e.jsx("section",{className:"booking-details-page",children:e.jsxs("div",{className:"admin-content booking-details-content",children:[e.jsxs("button",{type:"button",onClick:he,className:"booking-details-back",children:[e.jsx(we,{size:16,"aria-hidden":"true"}),"Go back"]}),e.jsxs("div",{className:"booking-details-hero",children:[e.jsxs("div",{className:"booking-details-hero__copy",children:[e.jsx("span",{className:"booking-details-hero__eyebrow",children:"Booking Record"}),e.jsx("h2",{className:"booking-details-hero__title",children:t.name||"Unnamed Client"}),e.jsx("p",{className:"booking-details-hero__reference",children:t.reference_code||`Booking #${t.id}`})]}),e.jsxs("div",{className:"booking-details-hero__status",children:[k&&e.jsx("button",{type:"button",className:"btn admin-btn--warning",disabled:ge||(t.flags||[]).some(a=>a.status==="OPEN"),onClick:Re,children:ge?"Flagging…":(t.flags||[]).some(a=>a.status==="OPEN")?"Flagged":"Flag booking"}),e.jsx("span",{className:`
                  status-badge
                  status-badge--${t.status}
                `,children:t.status||"UNKNOWN"})]})]}),(t.flags||[]).filter(a=>a.status==="OPEN").map(a=>e.jsx("div",{className:"booking-calendar-error",role:"status",children:e.jsxs("div",{children:[e.jsx("strong",{children:"Oversight warning"}),e.jsx("span",{children:a.reason})]})},a.id||a.reason)),!k&&e.jsxs("section",{className:"booking-details-panel",children:[e.jsx("div",{className:"booking-details-panel__head",children:e.jsxs("div",{className:"booking-details-panel__title-wrap",children:[e.jsx("span",{className:"booking-details-panel__icon",children:e.jsx(la,{size:17})}),e.jsx("h2",{className:"booking-details-panel__title",children:"Booking Status"})]})}),e.jsx("div",{className:"booking-details-panel__body",children:["COMPLETED","CANCELLED"].includes(t.status)?e.jsxs("div",{className:"booking-status-final",children:[e.jsx("span",{className:"booking-status-final__icon",children:e.jsx(W,{size:22})}),e.jsxs("div",{children:[e.jsx("strong",{children:t.status==="COMPLETED"?"This booking is completed.":"This booking request is closed."}),e.jsx("p",{children:t.status==="COMPLETED"?"The service is recorded as completed and remains available in the studio history.":"The request was cancelled and its preferred date is available to the public again."})]})]}):e.jsxs("div",{className:"booking-status-workflow",children:[e.jsxs("div",{className:"booking-status-workflow__intro",children:[e.jsx("span",{children:"Current stage"}),e.jsx("strong",{children:t.status==="CONFIRMED"?"Confirmed booking":t.status==="PENDING"?"Pending client discussion":"New booking request"}),e.jsx("p",{children:t.status==="CONFIRMED"?"This date is booked. If the arrangement is cancelled outside the website, update it here to reopen the date.":t.status==="PENDING"?"You have started handling this request. Confirm or cancel it after speaking with the client.":"The requested date is shown as pending and temporarily unavailable while you contact the client."})]}),e.jsx("div",{className:"booking-status-actions",role:"radiogroup","aria-label":"Final booking outcome",children:(ua[t.status]||[]).map(a=>e.jsxs("button",{type:"button",role:"radio","aria-checked":h===a,className:`booking-status-button ${h===a?"booking-status-button--active":""}`,disabled:$,onClick:()=>{oe(a),H(!1)},children:[e.jsx("span",{children:Ie[a][0]}),e.jsx("small",{children:Ie[a][1]})]},a))}),e.jsxs("label",{className:`booking-final-toggle ${h?"":"booking-final-toggle--disabled"}`,children:[e.jsx("input",{type:"checkbox",checked:V,disabled:!h||$,onChange:a=>H(a.target.checked)}),e.jsx("span",{className:"booking-final-toggle__track","aria-hidden":"true"}),e.jsxs("span",{children:[e.jsx("strong",{children:"I understand this updates the booking calendar."}),e.jsx("small",{children:h==="CANCELLED"?"Cancelling reopens the preferred date publicly.":h==="COMPLETED"?"Completing closes the active workflow but keeps its record.":h==="PENDING"?"Pending keeps the requested date held while you contact the client.":"Confirming marks the date as booked."})]})]}),e.jsxs("button",{type:"button",className:"btn btn--primary booking-status-submit",disabled:!h||!V||$,onClick:qe,children:[e.jsx(W,{size:16}),$?"Updating…":`Update to ${h||"selected status"}`]})]})})]}),e.jsxs("section",{className:"booking-details-panel booking-workflow-panel",children:[e.jsxs("div",{className:"booking-details-panel__head",children:[e.jsxs("div",{className:"booking-details-panel__title-wrap",children:[e.jsx("span",{className:"booking-details-panel__icon",children:e.jsx(De,{size:17})}),e.jsx("h2",{className:"booking-details-panel__title",children:"Agreed Details & Payments"})]}),!k&&!le&&!["COMPLETED","CANCELLED"].includes(t.status)&&e.jsxs("button",{type:"button",className:"btn btn--secondary",onClick:ze,children:[e.jsx(ra,{size:15})," Edit Agreed Details"]})]}),e.jsxs("div",{className:"booking-details-panel__body",children:[le?e.jsxs("form",{className:"booking-action-form",onSubmit:Be,children:[e.jsxs("label",{children:["Agreed service price (₱, whole pesos)",e.jsx("input",{type:"number",min:"1",step:"1",inputMode:"numeric",required:!0,value:l.total,onChange:a=>_({...l,total:a.target.value})})]}),e.jsxs("fieldset",{className:"booking-action-form__wide booking-fee-choice",children:[e.jsx("legend",{children:"Pass platform fee to client"}),e.jsxs("label",{children:[e.jsx("input",{type:"radio",name:"pass_platform_fee",checked:l.pass_platform_fee_to_client===null,onChange:()=>_({...l,pass_platform_fee_to_client:null})})," Use global default (",te.pass_platform_fee_to_client_default?"ON — client pays":"OFF — studio absorbs",")"]}),e.jsxs("label",{children:[e.jsx("input",{type:"radio",name:"pass_platform_fee",checked:l.pass_platform_fee_to_client===!0,onChange:()=>_({...l,pass_platform_fee_to_client:!0})})," ON — add a “Platform service fee” line to the client invoice"]}),e.jsxs("label",{children:[e.jsx("input",{type:"radio",name:"pass_platform_fee",checked:l.pass_platform_fee_to_client===!1,onChange:()=>_({...l,pass_platform_fee_to_client:!1})})," OFF — studio absorbs it; client invoice shows no fee line"]}),e.jsx("small",{children:"The developer fee accrues either way. This choice only changes what the client pays and sees."})]}),e.jsxs("label",{children:["Coverage description",e.jsx("input",{type:"text",maxLength:"160",value:l.coverage,onChange:a=>_({...l,coverage:a.target.value}),placeholder:"Full-day photo and video coverage"})]}),e.jsxs("label",{children:["Coverage hours",e.jsx("input",{type:"number",min:"0.5",max:"24",step:"0.5",value:l.hours,onChange:a=>_({...l,hours:a.target.value})})]}),e.jsxs("label",{children:["Final event date",e.jsx("input",{type:"date",required:!0,value:l.date,onChange:a=>_({...l,date:a.target.value})})]}),e.jsxs("label",{children:["Final location",e.jsx("input",{type:"text",maxLength:"200",value:l.location,onChange:a=>_({...l,location:a.target.value})})]}),e.jsxs("label",{className:"booking-action-form__wide",children:["Add-ons ",e.jsx("small",{children:"One per line: Name | Amount | Quantity"}),e.jsx("textarea",{rows:"4",value:l.addonsText,onChange:a=>_({...l,addonsText:a.target.value}),placeholder:"Printed album | 3500 | 1"})]}),e.jsxs("label",{className:"booking-action-form__wide",children:["Final notes",e.jsx("textarea",{rows:"4",maxLength:"2000",value:l.notes,onChange:a=>_({...l,notes:a.target.value})})]}),e.jsxs("div",{className:"booking-action-form__wide booking-fee-preview",children:["Platform fee (",U(D.feeRate),"): ",e.jsx("strong",{children:i(D.feeAmount)})," ",xe==="CLIENT"?"— added to the client total.":"— absorbed by the studio, not charged to the client.",e.jsx("br",{}),"Client total: ",e.jsx("strong",{children:i(D.clientTotal)})," · Required down payment (50%): ",e.jsx("strong",{children:i(D.requiredDownPayment)})," · Balance after down payment: ",e.jsx("strong",{children:i(D.clientTotal-D.requiredDownPayment)})]}),e.jsxs("div",{className:"booking-action-form__actions",children:[e.jsx("button",{type:"button",className:"btn btn--secondary",onClick:()=>K(!1),disabled:X,children:"Cancel"}),e.jsx("button",{type:"submit",className:"btn btn--primary",disabled:X,children:X?"Saving…":"Save agreed details"})]})]}):t.agreed_details?e.jsxs("div",{className:"booking-confirmed-summary",children:[e.jsxs("div",{children:[e.jsx("span",{children:"Agreed service price"}),e.jsx("strong",{children:i((n==null?void 0:n.service_total)??t.agreed_details.total)})]}),e.jsxs("div",{children:[e.jsx("span",{children:"Platform fee"}),e.jsxs("strong",{children:[i((n==null?void 0:n.fee_amount)||0)," · ",U(n==null?void 0:n.fee_rate)," · ",oa[n==null?void 0:n.fee_responsibility]||"—",n&&!n.fee_responsibility_set?" (earlier booking — not yet chosen)":""]})]}),e.jsxs("div",{children:[e.jsx("span",{children:"Client total"}),e.jsx("strong",{children:i((n==null?void 0:n.client_total)??t.agreed_details.total)})]}),e.jsxs("div",{children:[e.jsx("span",{children:"Required down payment (50%)"}),e.jsx("strong",{children:i(P)})]}),e.jsxs("div",{children:[e.jsx("span",{children:"Received so far"}),e.jsx("strong",{children:i((n==null?void 0:n.total_paid)??t.total_paid??0)})]}),e.jsxs("div",{children:[e.jsx("span",{children:"Balance due"}),e.jsx("strong",{children:i(E)})]}),e.jsxs("div",{children:[e.jsx("span",{children:"Coverage"}),e.jsxs("strong",{children:[t.agreed_details.coverage||"—",t.agreed_details.hours?` · ${t.agreed_details.hours} hours`:""]})]}),e.jsxs("div",{children:[e.jsx("span",{children:"Final date"}),e.jsx("strong",{children:B(t.agreed_details.date)})]}),e.jsxs("div",{children:[e.jsx("span",{children:"Location"}),e.jsx("strong",{children:t.agreed_details.location||"—"})]}),e.jsxs("div",{children:[e.jsx("span",{children:"Last updated"}),e.jsx("strong",{children:t.agreed_details_updated_at?Y(t.agreed_details_updated_at):"—"})]}),(t.agreed_details.addons||[]).length>0&&e.jsxs("div",{className:"booking-confirmed-summary__wide",children:[e.jsx("span",{children:"Add-ons"}),e.jsx("strong",{children:t.agreed_details.addons.map(a=>`${a.quantity||1}× ${a.label}`).join(", ")})]}),t.agreed_details.notes&&e.jsxs("div",{className:"booking-confirmed-summary__wide",children:[e.jsx("span",{children:"Notes"}),e.jsx("strong",{children:t.agreed_details.notes})]})]}):e.jsx("p",{className:"booking-workflow-note",children:"No final terms have been recorded. The original client estimate remains unchanged."}),e.jsx("div",{className:"booking-stage-timeline","aria-label":"Booking payment timeline",children:["Requested","Confirmed","Down payment invoice sent","Paid in full invoice sent"].map((a,s)=>{const o=s===0||s===1&&["CONFIRMED","COMPLETED"].includes(t.status)||s===2&&S&&ae||s===3&&ee&&Ve;return e.jsxs("span",{className:o?"is-complete":"",children:[e.jsx("i",{}),a]},a)})}),!k&&t.status==="CONFIRMED"&&t.agreed_details&&!ee&&Ke&&!de&&e.jsxs("button",{type:"button",className:"btn btn--primary booking-payment-button",onClick:()=>{R({amount:C==="FINAL_PAYMENT"?String(E):P&&P<=fe?String(P):"",date:new Date().toISOString().slice(0,10),note:""}),O(!0)},children:[e.jsx(ha,{size:16})," ",He]}),S&&!ae&&e.jsx("p",{className:"booking-workflow-note",children:"Send the active down-payment invoice before recording the final payment."}),!k&&de&&e.jsxs("form",{className:"booking-action-form booking-payment-form",onSubmit:Ye,children:[e.jsxs("label",{children:[C==="FINAL_PAYMENT"?"Final payment received (₱)":"Down payment received (₱)",e.jsx("input",{type:"number",step:"1",inputMode:"numeric",min:ke,max:se,required:!0,readOnly:C==="FINAL_PAYMENT",value:u.amount,onChange:a=>R({...u,amount:a.target.value})}),e.jsx("small",{children:C==="FINAL_PAYMENT"?`Must equal the remaining balance of ${i(E)}.`:ve?`Required: at least ${i(P)} (50% of ${i((n==null?void 0:n.client_total)??0)}), at most ${i(se)}. Enter the amount actually received, in whole pesos.`:"This client total is too small to split into a down payment and a final payment."})]}),e.jsxs("label",{children:["Date received",e.jsx("input",{type:"date",required:!0,value:u.date,onChange:a=>R({...u,date:a.target.value})})]}),e.jsxs("label",{className:"booking-action-form__wide",children:["Optional note",e.jsx("textarea",{maxLength:"500",rows:"3",value:u.note,onChange:a=>R({...u,note:a.target.value})})]}),e.jsxs("div",{className:"booking-action-form__actions",children:[e.jsx("button",{type:"button",className:"btn btn--secondary",onClick:()=>O(!1),disabled:N,children:"Cancel"}),e.jsxs("button",{type:"submit",className:"btn btn--primary",disabled:N||!ve,children:[e.jsx(Ce,{size:15})," Preview invoice"]})]})]}),q.length>0&&e.jsx("div",{className:"booking-invoice-list",children:q.map(a=>e.jsxs("article",{className:a.voided_at?"is-voided":"",children:[e.jsxs("div",{children:[e.jsx("span",{children:a.invoice_type==="FINAL_PAYMENT"?"Final receipt":"Down payment invoice"}),e.jsx("strong",{children:a.invoice_number}),e.jsx("small",{children:a.voided_at?"Voided — preserved snapshot":a.sent_at?`Sent ${Y(a.sent_at)}`:"Draft — ready to preview"})]}),e.jsxs("div",{children:[e.jsxs("button",{type:"button",className:"btn admin-btn--neutral",onClick:()=>T(a),children:[e.jsx(Ce,{size:15})," Preview"]}),e.jsxs("button",{type:"button",className:"btn btn--secondary",onClick:()=>We(a),children:[e.jsx(da,{size:15})," PDF"]}),!k&&!a.voided_at&&e.jsxs("button",{type:"button",className:"btn btn--secondary",onClick:()=>Ge(a.id),disabled:Se,children:[e.jsx(ca,{size:15})," ",a.sent_at?"Resend":"Send"]})]})]},a.id))})]})]}),d&&e.jsx("div",{className:"invoice-preview-modal",role:"presentation",onMouseDown:()=>!N&&T(null),children:e.jsxs("section",{ref:Le,tabIndex:-1,role:"dialog","aria-modal":"true","aria-label":"Invoice preview",onMouseDown:a=>a.stopPropagation(),children:[e.jsx("span",{className:"booking-details-panel__title",children:"Invoice preview"}),e.jsx("h2",{children:d.draftPayment?d.payment_type==="FINAL_PAYMENT"?"PAID IN FULL receipt":"Down payment invoice":`${d.invoice_number}${d.voided_at?" — VOID":""}`}),(()=>{var f,I;const a=d.draftPayment?null:d.snapshot||{},s=a?a.agreed_details||{}:t.agreed_details||{},o=a?a.platform_fee||{}:{rate:n==null?void 0:n.fee_rate,amount:n==null?void 0:n.fee_amount,charged_to_client:(n==null?void 0:n.fee_responsibility)==="CLIENT",responsibility:n==null?void 0:n.fee_responsibility},r=a?a.service_total:n==null?void 0:n.service_total,x=a?a.agreed_total:n==null?void 0:n.client_total;return e.jsxs("p",{children:[d.voided_at&&e.jsxs(e.Fragment,{children:[e.jsx("strong",{children:"Voided:"})," this is the preserved copy of what was issued.",e.jsx("br",{})]}),e.jsx("strong",{children:"Client:"})," ",((f=a==null?void 0:a.client)==null?void 0:f.name)||t.name,e.jsx("br",{}),e.jsx("strong",{children:"Package:"})," ",((I=a==null?void 0:a.booking)==null?void 0:I.shoot_type)||t.shoot_type,e.jsx("br",{}),e.jsx("strong",{children:"Coverage:"})," ",s.coverage||"—",s.hours?` · ${s.hours} hours`:"",e.jsx("br",{}),e.jsx("strong",{children:"Add-ons:"})," ",(s.addons||[]).map(j=>`${j.quantity||1}× ${j.label}`).join(", ")||"None",e.jsx("br",{}),r!=null&&e.jsxs(e.Fragment,{children:[e.jsx("strong",{children:"Agreed service price:"})," ",i(r),e.jsx("br",{})]}),o.responsibility&&e.jsxs(e.Fragment,{children:[e.jsxs("strong",{children:["Platform fee (",U(o.rate),"):"]})," ",i(o.amount)," — ",o.charged_to_client?"paid by the client (included in total)":"absorbed by the studio (not charged to the client)",e.jsx("br",{})]}),e.jsxs("strong",{children:[r!=null?"Total payable":"Agreed total",":"]})," ",i(x||0)]})})(),d.draftPayment?e.jsxs("p",{children:[d.payment_type==="DOWN_PAYMENT"&&e.jsxs(e.Fragment,{children:[e.jsx("strong",{children:"Required down payment (50%):"})," ",i(P),e.jsx("br",{})]}),e.jsx("strong",{children:"Amount received:"})," ",i(d.amount)," on ",B(d.date),e.jsx("br",{}),e.jsx("strong",{children:"Balance afterward:"})," ",i(Math.max(0,E-d.amount))]}):e.jsxs("p",{children:[e.jsx("strong",{children:"Status:"})," ",d.snapshot.status_label,d.snapshot.required_down_payment!==void 0&&d.invoice_type==="DOWN_PAYMENT"?e.jsxs(e.Fragment,{children:[e.jsx("br",{}),e.jsx("strong",{children:"Required down payment (50%):"})," ",i(d.snapshot.required_down_payment)]}):null,e.jsx("br",{}),e.jsx("strong",{children:"Paid:"})," ",i(d.snapshot.total_paid),e.jsx("br",{}),e.jsx("strong",{children:"Balance:"})," ",i(d.snapshot.balance_due)]}),e.jsxs("div",{className:"booking-action-form__actions",children:[e.jsx("button",{type:"button",className:"btn btn--secondary",disabled:N,onClick:()=>T(null),children:"Close"}),d.draftPayment&&e.jsx("button",{type:"button",className:"btn btn--primary",disabled:N,onClick:Ue,children:N?"Recording…":"Confirm, record & email"})]})]})}),e.jsxs("div",{className:"booking-details-columns",children:[e.jsxs("section",{className:"booking-details-panel",children:[e.jsxs("div",{className:"booking-details-panel__head",children:[e.jsxs("div",{className:"booking-details-panel__title-wrap",children:[e.jsx("span",{className:"booking-details-panel__icon",children:e.jsx(Ee,{size:17})}),e.jsx("h2",{className:"booking-details-panel__title",children:"Client"})]}),k&&t.contact_masked&&e.jsx("button",{type:"button",className:"btn admin-btn--secondary","aria-describedby":"contact-reveal-note",disabled:J,onClick:Fe,children:J?"Revealing…":"Reveal contact details"})]}),e.jsxs("div",{className:"booking-details-panel__body",children:[k&&t.contact_masked&&e.jsx("p",{className:"contact-reveal-note",id:"contact-reveal-note",children:"Contact details are masked. Revealing them is recorded in the Owner-visible access log."}),e.jsxs("div",{className:"booking-info-grid",children:[e.jsxs("div",{className:"booking-info-item",children:[e.jsxs("div",{className:"booking-info-item__label",children:[e.jsx(Ee,{size:14}),"Name"]}),e.jsx("p",{className:"booking-info-item__value",children:t.name||"—"})]}),e.jsxs("div",{className:"booking-info-item",children:[e.jsxs("div",{className:"booking-info-item__label",children:[e.jsx(pa,{size:14}),"Email"]}),e.jsx("p",{className:"booking-info-item__value",children:t.email?e.jsx("a",{href:`mailto:${t.email}`,children:t.email}):"—"})]}),e.jsxs("div",{className:"booking-info-item",children:[e.jsxs("div",{className:"booking-info-item__label",children:[e.jsx(ga,{size:14}),"Phone"]}),e.jsx("p",{className:"booking-info-item__value",children:t.phone?e.jsx("a",{href:`tel:${t.phone}`,children:t.phone}):"—"})]}),e.jsxs("div",{className:"booking-info-item",children:[e.jsxs("div",{className:"booking-info-item__label",children:[e.jsx(ma,{size:14}),"Facebook"]}),e.jsx("p",{className:"booking-info-item__value",children:t.facebook||"—"})]})]})]})]}),e.jsxs("section",{className:"booking-details-panel",children:[e.jsx("div",{className:"booking-details-panel__head",children:e.jsxs("div",{className:"booking-details-panel__title-wrap",children:[e.jsx("span",{className:"booking-details-panel__icon",children:e.jsx(Ne,{size:17})}),e.jsx("h2",{className:"booking-details-panel__title",children:"Shoot"})]})}),e.jsx("div",{className:"booking-details-panel__body",children:e.jsxs("div",{className:"booking-info-grid",children:[e.jsxs("div",{className:"booking-info-item",children:[e.jsxs("div",{className:"booking-info-item__label",children:[e.jsx(Ne,{size:14}),"Type"]}),e.jsx("p",{className:"booking-info-item__value",children:t.shoot_type||"—"})]}),e.jsxs("div",{className:"booking-info-item",children:[e.jsxs("div",{className:"booking-info-item__label",children:[e.jsx(Pe,{size:14}),"Date"]}),e.jsxs("p",{className:"booking-info-item__value",children:[t.preferred_date?B(t.preferred_date):"Not specified",t.preferred_time&&` · ${new Date(`2000-01-01T${t.preferred_time}`).toLocaleTimeString([],{hour:"numeric",minute:"2-digit"})}`]})]}),e.jsxs("div",{className:"booking-info-item",children:[e.jsxs("div",{className:"booking-info-item__label",children:[e.jsx(ba,{size:14}),"Location"]}),e.jsx("p",{className:"booking-info-item__value",children:t.location||"—"})]}),e.jsxs("div",{className:"booking-info-item",children:[e.jsxs("div",{className:"booking-info-item__label",children:[e.jsx(_a,{size:14}),"Guests"]}),e.jsx("p",{className:"booking-info-item__value",children:t.guest_count||"—"})]})]})}),e.jsx("div",{className:"booking-details-panel__body",children:e.jsxs("div",{className:"booking-message",children:[e.jsxs("div",{className:"booking-message__label",children:[e.jsx(Te,{size:14}),"Message"]}),e.jsx("p",{className:"booking-message__text",children:t.message||"No message provided."})]})})]})]}),e.jsxs("section",{className:"booking-details-panel",children:[e.jsx("div",{className:"booking-details-panel__head",children:e.jsxs("div",{className:"booking-details-panel__title-wrap",children:[e.jsx("span",{className:"booking-details-panel__icon",children:e.jsx(Te,{size:17})}),e.jsx("h2",{className:"booking-details-panel__title",children:"Response Templates"})]})}),e.jsxs("div",{className:"booking-details-panel__body",children:[e.jsx("p",{className:"booking-workflow-note",children:"Copy a clear response, then send it through the client’s preferred contact channel. No message is sent automatically."}),e.jsxs("div",{className:"booking-template-actions",children:[e.jsx("button",{type:"button",className:"btn admin-btn--neutral",onClick:()=>Q("acknowledge"),children:"Copy acknowledgement"}),e.jsx("button",{type:"button",className:"btn admin-btn--neutral",onClick:()=>Q("confirm"),children:"Copy confirmation"}),e.jsx("button",{type:"button",className:"btn admin-btn--neutral",onClick:()=>Q("cancel"),children:"Copy cancellation"})]})]})]}),t.estimate_total&&e.jsxs("section",{className:"booking-details-panel",children:[e.jsxs("div",{className:"booking-details-panel__head",children:[e.jsxs("div",{className:"booking-details-panel__title-wrap",children:[e.jsx("span",{className:"booking-details-panel__icon",children:e.jsx(De,{size:17})}),e.jsx("h2",{className:"booking-details-panel__title",children:"Estimate"})]}),e.jsx("strong",{children:i(t.estimate_total)})]}),e.jsx("div",{className:"booking-details-panel__body",children:e.jsxs("div",{className:"booking-estimate-list",children:[Z.length>0&&Z.map((a,s)=>e.jsxs("div",{className:"booking-estimate-row",children:[e.jsx("span",{className:"booking-estimate-row__label",children:a.label||"Add-on"}),e.jsx("span",{className:"booking-estimate-row__price",children:i(a.price)})]},a.label||`addon-${s}`)),Z.length===0&&e.jsxs("div",{className:"booking-estimate-row",children:[e.jsx("span",{className:"booking-estimate-row__label",children:"No itemized add-ons"}),e.jsx("span",{className:"booking-estimate-row__price",children:"—"})]}),e.jsxs("div",{className:"booking-estimate-total",children:[e.jsx("span",{className:"booking-estimate-total__label",children:"Total"}),e.jsx("span",{className:"booking-estimate-total__price",children:i(t.estimate_total)})]})]})})]}),e.jsxs("section",{className:"booking-details-panel",children:[e.jsx("div",{className:"booking-details-panel__head",children:e.jsxs("div",{className:"booking-details-panel__title-wrap",children:[e.jsx("span",{className:"booking-details-panel__icon",children:e.jsx(Ae,{size:17})}),e.jsx("h2",{className:"booking-details-panel__title",children:"Metadata"})]})}),e.jsx("div",{className:"booking-details-panel__body",children:e.jsxs("div",{className:"booking-info-grid",children:[e.jsxs("div",{className:"booking-info-item",children:[e.jsxs("div",{className:"booking-info-item__label",children:[e.jsx(Ae,{size:14}),"Booking ID"]}),e.jsxs("p",{className:"booking-info-item__value",children:["#",t.id]})]}),e.jsxs("div",{className:"booking-info-item",children:[e.jsxs("div",{className:"booking-info-item__label",children:[e.jsx(Pe,{size:14}),"Submitted"]}),e.jsx("p",{className:"booking-info-item__value",children:Y(t.created_at)})]}),e.jsxs("div",{className:"booking-info-item",children:[e.jsxs("div",{className:"booking-info-item__label",children:[e.jsx(W,{size:14}),"Privacy Consent"]}),e.jsx("p",{className:"booking-info-item__value",children:e.jsx("span",{className:`
                        booking-consent
                        ${t.privacy_agreed?"booking-consent--yes":"booking-consent--no"}
                      `,children:e.jsx("span",{children:t.privacy_agreed?"Agreed":"Not agreed"})})})]}),e.jsxs("div",{className:"booking-info-item",children:[e.jsxs("div",{className:"booking-info-item__label",children:[e.jsx(W,{size:14}),"Consent Timestamp"]}),e.jsx("p",{className:"booking-info-item__value",children:t.privacy_agreed_at?Y(t.privacy_agreed_at):"—"})]})]})})]})]})})]})}export{$a as default};
