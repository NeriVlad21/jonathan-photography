import{l as O,r,j as t,e as P,H as A,n as m}from"./index-DwFWKgCp.js";import{E as L,M as F}from"./Modal-AV3B6CNC.js";import{P as v}from"./pencil-BCcqf4qL.js";import{P as D}from"./plus-DsDCHajR.js";import{S as R}from"./save-DB8M_m-f.js";import{L as y,I as M}from"./link-DF4fV0h5.js";import{E as z}from"./eye-BdeqD93h.js";import{T as $}from"./trash-2-BOkEWldz.js";import{M as H}from"./mail-DSclWBKU.js";import{P as U}from"./phone-9k874mB0.js";import{F as V}from"./facebook-BlWrM3oW.js";const j={label:"",tagline:"",handle:"",link:"",icon:"link"},W=["instagram","facebook","phone","mail","link"];function at(){const{showToast:o}=O(),[n,b]=r.useState(null),[l,h]=r.useState(j),[i,_]=r.useState(null),[s,g]=r.useState(null),[f,u]=r.useState(!1),[N,w]=r.useState(null),p=()=>{m.list(!0).then(e=>{b(Array.isArray(e)?e:[])}).catch(()=>{b([])})};r.useEffect(()=>{document.title="Admin — Contact Links",p()},[]);const d=(e,a)=>{h(c=>({...c,[e]:a}))},k=e=>{_(e.id),h({label:e.label||"",tagline:e.tagline||"",handle:e.handle||"",link:e.link||"",icon:e.icon||"link"}),window.scrollTo({top:0,behavior:"smooth"})},x=()=>{_(null),h(j)},C=async e=>{e.preventDefault(),u(!0);try{if(i){const a=n==null?void 0:n.find(c=>c.id===i);await m.update({id:i,...l,visible:(a==null?void 0:a.visible)??1}),o("Contact platform updated.")}else await m.create(l),o("Contact platform added.");x(),p()}catch(a){o((a==null?void 0:a.message)||"Unable to save contact platform.","error")}finally{u(!1)}},E=async e=>{w(e.id);try{await m.update({...e,visible:e.visible?0:1}),o(e.visible?"Platform hidden from the public site.":"Platform is now visible on the public site."),p()}catch(a){o((a==null?void 0:a.message)||"Unable to update visibility.","error")}finally{w(null)}},I=async()=>{if(s)try{await m.remove(s.id),o("Contact platform deleted."),i===s.id&&x(),g(null),p()}catch(e){o((e==null?void 0:e.message)||"Unable to delete contact platform.","error")}},S=e=>{switch(e){case"instagram":return M;case"facebook":return V;case"phone":return U;case"mail":return H;default:return y}};return t.jsxs(t.Fragment,{children:[t.jsx("style",{children:`

        /*
        ============================================================
        CONTACT MANAGER
        ============================================================
        */

        .contact-manager-page {
          width: 100%;
        }

        .contact-manager-content {
          width: 100%;

          max-width:
            1050px;
        }

        /*
        ============================================================
        INTRO
        ============================================================
        */

        .contact-manager-intro {
          display: flex;

          align-items: flex-start;
          justify-content: space-between;

          gap: 20px;

          margin-bottom:
            20px;
        }

        .contact-manager-intro__copy {
          min-width: 0;
        }

        .contact-manager-intro__title {
          margin: 0;
        }

        .contact-manager-intro__text {
          margin:
            5px 0 0;

          color:
            var(--c-gray);

          max-width:
            60ch;
        }

        /*
        ============================================================
        EDITOR PANEL
        ============================================================
        */

        .contact-editor {
          margin-bottom:
            20px;

          border:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            var(--c-bg, #fff);
        }

        .contact-editor__head {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap: 15px;

          padding:
            17px 20px;

          border-bottom:
            1px solid
            var(--c-hairline, #e5e5e5);
        }

        .contact-editor__title-wrap {
          display: flex;

          align-items: center;

          gap: 9px;

          min-width: 0;
        }

        .contact-editor__icon {
          display: inline-flex;

          align-items: center;
          justify-content: center;

          width: 30px;
          height: 30px;

          flex: 0 0 30px;

          border-radius:
            7px;

          background:
            #111;

          color:
            #fff;
        }

        .contact-editor__title {
          margin: 0;
        }

        .contact-editor__body {
          padding:
            20px;
        }

        /*
        ============================================================
        FORM
        ============================================================
        */

        .contact-form-grid {
          display: grid;

          grid-template-columns:
            repeat(
              2,
              minmax(0, 1fr)
            );

          gap:
            17px 20px;
        }

        .contact-form-field {
          min-width: 0;
        }

        .contact-form-field--full {
          grid-column:
            1 / -1;
        }

        .contact-form-actions {
          display: flex;

          align-items: center;

          gap: 8px;

          margin-top:
            20px;
        }

        .contact-save-button {
          display: inline-flex;

          align-items: center;

          justify-content: center;

          gap: 7px;
        }

        /*
        ============================================================
        LIST HEADER
        ============================================================
        */

        .contact-list-panel {
          overflow: hidden;

          border:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            var(--c-bg, #fff);
        }

        .contact-list-header {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap: 15px;

          padding:
            17px 20px;

          border-bottom:
            1px solid
            var(--c-hairline, #e5e5e5);
        }

        .contact-list-header__title {
          margin: 0;
        }

        .contact-list-header__count {
          color:
            var(--c-gray);
        }

        /*
        ============================================================
        CONTACT ROW
        ============================================================
        */

        .contact-list {
          display: flex;

          flex-direction: column;
        }

        .contact-row {
          display: grid;

          grid-template-columns:
            minmax(170px, 1.1fr)
            minmax(180px, 1fr)
            minmax(220px, 1.2fr)
            auto;

          align-items: center;

          gap: 18px;

          padding:
            16px 20px;

          border-bottom:
            1px solid
            var(--c-hairline, #ededed);

          transition:
            background 0.18s ease;
        }

        .contact-row:last-child {
          border-bottom: 0;
        }

        .contact-row:hover {
          background:
            #fafafa;
        }

        /*
        ============================================================
        PLATFORM
        ============================================================
        */

        .contact-row__platform {
          display: flex;

          align-items: center;

          gap: 11px;

          min-width: 0;
        }

        .contact-row__icon {
          display: inline-flex;

          align-items: center;
          justify-content: center;

          width: 38px;
          height: 38px;

          flex: 0 0 38px;

          border:
            1px solid
            var(--c-hairline, #e0e0e0);

          border-radius:
            9px;

          background:
            #f7f7f7;

          color:
            var(--c-text);
        }

        .contact-row__platform-copy {
          min-width: 0;
        }

        .contact-row__label {
          overflow: hidden;

          text-overflow: ellipsis;

          white-space: nowrap;
        }

        .contact-row__handle {
          margin-top:
            3px;

          overflow: hidden;

          text-overflow: ellipsis;

          white-space: nowrap;

          color:
            var(--c-gray);
        }

        /*
        ============================================================
        TAGLINE
        ============================================================
        */

        .contact-row__tagline {
          min-width: 0;

          color:
            var(--c-gray);

          line-height:
            1.45;
        }

        /*
        ============================================================
        LINK
        ============================================================
        */

        .contact-row__link {
          min-width: 0;

          display: flex;

          align-items: center;

          gap: 6px;

          color:
            var(--c-text);

          text-decoration:
            none;
        }

        .contact-row__link-text {
          overflow: hidden;

          text-overflow: ellipsis;

          white-space: nowrap;
        }

        .contact-row__link:hover
        .contact-row__link-text {
          text-decoration:
            underline;
        }

        .contact-row__external {
          flex: 0 0 auto;

          color:
            #999;
        }

        /*
        ============================================================
        ROW ACTIONS
        ============================================================
        */

        .contact-row__actions {
          display: flex;

          align-items: center;

          justify-content: flex-end;

          gap: 7px;
        }

        .contact-row__visibility {
          display: inline-flex;

          align-items: center;

          justify-content: center;

          width: 34px;
          height: 34px;

          padding: 0;

          border:
            1px solid
            #d8d8d8;

          border-radius:
            7px;

          background:
            #fff;

          color:
            #777;

          cursor:
            pointer;

          transition:
            background 0.18s ease,
            color 0.18s ease,
            border-color 0.18s ease;
        }

        .contact-row__visibility:hover:not(:disabled) {
          background:
            #f2f2f2;

          color:
            var(--c-text);

          border-color:
            #c5c5c5;
        }

        .contact-row__visibility:disabled {
          cursor:
            wait;

          opacity:
            0.55;
        }

        .contact-row__visibility--visible {
          color:
            #2d7448;
        }

        .contact-row__edit,
        .contact-row__delete {
          display: inline-flex;

          align-items: center;

          justify-content: center;

          gap: 6px;

          min-height:
            34px;

          padding:
            0 10px;
        }

        .contact-row__delete {
          color:
            #b3261e;

          border-color:
            rgba(
              179,
              38,
              30,
              0.35
            );
        }

        .contact-row__delete:hover {
          color:
            #a51f19;

          border-color:
            #b3261e;

          background:
            rgba(
              179,
              38,
              30,
              0.04
            );
        }

        /*
        ============================================================
        MOBILE ROW
        ============================================================
        */

        .contact-row__mobile-meta {
          display: none;
        }

        /*
        ============================================================
        EMPTY
        ============================================================
        */

        .contact-empty {
          padding:
            45px 25px;

          text-align:
            center;

          color:
            var(--c-gray);
        }

        .contact-empty__icon {
          display: flex;

          align-items: center;
          justify-content: center;

          width: 44px;
          height: 44px;

          margin:
            0 auto 12px;

          border-radius:
            50%;

          background:
            #f1f1f1;

          color:
            #777;
        }

        .contact-empty__title {
          margin:
            0 0 5px;

          color:
            var(--c-text);
        }

        .contact-empty__text {
          margin:
            0;
        }

        /*
        ============================================================
        RESPONSIVE
        ============================================================
        */

        @media (max-width: 1000px) {

          .contact-row {
            grid-template-columns:
              minmax(160px, 1fr)
              minmax(180px, 1.2fr)
              auto;
          }

          .contact-row__tagline {
            display: none;
          }

        }

        @media (max-width: 760px) {

          .contact-form-grid {
            grid-template-columns:
              1fr;
          }

          .contact-form-field--full {
            grid-column:
              auto;
          }

          .contact-row {
            display: flex;

            align-items:
              flex-start;

            flex-direction:
              column;

            gap:
              12px;

            padding:
              16px;
          }

          .contact-row__platform,
          .contact-row__tagline,
          .contact-row__link {
            width:
              100%;
          }

          .contact-row__tagline {
            display: block;
          }

          .contact-row__actions {
            width:
              100%;

            justify-content:
              flex-start;

            flex-wrap:
              wrap;
          }

          .contact-row__visibility {
            margin-right:
              auto;
          }

        }

        @media (max-width: 500px) {

          .contact-editor__head,
          .contact-editor__body,
          .contact-list-header {
            padding:
              15px;
          }

          .contact-form-actions {
            align-items:
              stretch;

            flex-direction:
              column;
          }

          .contact-form-actions .btn {
            width:
              100%;
          }

          .contact-list-header {
            align-items:
              flex-start;

            flex-direction:
              column;

            gap:
              4px;
          }

        }

        /*
        ============================================================
        REDUCED MOTION
        ============================================================
        */

        @media (
          prefers-reduced-motion: reduce
        ) {

          .contact-row,
          .contact-row__visibility {
            transition:
              none;
          }

        }

      `}),t.jsx("section",{className:"contact-manager-page",children:t.jsxs("div",{className:"admin-content contact-manager-content",children:[t.jsxs("div",{className:"contact-editor",children:[t.jsxs("div",{className:"contact-editor__head",children:[t.jsxs("div",{className:"contact-editor__title-wrap",children:[t.jsx("span",{className:"contact-editor__icon",children:i?t.jsx(v,{size:15}):t.jsx(D,{size:15})}),t.jsx("h2",{className:"contact-editor__title",children:i?"Edit Platform":"Add a Platform"})]}),i&&t.jsx("button",{type:"button",className:`
                    btn
                    btn--ghost-light
                    btn--sm
                  `,onClick:x,children:"Cancel"})]}),t.jsxs("form",{className:"contact-editor__body",onSubmit:C,children:[t.jsxs("div",{className:"contact-form-grid",children:[t.jsxs("div",{className:"field contact-form-field",children:[t.jsx("label",{htmlFor:"c-label",children:"Label"}),t.jsx("input",{id:"c-label",type:"text",required:!0,value:l.label,onChange:e=>d("label",e.target.value),placeholder:"Instagram"})]}),t.jsxs("div",{className:"field contact-form-field",children:[t.jsx("label",{htmlFor:"c-icon",children:"Icon"}),t.jsx("select",{id:"c-icon",value:l.icon,onChange:e=>d("icon",e.target.value),children:W.map(e=>t.jsx("option",{value:e,children:e},e))})]}),t.jsxs("div",{className:"field contact-form-field",children:[t.jsx("label",{htmlFor:"c-handle",children:"Handle"}),t.jsx("input",{id:"c-handle",type:"text",value:l.handle,onChange:e=>d("handle",e.target.value),placeholder:"@jonathanphotography"})]}),t.jsxs("div",{className:"field contact-form-field",children:[t.jsx("label",{htmlFor:"c-link",children:"Link"}),t.jsx("input",{id:"c-link",type:"url",required:!0,value:l.link,onChange:e=>d("link",e.target.value),placeholder:"https://instagram.com/..."})]}),t.jsxs("div",{className:"field contact-form-field contact-form-field--full",children:[t.jsx("label",{htmlFor:"c-tagline",children:"Tagline"}),t.jsx("input",{id:"c-tagline",type:"text",value:l.tagline,onChange:e=>d("tagline",e.target.value),placeholder:"See what we're currently obsessed with."})]})]}),t.jsxs("div",{className:"contact-form-actions",children:[t.jsxs("button",{type:"submit",className:`
                    btn
                    btn--primary
                    btn--sm
                    contact-save-button
                  `,disabled:f,children:[t.jsx(R,{size:14}),f?"Saving…":i?"Save Changes":"Add Platform"]}),i&&t.jsx("button",{type:"button",className:`
                      btn
                      btn--ghost-light
                      btn--sm
                    `,onClick:x,disabled:f,children:"Cancel"})]})]})]}),n===null&&t.jsx(P,{label:"Loading contact links…"}),n!==null&&t.jsxs("div",{className:"contact-list-panel",children:[t.jsxs("div",{className:"contact-list-header",children:[t.jsx("h2",{className:"contact-list-header__title",children:"Contact Platforms"}),t.jsxs("span",{className:"contact-list-header__count",children:[n.length," ",n.length===1?"platform":"platforms"]})]}),n.length===0?t.jsxs("div",{className:"contact-empty",children:[t.jsx("div",{className:"contact-empty__icon",children:t.jsx(y,{size:19})}),t.jsx("h3",{className:"contact-empty__title",children:"No contact platforms yet"}),t.jsx("p",{className:"contact-empty__text",children:"Add your first social or contact link above."})]}):t.jsx("div",{className:"contact-list",children:n.map(e=>{const a=S(e.icon),c=!!e.visible;return t.jsxs("div",{className:"contact-row",children:[t.jsxs("div",{className:"contact-row__platform",children:[t.jsx("span",{className:"contact-row__icon",children:t.jsx(a,{size:17})}),t.jsxs("div",{className:"contact-row__platform-copy",children:[t.jsx("div",{className:"contact-row__label",children:e.label||"Untitled"}),e.handle&&t.jsx("div",{className:"contact-row__handle",children:e.handle})]})]}),t.jsx("div",{className:"contact-row__tagline",children:e.tagline||"No tagline set."}),t.jsxs("a",{href:e.link||"#",target:"_blank",rel:"noreferrer",className:"contact-row__link",onClick:T=>{e.link||T.preventDefault()},title:e.link||"No link",children:[t.jsx("span",{className:"contact-row__link-text",children:e.link||"No link"}),e.link&&t.jsx(A,{size:14,className:"contact-row__external"})]}),t.jsxs("div",{className:"contact-row__actions",children:[t.jsx("button",{type:"button",className:`
                                contact-row__visibility
                                ${c?"contact-row__visibility--visible":""}
                              `,onClick:()=>E(e),disabled:N===e.id,"aria-label":c?`Hide ${e.label}`:`Show ${e.label}`,title:c?"Visible on public site":"Hidden from public site",children:c?t.jsx(z,{size:15}):t.jsx(L,{size:15})}),t.jsxs("button",{type:"button",className:`
                                btn
                                btn--ghost-light
                                btn--sm
                                contact-row__edit
                              `,onClick:()=>k(e),children:[t.jsx(v,{size:13}),"Edit"]}),t.jsx("button",{type:"button",className:`
                                btn
                                btn--sm
                                contact-row__delete
                              `,onClick:()=>g(e),"aria-label":`Delete ${e.label}`,title:`Delete ${e.label}`,children:t.jsx($,{size:13})})]})]},e.id)})})]})]})}),s&&t.jsx(F,{title:`Delete "${s.label}"?`,body:"It will disappear from the public site immediately.",confirmLabel:"Delete",danger:!0,onConfirm:I,onClose:()=>g(null)})]})}export{at as default};
