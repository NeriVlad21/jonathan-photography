import{i as g,q as y,h as v,r as o,j as i,N}from"./index-ZwdCBnk2.js";import{U as j}from"./user-Cllqh9M3.js";/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=g("ArrowRight",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=g("LockKeyhole",[["circle",{cx:"12",cy:"16",r:"1",key:"1au0dj"}],["rect",{x:"3",y:"10",width:"18",height:"12",rx:"2",key:"6s8ecr"}],["path",{d:"M7 10V7a5 5 0 0 1 10 0v3",key:"1pqi11"}]]);function E(){const{admin:s,login:u}=y(),x=v(),[t,h]=o.useState(""),[d,b]=o.useState(""),[r,n]=o.useState(""),[l,m]=o.useState(!1);if(o.useEffect(()=>{document.title="Admin — Sign In"},[]),s)return i.jsx(N,{to:s.must_change_password?"/admin/profile":s.role==="SUPER_ADMIN"?"/admin/super-admin":"/admin/dashboard",replace:!0});const f=async e=>{var c,p;if(e.preventDefault(),n(""),!t.trim()||!d){n("Please enter your username and password.");return}m(!0);try{const a=await u(t.trim(),d);x((c=a.admin)!=null&&c.must_change_password?"/admin/profile":((p=a.admin)==null?void 0:p.role)==="SUPER_ADMIN"?"/admin/super-admin":"/admin/dashboard")}catch(a){n((a==null?void 0:a.message)||"Unable to sign in. Please check your credentials.")}finally{m(!1)}};return i.jsxs("div",{className:"admin-login-page",children:[i.jsx("style",{children:`

        /*
        ============================================================
        ADMIN LOGIN
        ============================================================
        */

        .admin-login-page {
          min-height: 100vh;

          display: flex;

          align-items: center;
          justify-content: center;

          padding:
            32px 20px;

          box-sizing: border-box;

          background:
            var(--c-bg, #f7f7f5);

          color:
            var(--c-text, #111);
        }

        /*
        ============================================================
        CARD
        ============================================================
        */

        .admin-login-card {
          width: min(
            100%,
            430px
          );

          padding:
            42px;

          border:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            var(--c-bg, #fff);

          box-shadow:
            0 20px 60px
            rgba(
              0,
              0,
              0,
              0.07
            );

          box-sizing: border-box;
        }

        /*
        ============================================================
        BRAND
        ============================================================
        */

        .admin-login-brand {
          margin-bottom: 6px;

          line-height: 1;
        }

        .admin-login-brand span {
          display: block;

          margin-top: 6px;

          color:
            var(--c-gray, #777);
        }

        .admin-login-heading {
          margin:
            30px 0 6px;
        }

        .admin-login-subtitle {
          margin:
            0 0 28px;

          color:
            var(--c-gray, #777);

          max-width: 40ch;
        }

        /*
        ============================================================
        FORM
        ============================================================
        */

        .admin-login-form {
          display: flex;

          flex-direction: column;

          gap: 18px;
        }

        .admin-login-field {
          display: flex;

          flex-direction: column;

          gap: 7px;
        }

        .admin-login-label {
          color:
            var(--c-text, #111);
        }

        .admin-login-input-wrap {
          position: relative;
        }

        .admin-login-input-icon {
          position: absolute;

          left: 13px;

          top: 50%;

          transform:
            translateY(-50%);

          color:
            #999;

          pointer-events: none;
        }

        .admin-login-input {
          width: 100%;

          min-height: 48px;

          padding:
            0 14px 0 42px;

          box-sizing: border-box;

          border:
            1px solid
            #d8d8d8;

          border-radius:
            8px;

          outline: none;

          background:
            #fafafa;

          color:
            var(--c-text, #111);

          font: inherit;

          transition:
            border-color 0.2s ease,
            background 0.2s ease,
            box-shadow 0.2s ease;
        }

        .admin-login-input:hover {
          background:
            #fff;

          border-color:
            #c8c8c8;
        }

        .admin-login-input:focus {
          background:
            #fff;

          border-color:
            var(--c-text, #111);

          box-shadow:
            0 0 0 3px
            rgba(
              0,
              0,
              0,
              0.045
            );
        }

        .admin-login-input::placeholder {
          color:
            #aaa;
        }

        /*
        ============================================================
        ERROR
        ============================================================
        */

        .admin-login-error {
          margin:
            -2px 0 0;

          padding:
            11px 13px;

          border:
            1px solid
            rgba(
              190,
              30,
              30,
              0.18
            );

          background:
            rgba(
              190,
              30,
              30,
              0.05
            );

          color:
            #a52828;

          border-radius:
            7px;
        }

        /*
        ============================================================
        SUBMIT
        ============================================================
        */

        .admin-login-submit {
          display: flex;

          align-items: center;
          justify-content: center;

          gap: 9px;

          width: 100%;

          min-height: 50px;

          margin-top: 2px;

          padding:
            0 18px;

          border: 0;

          border-radius:
            8px;

          cursor: pointer;

          transition:
            transform 0.2s ease,
            opacity 0.2s ease,
            box-shadow 0.2s ease;
        }

        .admin-login-submit:hover:not(:disabled) {
          transform:
            translateY(-1px);

          box-shadow:
            0 8px 20px
            rgba(
              0,
              0,
              0,
              0.10
            );
        }

        .admin-login-submit:active:not(:disabled) {
          transform:
            translateY(0);
        }

        .admin-login-submit:disabled {
          opacity:
            0.65;

          cursor:
            wait;
        }

        .admin-login-submit-icon {
          display: inline-flex;

          align-items: center;
          justify-content: center;

          transition:
            transform 0.2s ease;
        }

        .admin-login-submit:hover:not(:disabled)
        .admin-login-submit-icon {
          transform:
            translateX(3px);
        }

        /*
        ============================================================
        FOOTER
        ============================================================
        */

        .admin-login-footer {
          margin-top:
            26px;

          padding-top:
            18px;

          border-top:
            1px solid
            var(--c-hairline, #e5e5e5);

          color:
            var(--c-gray, #777);

          text-align:
            center;
        }

        /*
        ============================================================
        RESPONSIVE
        ============================================================
        */

        @media (max-width: 520px) {

          .admin-login-page {
            align-items:
              flex-start;

            padding:
              24px 14px;
          }

          .admin-login-card {
            padding:
              30px 22px;
          }

          .admin-login-heading {
            margin-top:
              24px;
          }

        }

        /*
        ============================================================
        REDUCED MOTION
        ============================================================
        */

        @media (
          prefers-reduced-motion: reduce
        ) {

          .admin-login-input,
          .admin-login-submit,
          .admin-login-submit-icon {
            transition: none;
          }

        }

      `}),i.jsxs("main",{className:"admin-login-card",children:[i.jsxs("div",{className:"admin-login-brand",children:["JONATHAN",i.jsx("span",{children:"Photography"})]}),i.jsx("h1",{className:"admin-login-heading",children:"Admin Dashboard"}),i.jsx("p",{className:"admin-login-subtitle",children:"Sign in to manage bookings, portfolio content, services, and studio settings."}),i.jsxs("form",{className:"admin-login-form",onSubmit:f,noValidate:!0,children:[i.jsxs("div",{className:"admin-login-field",children:[i.jsx("label",{htmlFor:"username",className:"admin-login-label",children:"Username"}),i.jsxs("div",{className:"admin-login-input-wrap",children:[i.jsx(j,{size:17,className:"admin-login-input-icon","aria-hidden":"true"}),i.jsx("input",{id:"username",name:"username",type:"text",autoComplete:"username",autoFocus:!0,className:"admin-login-input",value:t,onChange:e=>{h(e.target.value),r&&n("")},placeholder:"Enter your username"})]})]}),i.jsxs("div",{className:"admin-login-field",children:[i.jsx("label",{htmlFor:"password",className:"admin-login-label",children:"Password"}),i.jsxs("div",{className:"admin-login-input-wrap",children:[i.jsx(k,{size:17,className:"admin-login-input-icon","aria-hidden":"true"}),i.jsx("input",{id:"password",name:"password",type:"password",autoComplete:"current-password",className:"admin-login-input",value:d,onChange:e=>{b(e.target.value),r&&n("")},placeholder:"Enter your password"})]})]}),r&&i.jsx("p",{className:"admin-login-error",role:"alert",children:r}),i.jsxs("button",{type:"submit",className:`
              btn
              btn--primary
              admin-login-submit
            `,disabled:l,children:[i.jsx("span",{children:l?"Signing In…":"Sign In"}),!l&&i.jsx("span",{className:"admin-login-submit-icon",children:i.jsx(w,{size:17})})]})]}),i.jsx("div",{className:"admin-login-footer",children:"Jonathan Photography · Admin Access"})]})]})}export{E as default};
