import{i as l,q as W,h as $,b as H,r as t,t as V,v as q,j as e,E as B,X as C,w as M,M as F,O as Y}from"./index-ZwdCBnk2.js";import{S as O}from"./shield-check-BM8gRDKt.js";import{C as A}from"./calendar-days-DHsoeBVF.js";import{C as X}from"./calendar-check-Bik4zY78.js";import{S as G}from"./sparkles-C4oxipUZ.js";import{C as Q}from"./calculator-IfUrIFuN.js";import{W as J}from"./wallet-cards-C_5d4QJ-.js";import{A as K}from"./archive-restore-ChySCzsK.js";import{L as Z}from"./life-buoy-BFFga7h-.js";import{A as ee}from"./archive-Dy8hQhfj.js";import{U as ae}from"./user-Cllqh9M3.js";import{S as ie}from"./search-DJYhVgX9.js";import{C as _}from"./chevron-right-Cj6ZrVvO.js";/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const se=l("AtSign",[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-4 8",key:"7n84p3"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const re=l("ClipboardList",[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",key:"116196"}],["path",{d:"M12 11h4",key:"1jrz19"}],["path",{d:"M12 16h4",key:"n85exb"}],["path",{d:"M8 11h.01",key:"1dfujw"}],["path",{d:"M8 16h.01",key:"18s6g9"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const D=l("Images",[["path",{d:"M18 22H4a2 2 0 0 1-2-2V6",key:"pblm9e"}],["path",{d:"m22 13-1.296-1.296a2.41 2.41 0 0 0-3.408 0L11 18",key:"nf6bnh"}],["circle",{cx:"12",cy:"8",r:"2",key:"1822b1"}],["rect",{width:"16",height:"16",x:"6",y:"2",rx:"2",key:"12espp"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ne=l("LayoutDashboard",[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const te=l("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const oe=l("PanelsTopLeft",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M3 9h18",key:"1pudct"}],["path",{d:"M9 21V9",key:"1oto5p"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const le=l("ScanSearch",[["path",{d:"M3 7V5a2 2 0 0 1 2-2h2",key:"aa7l1z"}],["path",{d:"M17 3h2a2 2 0 0 1 2 2v2",key:"4qcy5o"}],["path",{d:"M21 17v2a2 2 0 0 1-2 2h-2",key:"6vwrx8"}],["path",{d:"M7 21H5a2 2 0 0 1-2-2v-2",key:"ioqczr"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}],["path",{d:"m16 16-1.9-1.9",key:"1dq9hf"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const de=l("ScrollText",[["path",{d:"M15 12h-5",key:"r7krc0"}],["path",{d:"M15 8h-5",key:"1khuty"}],["path",{d:"M19 17V5a2 2 0 0 0-2-2H4",key:"zz82l3"}],["path",{d:"M8 21h12a2 2 0 0 0 2-2v-1a1 1 0 0 0-1-1H11a1 1 0 0 0-1 1v1a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v2a1 1 0 0 0 1 1h3",key:"1ph1d7"}]]),ce=[{section:"Oversight",roles:["SUPER_ADMIN"],links:[{to:"/admin/super-admin",label:"Overview",icon:O},{to:"/admin/oversight/bookings",label:"Client Requests",icon:re},{to:"/admin/oversight/calendar",label:"Calendar",icon:A},{to:"/admin/oversight/portfolio",label:"Portfolio",icon:D},{to:"/admin/content-oversight",label:"Content Oversight",icon:le}]},{section:"Overview",roles:["OWNER"],links:[{to:"/admin/dashboard",label:"Dashboard",icon:ne}]},{section:"Requests",roles:["OWNER"],links:[{to:"/admin/bookings",label:"Client Requests",icon:X},{to:"/admin/calendar",label:"Calendar",icon:A}]},{section:"Content",roles:["OWNER"],links:[{to:"/admin/site-content",label:"Website Content",icon:oe},{to:"/admin/portfolio",label:"Portfolio",icon:D},{to:"/admin/services",label:"Services",icon:G}]},{section:"Configuration",roles:["OWNER"],links:[{to:"/admin/estimator-settings",label:"Estimator",icon:Q},{to:"/admin/contacts",label:"Contact Links",icon:se}]},{section:"Billing",links:[{to:"/admin/platform-fees",label:"Platform Fees",icon:J},{to:"/admin/super-archives",label:"Financial Archives",icon:K,roles:["SUPER_ADMIN"]}]},{section:"Support",links:[{to:"/admin/support",label:"Support Reports",ownerLabel:"Report a Problem",icon:Z}]},{section:"Records",roles:["OWNER"],links:[{to:"/admin/archive",label:"Archive & Logs",icon:ee},{to:"/admin/oversight-log",label:"Oversight & Flags",icon:de}]}];function Ne(){var w,N,j,S,R,E;const{admin:a,logout:I}=W(),b=$(),r=H(),[d,v]=t.useState(""),[o,x]=t.useState(null),[y,g]=t.useState(!1),[L,p]=t.useState(!1),[m,h]=t.useState(!1),k=ce.filter(i=>!i.roles||i.roles.includes(a==null?void 0:a.role)).map(i=>({...i,links:i.links.filter(s=>!s.roles||s.roles.includes(a==null?void 0:a.role))})),f=t.useRef(null);t.useEffect(()=>{window.scrollTo({top:0,left:0,behavior:"auto"})},[r.pathname,r.search]);const P=(a==null?void 0:a.role)==="SUPER_ADMIN"||(a==null?void 0:a.role)==="OWNER"&&(r.pathname==="/admin"||r.pathname==="/admin/dashboard"||r.pathname.startsWith("/admin/bookings")||r.pathname.startsWith("/admin/archive")),c=k.flatMap(i=>i.links).find(i=>r.pathname===i.to||r.pathname.startsWith(`${i.to}/`)),z=r.pathname==="/admin/profile"?(a==null?void 0:a.role)==="SUPER_ADMIN"?"Superadmin profile":"Studio profile":((a==null?void 0:a.role)==="OWNER"&&(c!=null&&c.ownerLabel)?c.ownerLabel:c==null?void 0:c.label)||"Dashboard",U=async()=>{await I(),b("/admin/login")};t.useEffect(()=>{const i=d.trim();if(!i){x(null),g(!1);return}g(!0);const s=setTimeout(async()=>{try{const n=(a==null?void 0:a.role)==="SUPER_ADMIN"?await V.global(i):await q.global(i);x((a==null?void 0:a.role)==="SUPER_ADMIN"?{superResults:(n==null?void 0:n.results)||[]}:{bookings:(n==null?void 0:n.bookings)||[],leads:(n==null?void 0:n.leads)||[]})}catch{x((a==null?void 0:a.role)==="SUPER_ADMIN"?{superResults:[]}:{bookings:[],leads:[]})}finally{g(!1)}},300);return()=>{clearTimeout(s)}},[d,a==null?void 0:a.role]),t.useEffect(()=>{const i=s=>{f.current&&!f.current.contains(s.target)&&p(!1)};return document.addEventListener("mousedown",i),()=>{document.removeEventListener("mousedown",i)}},[]),t.useEffect(()=>{p(!1),h(!1)},[r.pathname]),t.useEffect(()=>(document.body.style.overflow=m?"hidden":"",()=>{document.body.style.overflow=""}),[m]);const u=()=>{v(""),x(null),p(!1)};return e.jsxs("div",{className:"admin-shell",children:[e.jsx("a",{className:"admin-skip-link",href:"#admin-main",children:"Skip to main content"}),e.jsx("style",{children:`

        /*
        ============================================================
        ADMIN SHELL
        ============================================================
        */

        .admin-shell {
          min-height: 100vh;

          display: flex;

          background:
            var(--c-bg, #f7f7f5);

          color:
            var(--c-text, #111);
        }

        /*
        ============================================================
        SIDEBAR
        ============================================================
        */

        .admin-sidebar {
          position: sticky;

          top: 0;

          width: 255px;

          height: 100vh;

          flex:
            0 0 255px;

          display: flex;

          flex-direction: column;

          overflow: hidden;

          background:
            #111;

          color:
            #fff;

          scrollbar-width:
            thin;

          z-index:
            100;
        }

        /*
        ============================================================
        BRAND
        ============================================================
        */

        .admin-sidebar__brand {
          display: flex;

          flex-direction: column;

          justify-content: center;

          min-height:
            88px;

          padding:
            22px 24px;

          border-bottom:
            1px solid
            rgba(
              255,
              255,
              255,
              0.08
            );
        }

        .admin-sidebar__brand span {
          display:
            block;

          margin-top:
            5px;

          opacity:
            0.45;
        }

        /*
        ============================================================
        NAV
        ============================================================
        */

        .admin-sidebar__nav {
          flex:
            1;

          min-height:
            0;

          overflow-y:
            auto;

          overscroll-behavior-y:
            contain;

          scrollbar-gutter:
            stable;

          padding:
            16px 12px 20px;
        }

        .admin-sidebar__group {
          margin-bottom:
            22px;
        }

        .admin-sidebar__section {
          padding:
            0 12px;

          margin:
            0 0 7px;

          opacity:
            0.38;

          text-transform:
            uppercase;
        }

        .admin-sidebar__link {
          position:
            relative;

          display:
            flex;

          align-items:
            center;

          gap:
            11px;

          width:
            100%;

          min-height:
            44px;

          padding:
            0 12px;

          margin-bottom:
            3px;

          border-radius:
            8px;

          color:
            rgba(
              255,
              255,
              255,
              0.68
            );

          text-decoration:
            none;

          transition:
            background 0.2s ease,
            color 0.2s ease,
            transform 0.2s ease;
        }

        .admin-sidebar__link:hover {
          color:
            #fff;

          background:
            rgba(
              255,
              255,
              255,
              0.07
            );
        }

        .admin-sidebar__link.active {
          color:
            #fff;

          background:
            rgba(
              255,
              255,
              255,
              0.12
            );
        }

        .admin-sidebar__link.active::before {
          content:
            '';

          position:
            absolute;

          left:
            0;

          top:
            8px;

          bottom:
            8px;

          width:
            3px;

          border-radius:
            999px;

          background:
            #fff;
        }

        .admin-sidebar__link-icon {
          display:
            inline-flex;

          align-items:
            center;

          justify-content:
            center;

          flex:
            0 0 auto;

          opacity:
            0.8;
        }

        .admin-sidebar__link.active
        .admin-sidebar__link-icon {
          opacity:
            1;
        }

        /*
        ============================================================
        SIDEBAR FOOTER
        ============================================================
        */

        .admin-sidebar__footer {
          margin-top:
            auto;

          padding:
            16px;

          border-top:
            1px solid
            rgba(
              255,
              255,
              255,
              0.08
            );
        }

        .admin-sidebar__profile {
          display:
            flex;

          align-items:
            center;

          gap:
            11px;

          min-width:
            0;

          padding:
            8px;

          margin-bottom:
            10px;

          border-radius:
            9px;

          background:
            rgba(
              255,
              255,
              255,
              0.04
            );
        }

        .admin-sidebar__avatar {
          width:
            36px;

          height:
            36px;

          flex:
            0 0 36px;

          display:
            flex;

          align-items:
            center;

          justify-content:
            center;

          border-radius:
            50%;

          background:
            #F5D000;

          color:
            #111;
        }

        .admin-sidebar__profile-copy {
          min-width:
            0;
        }

        .admin-sidebar__profile-label {
          display:
            block;

          margin-bottom:
            3px;

          opacity:
            0.38;

          text-transform:
            uppercase;
        }

        .admin-sidebar__profile-name {
          overflow:
            hidden;

          text-overflow:
            ellipsis;

          white-space:
            nowrap;

          color:
            rgba(
              255,
              255,
              255,
              0.92
            );
        }

        .admin-sidebar__logout {
          display:
            flex;

          align-items:
            center;

          justify-content:
            center;

          gap:
            8px;

          width:
            100%;

          min-height:
            38px;

          padding:
            0 12px;

          border:
            1px solid
            rgba(
              255,
              255,
              255,
              0.09
            );

          border-radius:
            7px;

          background:
            rgba(
              255,
              255,
              255,
              0.035
            );

          color:
            rgba(
              255,
              255,
              255,
              0.72
            );

          cursor:
            pointer;

          transition:
            background 0.2s ease,
            color 0.2s ease,
            border-color 0.2s ease;
        }

        .admin-sidebar__logout:hover {
          color:
            #fff;

          background:
            rgba(
              255,
              255,
              255,
              0.09
            );

          border-color:
            rgba(
              255,
              255,
              255,
              0.18
            );
        }

        /*
        ============================================================
        MAIN
        ============================================================
        */

        .admin-main {
          min-width:
            0;

          flex:
            1;
        }

        .superadmin-readonly-banner { position: sticky; top: 0; z-index: 40; display: flex; align-items: center; gap: 9px; padding: 10px 40px; color: #111; background: #fff6bf; border-bottom: 1px solid #e6c900; font-size: 13px; font-weight: 800; letter-spacing: .04em; }

        /*
        ============================================================
        TOP BAR
        ============================================================
        */

        .admin-topbar {
          position:
            sticky;

          top:
            0;

          z-index:
            80;

          min-height:
            68px;

          display:
            flex;

          align-items:
            center;

          justify-content:
            space-between;

          gap:
            24px;

          padding:
            12px 28px;

          border-bottom:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            rgba(
              255,
              255,
              255,
              0.94
            );

          backdrop-filter:
            blur(12px);
        }

        /*
        ============================================================
        SINGLE PAGE TITLE
        ============================================================
        */

        .admin-topbar__title {
          min-width:
            0;

          margin:
            0;

          overflow:
            hidden;

          text-overflow:
            ellipsis;

          white-space:
            nowrap;

          line-height:
            1.1;
        }

        /*
        ============================================================
        SEARCH
        ============================================================
        */

        .admin-search {
          position:
            relative;

          width:
            min(
              380px,
              42vw
            );

          flex:
            0 0 auto;
        }

        .admin-search__input-wrap {
          position:
            relative;
        }

        .admin-search__icon {
          position:
            absolute;

          left:
            13px;

          top:
            50%;

          transform:
            translateY(-50%);

          color:
            #9ca3af;

          pointer-events:
            none;
        }

        .admin-search__input {
          width:
            100%;

          min-height:
            40px;

          box-sizing:
            border-box;

          padding:
            0 38px;

          border:
            1px solid
            #d8d8d8;

          border-radius:
            999px;

          outline:
            none;

          background:
            #fafafa;

          color:
            var(--c-text);

          font:
            inherit;

          transition:
            border-color 0.2s ease,
            background 0.2s ease,
            box-shadow 0.2s ease;
        }

        .admin-search__input:hover {
          background:
            #fff;
        }

        .admin-search__input:focus {
          background:
            #fff;

          border-color:
            var(--c-text);

          box-shadow:
            0 0 0 3px
            rgba(
              0,
              0,
              0,
              0.04
            );
        }

        .admin-search__clear {
          position:
            absolute;

          right:
            11px;

          top:
            50%;

          transform:
            translateY(-50%);

          display:
            flex;

          align-items:
            center;

          justify-content:
            center;

          width:
            24px;

          height:
            24px;

          padding:
            0;

          border:
            0;

          border-radius:
            50%;

          background:
            transparent;

          color:
            #8c8c8c;

          cursor:
            pointer;

          transition:
            background 0.2s ease,
            color 0.2s ease;
        }

        .admin-search__clear:hover {
          color:
            var(--c-text);

          background:
            #ededed;
        }

        /*
        ============================================================
        SEARCH RESULTS
        ============================================================
        */

        .admin-search__results {
          position:
            absolute;

          top:
            calc(
              100% + 9px
            );

          left:
            0;

          right:
            0;

          max-height:
            440px;

          overflow-y:
            auto;

          overflow-x:
            hidden;

          border:
            1px solid
            #dedede;

          border-radius:
            10px;

          background:
            #fff;

          box-shadow:
            0 16px 40px
            rgba(
              0,
              0,
              0,
              0.12
            );
        }

        .admin-search__state {
          padding:
            18px;

          color:
            #777;

          text-align:
            center;
        }

        .admin-search__group {
          padding:
            8px;
        }

        .admin-search__group
        + .admin-search__group {
          border-top:
            1px solid
            #ededed;
        }

        .admin-search__group-label {
          padding:
            6px 8px;

          color:
            #999;

          text-transform:
            uppercase;
        }

        .admin-search__result {
          display:
            flex;

          align-items:
            center;

          justify-content:
            space-between;

          gap:
            14px;

          width:
            100%;

          min-height:
            58px;

          padding:
            8px;

          border:
            0;

          border-radius:
            7px;

          background:
            transparent;

          color:
            var(--c-text);

          text-align:
            left;

          cursor:
            pointer;

          transition:
            background 0.2s ease;
        }

        .admin-search__result:hover {
          background:
            #f5f5f5;
        }

        .admin-search__result-copy {
          min-width:
            0;
        }

        .admin-search__result-name {
          overflow:
            hidden;

          text-overflow:
            ellipsis;

          white-space:
            nowrap;
        }

        .admin-search__result-meta {
          margin-top:
            3px;

          overflow:
            hidden;

          text-overflow:
            ellipsis;

          white-space:
            nowrap;

          color:
            #777;
        }

        .admin-search__result-arrow {
          flex:
            0 0 auto;

          color:
            #aaa;
        }

        /*
        ============================================================
        CONTENT
        ============================================================
        */

        .admin-main > .admin-content,
        .admin-main > main {
          min-width:
            0;
        }

        .admin-nav-toggle,
        .admin-sidebar__close,
        .admin-nav-backdrop {
          display: none;
        }

        /*
        ============================================================
        RESPONSIVE
        ============================================================
        */

        @media (max-width: 1000px) {

          .admin-sidebar {
            width:
              220px;

            flex-basis:
              220px;
          }

          .admin-topbar {
            padding:
              12px 20px;
          }

          .admin-search {
            width:
              min(
                320px,
                45vw
              );
          }

        }

        @media (max-width: 900px) {

          .admin-shell { display: block; }

          .admin-shell .admin-sidebar {
            position: fixed;
            inset: 0 auto 0 0;
            width: min(86vw, 320px);
            height: 100svh;
            max-height: none;
            overflow: hidden;
            transform: translateX(-102%);
            transition: transform 240ms ease;
            box-shadow: 18px 0 50px rgba(0, 0, 0, 0.24);
          }

          .admin-shell .admin-sidebar.is-open { transform: translateX(0); }

          .admin-sidebar__brand { position: relative; min-height: 66px; padding: 17px 58px 17px 20px; }

          .admin-sidebar__close {
            position: absolute;
            top: 14px;
            right: 14px;
            display: grid;
            width: 38px;
            height: 38px;
            place-items: center;
            border: 0;
            border-radius: 50%;
            background: rgba(255,255,255,0.1);
            color: #fff;
          }

          .admin-shell .admin-sidebar__nav { display: block; overflow-y: auto; padding: 12px; }

          .admin-shell .admin-sidebar__group { display: block; margin: 0 0 14px; }

          .admin-shell .admin-sidebar__section { display: block; padding: 5px 9px; margin-bottom: 4px; }

          .admin-shell .admin-sidebar__link { justify-content: flex-start; min-height: 44px; padding: 0 12px; border-radius: 6px; }

          .admin-shell .admin-sidebar__footer { display: block; padding: 12px; }

          .admin-sidebar__profile {
            margin-bottom:
              8px;
          }

          .admin-topbar { position: sticky; top: 0; min-height: 64px; align-items: center; flex-flow: row wrap; padding: 10px 16px; gap: 10px; }

          .admin-nav-toggle {
            display: grid;
            width: 44px;
            height: 44px;
            flex: 0 0 44px;
            place-items: center;
            border: 1px solid var(--c-hairline, #ddd);
            border-radius: 50%;
            background: #fff;
            color: #111;
          }

          .admin-nav-backdrop {
            position: fixed;
            inset: 0;
            z-index: 90;
            display: block;
            border: 0;
            background: rgba(0,0,0,0.48);
          }

          .admin-topbar__title { width: auto; flex: 1; font-size: clamp(1.15rem, 5vw, 1.45rem); }

          .admin-search { order: 3; width: 100%; }

        }

        @media (max-width: 500px) {

          .admin-topbar { padding-inline: 12px; }

        }

        /*
        ============================================================
        REDUCED MOTION
        ============================================================
        */

        @media (
          prefers-reduced-motion: reduce
        ) {

          .admin-sidebar__link,
          .admin-sidebar__logout,
          .admin-search__input,
          .admin-search__clear,
          .admin-search__result {
            transition:
              none;
          }

        }

      `}),e.jsxs("aside",{id:"admin-navigation",className:`admin-sidebar ${m?"is-open":""}`,children:[e.jsxs("div",{className:"admin-sidebar__brand",children:[e.jsx(B,{variant:"admin"}),e.jsx("strong",{children:"jonathan"}),e.jsx("span",{children:(a==null?void 0:a.role)==="SUPER_ADMIN"?"platform oversight":"photography / studio"}),e.jsx("button",{type:"button",className:"admin-sidebar__close",onClick:()=>h(!1),"aria-label":"Close admin navigation",children:e.jsx(C,{size:20})})]}),e.jsx("nav",{className:"admin-sidebar__nav",children:k.map(i=>e.jsxs("div",{className:"admin-sidebar__group",children:[e.jsx("div",{className:"admin-sidebar__section",children:i.section}),i.links.map(s=>{const n=s.icon;return e.jsxs(M,{to:s.to,className:({isActive:T})=>`admin-sidebar__link ${T?"active":""}`,onClick:()=>h(!1),children:[e.jsx("span",{className:"admin-sidebar__link-icon",children:e.jsx(n,{size:17})}),e.jsx("span",{children:(a==null?void 0:a.role)==="OWNER"&&s.ownerLabel?s.ownerLabel:s.label})]},s.to)})]},i.section))}),e.jsxs("div",{className:"admin-sidebar__footer",children:[e.jsxs(M,{to:"/admin/profile",className:({isActive:i})=>`admin-sidebar__profile ${i?"is-active":""}`,"aria-label":`${(a==null?void 0:a.role)==="SUPER_ADMIN"?"Superadmin":"Studio"} profile and security for ${(a==null?void 0:a.username)||"this account"}`,children:[e.jsx("div",{className:"admin-sidebar__avatar",children:a!=null&&a.username?a.username.charAt(0).toUpperCase():e.jsx(ae,{size:18})}),e.jsxs("div",{className:"admin-sidebar__profile-copy",children:[e.jsx("span",{className:"admin-sidebar__profile-label",children:(a==null?void 0:a.role)==="SUPER_ADMIN"?"Platform oversight":"Studio workspace"}),e.jsxs("div",{className:"admin-sidebar__profile-name",children:["Hi,"," ",(a==null?void 0:a.username)||"Admin","!"]}),e.jsx("span",{className:"admin-sidebar__profile-action",children:"Profile & security"})]})]}),e.jsxs("button",{type:"button",onClick:U,className:"admin-sidebar__logout",children:[e.jsx(te,{size:15}),"Logout"]})]})]}),m&&e.jsx("button",{type:"button",className:"admin-nav-backdrop",onClick:()=>h(!1),"aria-label":"Close admin navigation"}),e.jsxs("div",{className:"admin-main",children:[e.jsxs("header",{className:"admin-topbar",children:[e.jsx("button",{type:"button",className:"admin-nav-toggle",onClick:()=>h(!0),"aria-controls":"admin-navigation","aria-expanded":m,"aria-label":"Open admin navigation",children:e.jsx(F,{size:21})}),e.jsx("h1",{className:"admin-topbar__title",children:z}),P&&e.jsxs("div",{className:"admin-search",ref:f,children:[e.jsxs("div",{className:"admin-search__input-wrap",children:[e.jsx(ie,{size:17,className:"admin-search__icon"}),e.jsx("input",{type:"search","aria-label":(a==null?void 0:a.role)==="SUPER_ADMIN"?"Search platform records":"Search clients and bookings",className:"admin-search__input",placeholder:(a==null?void 0:a.role)==="SUPER_ADMIN"?"Search fees, support, or website content…":"Search clients, emails, or bookings...",value:d,onFocus:()=>{d.trim()&&p(!0)},onChange:i=>{v(i.target.value),p(!0)}}),d&&e.jsx("button",{type:"button",className:"admin-search__clear",onMouseDown:i=>i.preventDefault(),onClick:u,"aria-label":"Clear search",children:e.jsx(C,{size:14})})]}),d&&L&&e.jsxs("div",{className:"admin-search__results",children:[y&&e.jsx("div",{className:"admin-search__state",children:"Searching..."}),!y&&o&&e.jsxs(e.Fragment,{children:[((w=o.superResults)==null?void 0:w.length)>0&&e.jsxs("div",{className:"admin-search__group",children:[e.jsx("div",{className:"admin-search__group-label",children:"Platform results"}),o.superResults.map((i,s)=>e.jsxs("button",{type:"button",className:"admin-search__result",onMouseDown:n=>n.preventDefault(),onClick:()=>{b(i.to),u()},children:[e.jsxs("div",{className:"admin-search__result-copy",children:[e.jsx("div",{className:"admin-search__result-name",children:i.label}),e.jsxs("div",{className:"admin-search__result-meta",children:[i.type," · ",i.meta]})]}),e.jsx(_,{size:15,className:"admin-search__result-arrow"})]},`${i.type}-${i.label}-${s}`))]}),((N=o.bookings)==null?void 0:N.length)>0&&e.jsxs("div",{className:"admin-search__group",children:[e.jsx("div",{className:"admin-search__group-label",children:"Bookings"}),o.bookings.map(i=>e.jsxs("button",{type:"button",className:"admin-search__result",onMouseDown:s=>s.preventDefault(),onClick:()=>{b(`/admin/bookings/${i.id}`,{state:{from:{...r,state:{...r.state||{},scrollY:window.scrollY}}}}),u()},children:[e.jsxs("div",{className:"admin-search__result-copy",children:[e.jsx("div",{className:"admin-search__result-name",children:i.name||i.client_name||i.full_name||"Unnamed Client"}),e.jsxs("div",{className:"admin-search__result-meta",children:[i.email||"No email"," · ",i.shoot_type||i.service_type||"Booking"]})]}),e.jsx(_,{size:15,className:"admin-search__result-arrow"})]},`b-${i.id}`))]}),((j=o.leads)==null?void 0:j.length)>0&&e.jsxs("div",{className:"admin-search__group",children:[e.jsx("div",{className:"admin-search__group-label",children:"Saved Estimates"}),o.leads.map(i=>e.jsxs("button",{type:"button",className:"admin-search__result",onMouseDown:s=>s.preventDefault(),onClick:()=>{b("/admin/bookings?view=estimates"),u()},children:[e.jsxs("div",{className:"admin-search__result-copy",children:[e.jsx("div",{className:"admin-search__result-name",children:i.name||i.client_name||i.full_name||"Unnamed Lead"}),e.jsxs("div",{className:"admin-search__result-meta",children:[i.email||"No email"," · Status: ",i.status||"New"]})]}),e.jsx(_,{size:15,className:"admin-search__result-arrow"})]},`l-${i.id}`))]}),!((S=o.bookings)!=null&&S.length)&&!((R=o.leads)!=null&&R.length)&&!((E=o.superResults)!=null&&E.length)&&e.jsxs("div",{className:"admin-search__state",children:['No results found for "',d,'".']})]})]})]})]}),(a==null?void 0:a.role)==="SUPER_ADMIN"&&(r.pathname.startsWith("/admin/oversight/")||r.pathname==="/admin/platform-fees")&&e.jsxs("div",{className:"superadmin-readonly-banner",role:"status",children:[e.jsx(O,{size:16})," Read-only: Superadmin oversight. Studio records cannot be changed here."]}),e.jsx("main",{id:"admin-main",tabIndex:"-1",className:"admin-main__content",children:e.jsx(Y,{})})]})]})}export{Ne as default};
