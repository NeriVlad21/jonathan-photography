import{i as w,l as U,r as c,j as t,e as F,m,s as E}from"./index-DwFWKgCp.js";import{E as G,M as B}from"./Modal-AV3B6CNC.js";import{S as V}from"./save-DB8M_m-f.js";import{E as Q}from"./eye-BdeqD93h.js";import{C as P}from"./clock-3-PeY9BpDi.js";import{T}from"./trash-2-BOkEWldz.js";import{P as M}from"./plus-DsDCHajR.js";/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const W=w("DollarSign",[["line",{x1:"12",x2:"12",y1:"2",y2:"22",key:"7eqyqh"}],["path",{d:"M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",key:"1b0p4s"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const K=w("Layers3",[["path",{d:"m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z",key:"8b97xw"}],["path",{d:"m6.08 9.5-3.5 1.6a1 1 0 0 0 0 1.81l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9a1 1 0 0 0 0-1.83l-3.5-1.59",key:"1e5n1m"}],["path",{d:"m6.08 14.5-3.5 1.6a1 1 0 0 0 0 1.81l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9a1 1 0 0 0 0-1.83l-3.5-1.59",key:"1iwflc"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $=w("PackagePlus",[["path",{d:"M16 16h6",key:"100bgy"}],["path",{d:"M19 13v6",key:"85cyf1"}],["path",{d:"M21 10V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l2-1.14",key:"e7tb2h"}],["path",{d:"m7.5 4.27 9 5.15",key:"1c824w"}],["polyline",{points:"3.29 7 12 12 20.71 7",key:"ousv84"}],["line",{x1:"12",x2:"12",y1:"22",y2:"12",key:"a4e8g8"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Y=w("Percent",[["line",{x1:"19",x2:"5",y1:"5",y2:"19",key:"1x9vlm"}],["circle",{cx:"6.5",cy:"6.5",r:"2.5",key:"4mh3h7"}],["circle",{cx:"17.5",cy:"17.5",r:"2.5",key:"1mdrzq"}]]);function se(){const{showToast:n}=U(),[p,g]=c.useState(null),[x,f]=c.useState({label:"",hours:"",price:""}),[l,h]=c.useState({label:"",description:"",price:"",is_quantity_based:0}),[u,v]=c.useState(null),[_,N]=c.useState("15"),[A,C]=c.useState(!1),k=c.useRef(new Map),D=(e,i)=>{const a=k.current;a.has(e)&&window.clearTimeout(a.get(e).timer);const r=window.setTimeout(()=>{a.delete(e),i()},600);a.set(e,{timer:r,save:i})};c.useEffect(()=>()=>{k.current.forEach(({timer:e,save:i})=>{window.clearTimeout(e),i()}),k.current.clear()},[]);const b=e=>e===""||e===null||e===void 0,d=()=>m.config(!0).then(e=>{g({hours:Array.isArray(e==null?void 0:e.hours)?e.hours:[],addons:Array.isArray(e==null?void 0:e.addons)?e.addons:[],services:Array.isArray(e==null?void 0:e.services)?e.services:[]}),(e==null?void 0:e.range_margin)!==void 0&&(e==null?void 0:e.range_margin)!==null&&N(String(e.range_margin))}).catch(()=>{g({hours:[],addons:[],services:[]})});c.useEffect(()=>{document.title="Admin — Estimator Settings",d()},[]);const z=async e=>{e.preventDefault();const i=Number(_);if(_===""||Number.isNaN(i)||i<0||i>100){n("Margin must be between 0 and 100.","error");return}C(!0);try{const a=await m.updateSettings({range_margin:i});N(String((a==null?void 0:a.range_margin)??i)),n("Estimator range margin updated.")}catch(a){n((a==null?void 0:a.message)||"Unable to update the range margin.","error")}finally{C(!1)}},q=async(e,i)=>{const a=i===""?"":Number(i),r={...e,starting_price:a};g(s=>({...s,services:s.services.map(o=>o.id===e.id?r:o)}));try{await E.update({id:e.id,starting_price:i===""?"":Number(i)}),n(`${e.name} price updated.`)}catch(s){n((s==null?void 0:s.message)||"Unable to update service price.","error"),d()}},H=(e,i)=>{g(a=>({...a,services:a.services.map(r=>r.id===e.id?{...r,starting_price:i}:r)}))},L=async(e,i,a)=>{const r={...e,[i]:a};g(s=>({...s,services:s.services.map(o=>o.id===e.id?r:o)}));try{await E.update({id:e.id,[i]:i==="visible"?a?1:0:a}),i==="visible"&&n(`${e.name} visibility updated.`)}catch(s){n((s==null?void 0:s.message)||"Unable to update service.","error"),d()}},I=async e=>{e.preventDefault();try{await m.createHour(x),f({label:"",hours:"",price:""}),n("Coverage option added."),d()}catch(i){n((i==null?void 0:i.message)||"Unable to add coverage option.","error")}},j=(e,i,a)=>{const r={...e,[i]:a};g(s=>({...s,hours:s.hours.map(o=>o.id===e.id?r:o)})),!(b(r.label)||b(r.hours)||b(r.price))&&D(`hour-${e.id}`,async()=>{try{await m.updateHour(r)}catch(s){n((s==null?void 0:s.message)||"Unable to update coverage option.","error"),d()}})},R=async e=>{e.preventDefault();try{await m.createAddon(l),h({label:"",description:"",price:"",is_quantity_based:0}),n("Add-on added."),d()}catch(i){n((i==null?void 0:i.message)||"Unable to add add-on.","error")}},y=(e,i,a)=>{const r={...e,[i]:a};g(s=>({...s,addons:s.addons.map(o=>o.id===e.id?r:o)})),!(b(r.label)||b(r.price))&&D(`addon-${e.id}`,async()=>{try{await m.updateAddon(r)}catch(s){n((s==null?void 0:s.message)||"Unable to update add-on.","error"),d()}})},O=async()=>{if(u)try{u.type==="hour"?await m.deleteHour(u.id):await m.deleteAddon(u.id),n(`${u.type==="hour"?"Coverage option":"Add-on"} deleted.`),v(null),d()}catch(e){n((e==null?void 0:e.message)||"Unable to delete item.","error")}},S=(e,i,a)=>t.jsxs("div",{className:"estimator-settings-empty",children:[t.jsx("div",{className:"estimator-settings-empty__icon",children:e}),t.jsx("strong",{children:i}),t.jsx("span",{children:a})]});return p?t.jsxs(t.Fragment,{children:[t.jsx("style",{children:`

        /*
        ============================================================
        ESTIMATOR SETTINGS
        ============================================================
        */

        .estimator-settings-page {
          width: 100%;
        }

        .estimator-settings-content {
          width: 100%;

          max-width:
            1050px;
        }

        /*
        ============================================================
        INTRO
        ============================================================
        */

        .estimator-settings-intro {
          margin-bottom:
            20px;

          color:
            var(--c-gray);
        }

        .estimator-settings-intro p {
          margin:
            0;

          max-width:
            70ch;
        }

        /*
        ============================================================
        PANEL
        ============================================================
        */

        .estimator-settings-panel {
          margin-bottom:
            18px;

          border:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            var(--c-bg, #fff);

          overflow:
            hidden;
        }

        .estimator-settings-panel:last-child {
          margin-bottom:
            0;
        }

        .estimator-settings-panel__head {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap: 15px;

          padding:
            17px 20px;

          border-bottom:
            1px solid
            var(--c-hairline, #e5e5e5);
        }

        .estimator-settings-panel__title-wrap {
          display: flex;

          align-items: center;

          gap: 10px;
        }

        .estimator-settings-panel__icon {
          display: inline-flex;

          align-items: center;
          justify-content: center;

          width: 31px;
          height: 31px;

          flex:
            0 0 31px;

          border-radius:
            7px;

          background:
            #111;

          color:
            #fff;
        }

        .estimator-settings-panel__title {
          margin:
            0;
        }

        .estimator-settings-panel__description {
          margin:
            4px 0 0;

          color:
            var(--c-gray);
        }

        .estimator-settings-panel__body {
          padding:
            20px;
        }

        /*
        ============================================================
        GLOBAL MARGIN
        ============================================================
        */

        .estimator-margin-form {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap: 25px;
        }

        .estimator-margin-copy {
          min-width:
            0;
        }

        .estimator-margin-copy__label {
          display: block;

          margin-bottom:
            4px;
        }

        .estimator-margin-copy__text {
          margin:
            0;

          color:
            var(--c-gray);

          line-height:
            1.5;
        }

        .estimator-margin-control {
          display: flex;

          align-items: center;

          gap: 7px;

          flex:
            0 0 auto;
        }

        .estimator-margin-input {
          width:
            90px;

          min-height:
            42px;

          box-sizing:
            border-box;

          padding:
            0 11px;

          border:
            1px solid
            #d8d8d8;

          border-radius:
            7px;

          background:
            #fafafa;

          color:
            var(--c-text);

          outline:
            none;

          font:
            inherit;

          transition:
            border-color 0.2s ease,
            background 0.2s ease,
            box-shadow 0.2s ease;
        }

        .estimator-margin-input:hover {
          background:
            #fff;

          border-color:
            #c5c5c5;
        }

        .estimator-margin-input:focus {
          background:
            #fff;

          border-color:
            var(--c-text);

          box-shadow:
            0 0 0 3px
            rgba(
              0,
              0,
              0,
              0.04
            );
        }

        .estimator-margin-percent {
          color:
            var(--c-gray);
        }

        .estimator-margin-button {
          display: inline-flex;

          align-items: center;

          gap: 7px;

          min-height:
            42px;
        }

        /*
        ============================================================
        SERVICE PRICING
        ============================================================
        */

        .estimator-service-list {
          display: flex;

          flex-direction:
            column;
        }

        .estimator-service-row {
          display: grid;

          grid-template-columns:
            minmax(180px, 1fr)
            190px
            72px;

          align-items: center;

          gap:
            15px;

          padding:
            15px 0;

          border-bottom:
            1px solid
            var(--c-hairline, #ededed);
        }

        .estimator-service-row:first-child {
          padding-top:
            0;
        }

        .estimator-service-row:last-child {
          padding-bottom:
            0;

          border-bottom:
            0;
        }

        .estimator-service-info {
          min-width:
            0;
        }

        .estimator-service-name {
          margin:
            0 0 3px;
        }

        .estimator-service-category {
          color:
            var(--c-gray);

          text-transform:
            capitalize;
        }

        .estimator-price-control {
          display: flex;

          align-items: center;

          gap: 7px;
        }

        .estimator-price-prefix {
          color:
            var(--c-gray);
        }

        .estimator-price-input {
          width:
            100%;

          min-height:
            39px;

          box-sizing:
            border-box;

          padding:
            0 10px;

          border:
            1px solid
            #d8d8d8;

          border-radius:
            7px;

          outline:
            none;

          background:
            #fafafa;

          color:
            var(--c-text);

          font:
            inherit;

          transition:
            border-color 0.2s ease,
            background 0.2s ease;
        }

        .estimator-price-input:hover {
          background:
            #fff;

          border-color:
            #c5c5c5;
        }

        .estimator-price-input:focus {
          background:
            #fff;

          border-color:
            var(--c-text);

          box-shadow:
            0 0 0 3px
            rgba(
              0,
              0,
              0,
              0.04
            );
        }

        .estimator-visibility {
          display: flex;

          align-items: center;

          justify-content:
            flex-end;
        }

        .estimator-visibility__button {
          display: inline-flex;

          align-items: center;
          justify-content: center;

          width:
            36px;

          height:
            36px;

          padding: 0;

          border:
            1px solid
            #d8d8d8;

          border-radius:
            7px;

          background:
            #fff;

          color:
            #777;

          cursor:
            pointer;

          transition:
            background 0.18s ease,
            color 0.18s ease,
            border-color 0.18s ease;
        }

        .estimator-visibility__button:hover {
          background:
            #f4f4f4;

          color:
            var(--c-text);

          border-color:
            #c5c5c5;
        }

        .estimator-visibility__button--visible {
          color:
            #247447;
        }

        /*
        ============================================================
        ROW LISTS
        ============================================================
        */

        .estimator-list {
          display:
            flex;

          flex-direction:
            column;
        }

        .estimator-list-row {
          display:
            grid;

          grid-template-columns:
            minmax(130px, 1.2fr)
            90px
            120px
            80px
            40px;

          align-items:
            center;

          gap:
            10px;

          padding:
            13px 0;

          border-bottom:
            1px solid
            var(--c-hairline, #ededed);
        }

        .estimator-list-row:last-child {
          border-bottom:
            0;
        }

        .estimator-inline-input {
          width:
            100%;

          min-height:
            38px;

          box-sizing:
            border-box;

          padding:
            0 9px;

          border:
            1px solid
            #d8d8d8;

          border-radius:
            7px;

          background:
            #fafafa;

          color:
            var(--c-text);

          outline:
            none;

          font:
            inherit;
        }

        .estimator-inline-input:focus {
          background:
            #fff;

          border-color:
            var(--c-text);

          box-shadow:
            0 0 0 3px
            rgba(
              0,
              0,
              0,
              0.04
            );
        }

        .estimator-active-control {
          display:
            flex;

          align-items:
            center;

          justify-content:
            center;
        }

        .estimator-delete {
          display:
            inline-flex;

          align-items:
            center;

          justify-content:
            center;

          width:
            34px;

          height:
            34px;

          padding:
            0;

          border:
            1px solid
            rgba(
              179,
              38,
              30,
              0.35
            );

          border-radius:
            7px;

          background:
            transparent;

          color:
            #b3261e;

          cursor:
            pointer;

          transition:
            background 0.18s ease,
            border-color 0.18s ease;
        }

        .estimator-delete:hover {
          background:
            rgba(
              179,
              38,
              30,
              0.05
            );

          border-color:
            #b3261e;
        }

        /*
        ============================================================
        ADD ROW
        ============================================================
        */

        .estimator-add-row {
          display:
            grid;

          grid-template-columns:
            minmax(130px, 1.2fr)
            90px
            120px
            80px
            auto;

          align-items:
            center;

          gap:
            10px;

          margin-top:
            14px;

          padding-top:
            14px;

          border-top:
            1px dashed
            #dcdcdc;
        }

        .estimator-add-row__action {
          display:
            inline-flex;

          align-items:
            center;

          justify-content:
            center;

          gap:
            6px;

          white-space:
            nowrap;
        }

        /*
        ============================================================
        ADD-ON LIST
        ============================================================
        */

        .estimator-addon-row {
          display:
            grid;

          grid-template-columns:
            minmax(140px, 1fr)
            minmax(180px, 1.4fr)
            100px
            95px
            75px
            40px;

          align-items:
            center;

          gap:
            10px;

          padding:
            13px 0;

          border-bottom:
            1px solid
            var(--c-hairline, #ededed);
        }

        .estimator-addon-row:last-child {
          border-bottom:
            0;
        }

        .estimator-addon-label {
          min-width:
            0;
        }

        .estimator-addon-description {
          min-width:
            0;

          overflow:
            hidden;

          text-overflow:
            ellipsis;

          white-space:
            nowrap;
        }

        .estimator-switch-field {
          display:
            flex;

          align-items:
            center;

          justify-content:
            center;

          gap:
            6px;
        }

        .estimator-switch-label {
          color:
            var(--c-gray);
        }

        /*
        ============================================================
        ADD-ON ADD FORM
        ============================================================
        */

        .estimator-addon-add-row {
          display:
            grid;

          grid-template-columns:
            minmax(140px, 1fr)
            minmax(180px, 1.4fr)
            100px
            95px
            auto;

          align-items:
            center;

          gap:
            10px;

          margin-top:
            14px;

          padding-top:
            14px;

          border-top:
            1px dashed
            #dcdcdc;
        }

        .estimator-addon-quantity {
          display:
            flex;

          align-items:
            center;

          gap:
            7px;

          color:
            var(--c-gray);

          white-space:
            nowrap;
        }

        .estimator-addon-submit {
          display:
            inline-flex;

          align-items:
            center;

          justify-content:
            center;

          gap:
            6px;

          white-space:
            nowrap;
        }

        /*
        ============================================================
        EMPTY
        ============================================================
        */

        .estimator-settings-empty {
          display:
            flex;

          flex-direction:
            column;

          align-items:
            center;

          justify-content:
            center;

          padding:
            35px 20px;

          color:
            var(--c-gray);

          text-align:
            center;
        }

        .estimator-settings-empty__icon {
          display:
            flex;

          align-items:
            center;

          justify-content:
            center;

          width:
            42px;

          height:
            42px;

          margin-bottom:
            10px;

          border-radius:
            50%;

          background:
            #f1f1f1;

          color:
            #777;
        }

        /*
        ============================================================
        RESPONSIVE
        ============================================================
        */

        @media (max-width: 900px) {

          .estimator-service-row {
            grid-template-columns:
              minmax(160px, 1fr)
              170px
              50px;
          }

          .estimator-addon-row {
            grid-template-columns:
              minmax(140px, 1fr)
              minmax(150px, 1fr)
              90px
              75px
              70px
              40px;
          }

          .estimator-addon-add-row {
            grid-template-columns:
              minmax(130px, 1fr)
              minmax(150px, 1fr)
              90px
              auto;
          }

          .estimator-addon-quantity {
            grid-column:
              1 / -1;
          }

        }

        @media (max-width: 760px) {

          .estimator-margin-form {
            align-items:
              stretch;

            flex-direction:
              column;
          }

          .estimator-margin-control {
            width:
              100%;
          }

          .estimator-margin-input {
            width:
              100%;
          }

          .estimator-margin-button {
            flex:
              0 0 auto;
          }

          .estimator-service-row {
            grid-template-columns:
              1fr;

            gap:
              10px;
          }

          .estimator-price-control {
            max-width:
              220px;
          }

          .estimator-visibility {
            justify-content:
              flex-start;
          }

          .estimator-list-row,
          .estimator-addon-row {
            display:
              flex;

            align-items:
              flex-start;

            flex-direction:
              column;

            gap:
              8px;

            padding:
              15px 0;
          }

          .estimator-list-row
          > *,
          .estimator-addon-row
          > * {
            width:
              100%;
          }

          .estimator-active-control,
          .estimator-switch-field {
            justify-content:
              flex-start;
          }

          .estimator-delete {
            width:
              100%;
          }

          .estimator-add-row,
          .estimator-addon-add-row {
            display:
              flex;

            flex-direction:
              column;

            align-items:
              stretch;

            gap:
              8px;
          }

          .estimator-add-row .btn,
          .estimator-addon-submit {
            width:
              100%;
          }

        }

        @media (max-width: 500px) {

          .estimator-settings-panel__head,
          .estimator-settings-panel__body {
            padding:
              15px;
          }

          .estimator-margin-control {
            align-items:
              stretch;

            flex-direction:
              column;
          }

          .estimator-margin-percent {
            display:
              none;
          }

          .estimator-price-control {
            max-width:
              none;
          }

        }

        /*
        ============================================================
        REDUCED MOTION
        ============================================================
        */

        @media (
          prefers-reduced-motion: reduce
        ) {

          .estimator-margin-input,
          .estimator-price-input,
          .estimator-inline-input,
          .estimator-visibility__button,
          .estimator-delete {
            transition:
              none;
          }

        }

      `}),t.jsx("section",{className:"estimator-settings-page",children:t.jsxs("div",{className:"admin-content estimator-settings-content",children:[t.jsx("div",{className:"estimator-settings-intro",children:t.jsx("p",{children:"Configure service pricing, coverage hours, add-ons, and the pricing logic used by the public estimator."})}),t.jsxs("section",{className:"estimator-settings-panel",children:[t.jsx("div",{className:"estimator-settings-panel__head",children:t.jsxs("div",{className:"estimator-settings-panel__title-wrap",children:[t.jsx("span",{className:"estimator-settings-panel__icon",children:t.jsx(Y,{size:15})}),t.jsxs("div",{children:[t.jsx("h2",{className:"estimator-settings-panel__title",children:"Global Logic"}),t.jsx("p",{className:"estimator-settings-panel__description",children:"Control how the public estimator displays its price range."})]})]})}),t.jsx("div",{className:"estimator-settings-panel__body",children:t.jsxs("form",{className:"estimator-margin-form",onSubmit:z,children:[t.jsxs("div",{className:"estimator-margin-copy",children:[t.jsx("strong",{className:"estimator-margin-copy__label",children:"Price Range Margin"}),t.jsx("p",{className:"estimator-margin-copy__text",children:"The estimator uses this percentage to calculate the displayed pricing range."})]}),t.jsxs("div",{className:"estimator-margin-control",children:[t.jsx("input",{type:"number",min:"0",max:"100",step:"1",value:_,onChange:e=>N(e.target.value),className:"estimator-margin-input","aria-label":"Price range margin percentage"}),t.jsx("span",{className:"estimator-margin-percent",children:"%"}),t.jsxs("button",{type:"submit",className:`
                      btn
                      btn--primary
                      estimator-margin-button
                    `,disabled:A,children:[t.jsx(V,{size:14}),A?"Saving…":"Save Margin"]})]})]})})]}),t.jsxs("section",{className:"estimator-settings-panel",children:[t.jsx("div",{className:"estimator-settings-panel__head",children:t.jsxs("div",{className:"estimator-settings-panel__title-wrap",children:[t.jsx("span",{className:"estimator-settings-panel__icon",children:t.jsx(W,{size:15})}),t.jsxs("div",{children:[t.jsx("h2",{className:"estimator-settings-panel__title",children:"Service Type Pricing"}),t.jsx("p",{className:"estimator-settings-panel__description",children:"These are the same service prices used in Services. A change here updates both areas. Descriptions and package details are edited in Services."})]})]})}),t.jsx("div",{className:"estimator-settings-panel__body",children:p.services.length===0?S(t.jsx(K,{size:18}),"No services found.","Add services from the Services section."):t.jsx("div",{className:"estimator-service-list",children:p.services.map(e=>t.jsxs("div",{className:"estimator-service-row",children:[t.jsxs("div",{className:"estimator-service-info",children:[t.jsx("strong",{className:"estimator-service-name",children:e.name}),t.jsx("div",{className:"estimator-service-category",children:e.category||"Photography"})]}),t.jsxs("div",{className:"estimator-price-control",children:[t.jsx("span",{className:"estimator-price-prefix",children:"₱"}),t.jsx("input",{type:"number",min:"0",step:"0.01",value:e.starting_price??"",onChange:i=>H(e,i.target.value),onBlur:i=>q(e,i.target.value),onKeyDown:i=>{i.key==="Enter"&&i.currentTarget.blur()},"aria-label":`${e.name} starting price`,className:"estimator-price-input",title:"Starting price"})]}),t.jsx("div",{className:"estimator-visibility",children:t.jsx("button",{type:"button",className:`
                              estimator-visibility__button
                              ${e.visible?"estimator-visibility__button--visible":""}
                            `,onClick:()=>L(e,"visible",!e.visible),title:e.visible?"Visible on public estimator":"Hidden from public estimator","aria-label":e.visible?`Hide ${e.name}`:`Show ${e.name}`,children:e.visible?t.jsx(Q,{size:15}):t.jsx(G,{size:15})})})]},e.id))})})]}),t.jsxs("section",{className:"estimator-settings-panel",children:[t.jsx("div",{className:"estimator-settings-panel__head",children:t.jsxs("div",{className:"estimator-settings-panel__title-wrap",children:[t.jsx("span",{className:"estimator-settings-panel__icon",children:t.jsx(P,{size:15})}),t.jsxs("div",{children:[t.jsx("h2",{className:"estimator-settings-panel__title",children:"Coverage Hours"}),t.jsx("p",{className:"estimator-settings-panel__description",children:"Configure the available coverage duration options and their prices."})]})]})}),t.jsxs("div",{className:"estimator-settings-panel__body",children:[p.hours.length===0?S(t.jsx(P,{size:18}),"No coverage options yet.","Add your first coverage option below."):t.jsx("div",{className:"estimator-list",children:p.hours.map(e=>t.jsxs("div",{className:"estimator-list-row",children:[t.jsx("input",{type:"text",value:e.label||"",onChange:i=>j(e,"label",i.target.value),"aria-label":`${e.label||"Coverage option"} label`,className:"estimator-inline-input",title:"Coverage label"}),t.jsx("input",{type:"number",min:"0",step:"0.5",value:e.hours??"",onChange:i=>j(e,"hours",i.target.value),"aria-label":`${e.label||"Coverage option"} hours`,className:"estimator-inline-input",title:"Hours",placeholder:"Hours"}),t.jsx("input",{type:"number",min:"0",step:"0.01",value:e.price??"",onChange:i=>j(e,"price",i.target.value),"aria-label":`${e.label||"Coverage option"} price`,className:"estimator-inline-input",title:"Price",placeholder:"Price"}),t.jsx("div",{className:"estimator-active-control",children:t.jsxs("label",{className:"switch",title:e.active?"Active":"Inactive",children:[t.jsx("input",{type:"checkbox",checked:!!e.active,onChange:i=>j(e,"active",i.target.checked?1:0)}),t.jsx("span",{className:"switch__track"})]})}),t.jsx("button",{type:"button",className:"estimator-delete",onClick:()=>v({type:"hour",id:e.id,label:e.label}),"aria-label":`Delete ${e.label}`,title:`Delete ${e.label}`,children:t.jsx(T,{size:14})})]},e.id))}),t.jsxs("form",{onSubmit:I,className:"estimator-add-row",children:[t.jsx("input",{type:"text",placeholder:"Label (e.g. 10 Hours)",required:!0,value:x.label,onChange:e=>f({...x,label:e.target.value}),"aria-label":"New coverage label",className:"estimator-inline-input"}),t.jsx("input",{type:"number",min:"0",step:"0.5",placeholder:"Hours",required:!0,value:x.hours,onChange:e=>f({...x,hours:e.target.value}),"aria-label":"New coverage hours",className:"estimator-inline-input"}),t.jsx("input",{type:"number",min:"0",step:"0.01",placeholder:"Price",required:!0,value:x.price,onChange:e=>f({...x,price:e.target.value}),"aria-label":"New coverage price",className:"estimator-inline-input"}),t.jsx("span",{}),t.jsxs("button",{type:"submit",className:`
                    btn
                    btn--primary
                    btn--sm
                    estimator-add-row__action
                  `,children:[t.jsx(M,{size:14}),"Add Coverage"]})]})]})]}),t.jsxs("section",{className:"estimator-settings-panel",children:[t.jsx("div",{className:"estimator-settings-panel__head",children:t.jsxs("div",{className:"estimator-settings-panel__title-wrap",children:[t.jsx("span",{className:"estimator-settings-panel__icon",children:t.jsx($,{size:15})}),t.jsxs("div",{children:[t.jsx("h2",{className:"estimator-settings-panel__title",children:"Add-ons"}),t.jsx("p",{className:"estimator-settings-panel__description",children:"Manage optional extras and quantity-based pricing."})]})]})}),t.jsxs("div",{className:"estimator-settings-panel__body",children:[p.addons.length===0?S(t.jsx($,{size:18}),"No add-ons yet.","Add your first optional service below."):t.jsx("div",{className:"estimator-list",children:p.addons.map(e=>t.jsxs("div",{className:"estimator-addon-row",children:[t.jsx("input",{type:"text",value:e.label||"",onChange:i=>y(e,"label",i.target.value),"aria-label":`${e.label||"Add-on"} name`,className:`
                            estimator-inline-input
                            estimator-addon-label
                          `,placeholder:"Label"}),t.jsx("input",{type:"text",value:e.description||"",onChange:i=>y(e,"description",i.target.value),"aria-label":`${e.label||"Add-on"} description`,className:`
                            estimator-inline-input
                            estimator-addon-description
                          `,placeholder:"Description"}),t.jsx("input",{type:"number",min:"0",step:"0.01",value:e.price??"",onChange:i=>y(e,"price",i.target.value),"aria-label":`${e.label||"Add-on"} price`,className:"estimator-inline-input",title:"Price",placeholder:"Price"}),t.jsxs("div",{className:"estimator-switch-field",children:[t.jsxs("label",{className:"switch",title:"Quantity based",children:[t.jsx("input",{type:"checkbox",checked:!!e.is_quantity_based,onChange:i=>y(e,"is_quantity_based",i.target.checked?1:0)}),t.jsx("span",{className:"switch__track"})]}),t.jsx("span",{className:"estimator-switch-label",children:"Qty"})]}),t.jsxs("div",{className:"estimator-switch-field",children:[t.jsxs("label",{className:"switch",title:"Active",children:[t.jsx("input",{type:"checkbox",checked:!!e.active,onChange:i=>y(e,"active",i.target.checked?1:0)}),t.jsx("span",{className:"switch__track"})]}),t.jsx("span",{className:"estimator-switch-label",children:"Active"})]}),t.jsx("button",{type:"button",className:"estimator-delete",onClick:()=>v({type:"addon",id:e.id,label:e.label}),"aria-label":`Delete ${e.label}`,title:`Delete ${e.label}`,children:t.jsx(T,{size:14})})]},e.id))}),t.jsxs("form",{onSubmit:R,className:"estimator-addon-add-row",children:[t.jsx("input",{type:"text",placeholder:"Label",required:!0,value:l.label,onChange:e=>h({...l,label:e.target.value}),"aria-label":"New add-on name",className:"estimator-inline-input"}),t.jsx("input",{type:"text",placeholder:"Description",value:l.description,onChange:e=>h({...l,description:e.target.value}),"aria-label":"New add-on description",className:"estimator-inline-input"}),t.jsx("input",{type:"number",min:"0",step:"0.01",placeholder:"Price",required:!0,value:l.price,onChange:e=>h({...l,price:e.target.value}),"aria-label":"New add-on price",className:"estimator-inline-input"}),t.jsxs("label",{className:"estimator-addon-quantity",children:[t.jsx("input",{type:"checkbox",checked:!!l.is_quantity_based,onChange:e=>h({...l,is_quantity_based:e.target.checked?1:0})}),"Qty Based"]}),t.jsxs("button",{type:"submit",className:`
                    btn
                    btn--primary
                    btn--sm
                    estimator-addon-submit
                  `,children:[t.jsx(M,{size:14}),"Add Add-on"]})]})]})]})]})}),u&&t.jsx(B,{title:`Delete "${u.label}"?`,body:"This will remove it from the public estimator immediately.",confirmLabel:"Delete",danger:!0,onConfirm:O,onClose:()=>v(null)})]}):t.jsx(F,{label:"Loading estimator settings…"})}export{se as default};
