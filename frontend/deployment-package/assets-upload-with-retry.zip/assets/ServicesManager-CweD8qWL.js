import{l as T,r as a,D,F as A,G as P,j as i,e as R,s as m}from"./index-ZwdCBnk2.js";import{E as L,M as z}from"./Modal-ccbGtAJE.js";import{P as w}from"./pencil-CLA_XYXX.js";import{P as V}from"./plus-BEFK1lLT.js";import{S as $}from"./save-C5FtuGKN.js";import{S as M}from"./sparkles-C4oxipUZ.js";import{E as U}from"./eye-DEQCkNaR.js";import{T as H}from"./trash-2-5jK_EI28.js";const j={name:"",category:"photography",description:"",starting_price:"",sort_order:"",visible:1,inclusions:"",coverage_details:"",deliverables:"",package_options:"",notes:""},G=[{key:"inclusions",label:"Included",placeholder:`One item per line, e.g.
Pre-event consultation
One lead photographer`},{key:"coverage_details",label:"Coverage",placeholder:`One item per line, e.g.
Preparation to reception`},{key:"deliverables",label:"Deliverables",placeholder:`One item per line, e.g.
Edited digital gallery`},{key:"package_options",label:"Options",placeholder:"One item per line — optional upgrades or variations"},{key:"notes",label:"Notes",placeholder:"One item per line — travel, scheduling, or other notes"}];function Z(){const{showToast:n}=T(),[o,f]=a.useState(null),[r,g]=a.useState(j),[t,b]=a.useState(null),[c,x]=a.useState(null),[p,u]=a.useState(!1),[N,_]=a.useState(null),[y,S]=a.useState(D.servicesPage.categories),v=()=>{m.list(!0).then(e=>{f(Array.isArray(e)?e:[])}).catch(()=>{f([])})};a.useEffect(()=>{document.title="Admin — Services",v(),A.get().then(e=>S(P(e==null?void 0:e.content).servicesPage.categories)).catch(()=>{})},[]);const l=(e,s)=>{g(d=>({...d,[e]:s}))},k=e=>{b(e.id),g({name:e.name||"",category:e.category||"photography",description:e.description||"",starting_price:e.starting_price??"",sort_order:e.sort_order??"",visible:e.visible?1:0,inclusions:e.inclusions||"",coverage_details:e.coverage_details||"",deliverables:e.deliverables||"",package_options:e.package_options||"",notes:e.notes||""}),window.scrollTo({top:0,behavior:"smooth"})},h=()=>{b(null),g(j)},E=async e=>{e.preventDefault(),u(!0);try{if(t)await m.update({id:t,...r}),n("Service updated.");else{const{sort_order:s,...d}=r;await m.create(s===""?d:r),n("Service added.")}h(),v()}catch(s){const d=Object.values((s==null?void 0:s.errors)||{}).find(F=>typeof F=="string");n(d||(s==null?void 0:s.message)||"Unable to save service.","error")}finally{u(!1)}},C=async e=>{_(e.id);try{await m.update({id:e.id,visible:e.visible?0:1}),n(e.visible?"Service hidden from the public site.":"Service is now visible on the public site."),v()}catch(s){n((s==null?void 0:s.message)||"Unable to update service visibility.","error")}finally{_(null)}},I=async()=>{if(c)try{await m.remove(c.id),n("Service deleted."),t===c.id&&h(),x(null),v()}catch(e){n((e==null?void 0:e.message)||"Unable to delete service.","error")}},O=e=>{if(e==null||e==="")return"—";const s=Number(e);return Number.isNaN(s)?"—":`₱${s.toLocaleString("en-PH",{minimumFractionDigits:0,maximumFractionDigits:2})}`};return i.jsxs(i.Fragment,{children:[i.jsx("style",{children:`

        /*
        ============================================================
        SERVICES MANAGER
        ============================================================
        */

        .services-manager-page {
          width: 100%;
        }

        .services-manager-content {
          width: 100%;

          max-width:
            1100px;
        }

        /*
        ============================================================
        INTRO
        ============================================================
        */

        .services-manager-intro {
          margin-bottom:
            20px;

          color:
            var(--c-gray);
        }

        .services-manager-intro p {
          margin:
            0;

          max-width:
            65ch;
        }

        /*
        ============================================================
        EDITOR
        ============================================================
        */

        .services-editor {
          margin-bottom:
            20px;

          border:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            var(--c-bg, #fff);

          overflow:
            hidden;
        }

        .services-editor__head {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap:
            15px;

          padding:
            17px 20px;

          border-bottom:
            1px solid
            var(--c-hairline, #e5e5e5);
        }

        .services-editor__title-wrap {
          display: flex;

          align-items: center;

          gap:
            10px;
        }

        .services-editor__icon {
          display: inline-flex;

          align-items: center;
          justify-content: center;

          width:
            31px;

          height:
            31px;

          flex:
            0 0 31px;

          border-radius:
            7px;

          background:
            #111;

          color:
            #fff;
        }

        .services-editor__title {
          margin:
            0;
        }

        .services-editor__body {
          padding:
            20px;
        }

        /*
        ============================================================
        FORM
        ============================================================
        */

        .services-form-grid {
          display: grid;

          grid-template-columns:
            repeat(
              2,
              minmax(0, 1fr)
            );

          gap:
            17px 20px;
        }

        .services-form-field {
          min-width:
            0;
        }

        .services-form-field--full {
          grid-column:
            1 / -1;
        }

        .services-details-heading {
          display: flex;
          flex-direction: column;
          gap: 4px;
          padding-top: 14px;
          border-top: 1px solid var(--c-hairline, #e5e5e5);
        }

        .services-form-actions {
          display: flex;

          align-items: center;

          gap:
            8px;

          margin-top:
            20px;
        }

        .services-submit {
          display: inline-flex;

          align-items: center;
          justify-content: center;

          gap:
            7px;
        }

        /*
        ============================================================
        LIST
        ============================================================
        */

        .services-list-panel {
          overflow:
            hidden;

          border:
            1px solid
            var(--c-hairline, #e5e5e5);

          background:
            var(--c-bg, #fff);
        }

        .services-list-header {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap:
            15px;

          padding:
            17px 20px;

          border-bottom:
            1px solid
            var(--c-hairline, #e5e5e5);
        }

        .services-list-header__title {
          margin:
            0;
        }

        .services-list-header__count {
          color:
            var(--c-gray);
        }

        /*
        ============================================================
        SERVICE ROW
        ============================================================
        */

        .services-list {
          display:
            flex;

          flex-direction:
            column;
        }

        .svc-admin-row {
          display: grid;

          grid-template-columns:
            minmax(190px, 1.2fr)
            minmax(130px, 0.8fr)
            140px
            auto
            auto;

          align-items:
            center;

          gap:
            18px;

          padding:
            16px 20px;

          border-bottom:
            1px solid
            var(--c-hairline, #ededed);

          transition:
            background 0.18s ease;
        }

        .svc-admin-row:last-child {
          border-bottom:
            0;
        }

        .svc-admin-row:hover {
          background:
            #fafafa;
        }

        /*
        ============================================================
        SERVICE INFO
        ============================================================
        */

        .svc-admin-row__info {
          min-width:
            0;
        }

        .svc-admin-row__name {
          display:
            block;

          overflow:
            hidden;

          text-overflow:
            ellipsis;

          white-space:
            nowrap;
        }

        .svc-admin-row__description {
          margin-top:
            4px;

          overflow:
            hidden;

          color:
            var(--c-gray);

          text-overflow:
            ellipsis;

          white-space:
            nowrap;
        }

        /*
        ============================================================
        CATEGORY
        ============================================================
        */

        .svc-admin-row__category {
          color:
            var(--c-gray);

          text-transform:
            capitalize;
        }

        /*
        ============================================================
        PRICE
        ============================================================
        */

        .svc-admin-row__price {
          white-space:
            nowrap;
        }

        .svc-admin-row__price-label {
          display:
            block;

          margin-bottom:
            3px;

          color:
            #999;

          text-transform:
            uppercase;
        }

        /*
        ============================================================
        VISIBILITY
        ============================================================
        */

        .svc-admin-row__visibility {
          display:
            inline-flex;

          align-items:
            center;

          justify-content:
            center;

          width:
            36px;

          height:
            36px;

          padding:
            0;

          border:
            1px solid
            #d8d8d8;

          border-radius:
            7px;

          background:
            #fff;

          color:
            #777;

          cursor:
            pointer;

          transition:
            background 0.18s ease,
            border-color 0.18s ease,
            color 0.18s ease;
        }

        .svc-admin-row__visibility:hover:not(:disabled) {
          background:
            #f2f2f2;

          border-color:
            #c5c5c5;

          color:
            var(--c-text);
        }

        .svc-admin-row__visibility--visible {
          color:
            #287449;
        }

        .svc-admin-row__visibility:disabled {
          opacity:
            0.55;

          cursor:
            wait;
        }

        /*
        ============================================================
        ACTIONS
        ============================================================
        */

        .svc-admin-row__actions {
          display:
            flex;

          align-items:
            center;

          justify-content:
            flex-end;

          gap:
            7px;
        }

        .svc-admin-row__edit {
          display:
            inline-flex;

          align-items:
            center;

          justify-content:
            center;

          gap:
            6px;

          min-height:
            34px;

          padding:
            0 10px;
        }

        .svc-admin-row__delete {
          display:
            inline-flex;

          align-items:
            center;

          justify-content:
            center;

          width:
            34px;

          height:
            34px;

          padding:
            0;

          border:
            1px solid
            rgba(
              179,
              38,
              30,
              0.35
            );

          border-radius:
            7px;

          background:
            transparent;

          color:
            #b3261e;

          cursor:
            pointer;

          transition:
            background 0.18s ease,
            border-color 0.18s ease;
        }

        .svc-admin-row__delete:hover {
          background:
            rgba(
              179,
              38,
              30,
              0.05
            );

          border-color:
            #b3261e;
        }

        /*
        ============================================================
        EMPTY
        ============================================================
        */

        .services-empty {
          display:
            flex;

          flex-direction:
            column;

          align-items:
            center;

          justify-content:
            center;

          padding:
            45px 25px;

          text-align:
            center;

          color:
            var(--c-gray);
        }

        .services-empty__icon {
          display:
            flex;

          align-items:
            center;

          justify-content:
            center;

          width:
            44px;

          height:
            44px;

          margin-bottom:
            11px;

          border-radius:
            50%;

          background:
            #f1f1f1;

          color:
            #777;
        }

        .services-empty__title {
          margin:
            0 0 5px;

          color:
            var(--c-text);
        }

        .services-empty__text {
          margin:
            0;
        }

        /*
        ============================================================
        RESPONSIVE
        ============================================================
        */

        @media (max-width: 900px) {

          .svc-admin-row {
            grid-template-columns:
              minmax(170px, 1.3fr)
              minmax(110px, 0.8fr)
              120px
              auto;
          }

          .svc-admin-row__actions {
            grid-column:
              1 / -1;

            justify-content:
              flex-start;
          }

        }

        @media (max-width: 760px) {

          .services-form-grid {
            grid-template-columns:
              1fr;
          }

          .services-form-field--full {
            grid-column:
              auto;
          }

          .services-form-actions {
            align-items:
              stretch;

            flex-direction:
              column;
          }

          .services-form-actions .btn {
            width:
              100%;
          }

          .svc-admin-row {
            display:
              flex;

            align-items:
              flex-start;

            flex-direction:
              column;

            gap:
              10px;

            padding:
              16px;
          }

          .svc-admin-row__info,
          .svc-admin-row__category,
          .svc-admin-row__price,
          .svc-admin-row__actions {
            width:
              100%;
          }

          .svc-admin-row__visibility {
            margin-right:
              auto;
          }

          .svc-admin-row__actions {
            display:
              flex;

            align-items:
              center;

            justify-content:
              flex-start;
          }

        }

        @media (max-width: 500px) {

          .services-editor__head,
          .services-editor__body,
          .services-list-header {
            padding:
              15px;
          }

          .services-list-header {
            align-items:
              flex-start;

            flex-direction:
              column;

            gap:
              4px;
          }

          .svc-admin-row__actions {
            flex-wrap:
              wrap;
          }

        }

        /*
        ============================================================
        REDUCED MOTION
        ============================================================
        */

        @media (
          prefers-reduced-motion: reduce
        ) {

          .svc-admin-row,
          .svc-admin-row__visibility,
          .svc-admin-row__delete {
            transition:
              none;
          }

        }

      `}),i.jsx("section",{className:"services-manager-page",children:i.jsxs("div",{className:"admin-content services-manager-content",children:[i.jsx("div",{className:"services-manager-intro",children:i.jsx("p",{children:"Manage the photography services offered through the public website and estimator."})}),i.jsxs("div",{className:"services-editor",children:[i.jsxs("div",{className:"services-editor__head",children:[i.jsxs("div",{className:"services-editor__title-wrap",children:[i.jsx("span",{className:"services-editor__icon",children:t?i.jsx(w,{size:15}):i.jsx(V,{size:15})}),i.jsx("h2",{className:"services-editor__title",children:t?"Edit Service":"Add a Service"})]}),t&&i.jsx("button",{type:"button",className:`\r
                    btn\r
                    btn--ghost-light\r
                    btn--sm\r
                  `,onClick:h,disabled:p,children:"Cancel"})]}),i.jsxs("form",{className:"services-editor__body",onSubmit:E,children:[i.jsxs("div",{className:"services-form-grid",children:[i.jsxs("div",{className:"field services-form-field",children:[i.jsx("label",{htmlFor:"svc-name",children:"Name"}),i.jsx("input",{id:"svc-name",type:"text",required:!0,value:r.name,onChange:e=>l("name",e.target.value),placeholder:"Wedding Photography"})]}),i.jsxs("div",{className:"field services-form-field",children:[i.jsx("label",{htmlFor:"svc-cat",children:"Category"}),i.jsxs("select",{id:"svc-cat",value:r.category,onChange:e=>l("category",e.target.value),children:[!y.some(e=>e.key===r.category)&&i.jsx("option",{value:r.category,children:r.category}),y.map(e=>i.jsx("option",{value:e.key,children:e.label},e.key))]})]}),i.jsxs("div",{className:"field services-form-field",children:[i.jsx("label",{htmlFor:"svc-price",children:"Starting Price"}),i.jsx("small",{className:"services-form-help",children:"Shared with Estimator settings and the public package builder."}),i.jsx("input",{id:"svc-price",type:"number",min:"0",step:"0.01",value:r.starting_price,onChange:e=>l("starting_price",e.target.value),placeholder:"25000"})]}),i.jsxs("div",{className:"field services-form-field services-form-field--full",children:[i.jsx("label",{htmlFor:"svc-desc",children:"Description"}),i.jsx("textarea",{id:"svc-desc",value:r.description,onChange:e=>l("description",e.target.value),placeholder:"A short summary shown on the Services page and in the estimator.",rows:"4",maxLength:1200})]}),i.jsxs("div",{className:"field services-form-field",children:[i.jsx("label",{htmlFor:"svc-sort",children:"Sort Order"}),i.jsx("input",{id:"svc-sort",type:"number",step:"1",value:r.sort_order,onChange:e=>l("sort_order",e.target.value),placeholder:"Added last when blank"})]}),i.jsxs("div",{className:"field services-form-field",children:[i.jsx("label",{htmlFor:"svc-visible",children:"Visibility"}),i.jsxs("select",{id:"svc-visible",value:r.visible?"1":"0",onChange:e=>l("visible",e.target.value==="1"?1:0),children:[i.jsx("option",{value:"1",children:"Visible on the public site and estimator"}),i.jsx("option",{value:"0",children:"Hidden from the public"})]})]}),i.jsxs("div",{className:"services-form-field services-form-field--full services-details-heading",children:[i.jsx("strong",{children:"Package details"}),i.jsx("small",{className:"services-form-help",children:"Shown when visitors open this service on the Services page or tap the info button in the estimator. Write one item per line; empty sections are hidden."})]}),G.map(e=>i.jsxs("div",{className:"field services-form-field",children:[i.jsx("label",{htmlFor:`svc-${e.key}`,children:e.label}),i.jsx("textarea",{id:`svc-${e.key}`,value:r[e.key],onChange:s=>l(e.key,s.target.value),placeholder:e.placeholder,rows:"4",maxLength:2e3})]},e.key))]}),i.jsxs("div",{className:"services-form-actions",children:[i.jsxs("button",{type:"submit",className:`\r
                    btn\r
                    btn--primary\r
                    btn--sm\r
                    services-submit\r
                  `,disabled:p,children:[i.jsx($,{size:14}),p?"Saving…":t?"Save Changes":"Add Service"]}),t&&i.jsx("button",{type:"button",className:`\r
                      btn\r
                      btn--ghost-light\r
                      btn--sm\r
                    `,onClick:h,disabled:p,children:"Cancel"})]})]})]}),o===null&&i.jsx(R,{label:"Loading services…"}),o!==null&&i.jsxs("div",{className:"services-list-panel",children:[i.jsxs("div",{className:"services-list-header",children:[i.jsx("h2",{className:"services-list-header__title",children:"Available Services"}),i.jsxs("span",{className:"services-list-header__count",children:[o.length," ",o.length===1?"service":"services"]})]}),o.length===0?i.jsxs("div",{className:"services-empty",children:[i.jsx("div",{className:"services-empty__icon",children:i.jsx(M,{size:19})}),i.jsx("h3",{className:"services-empty__title",children:"No services yet"}),i.jsx("p",{className:"services-empty__text",children:"Add your first service above."})]}):i.jsx("div",{className:"services-list",children:o.map(e=>i.jsxs("div",{className:"svc-admin-row",children:[i.jsxs("div",{className:"svc-admin-row__info",children:[i.jsx("strong",{className:"svc-admin-row__name",children:e.name||"Untitled Service"}),i.jsx("div",{className:"svc-admin-row__description",children:e.description||"No description provided."})]}),i.jsx("div",{className:"svc-admin-row__category",children:e.category||"Photography"}),i.jsxs("div",{className:"svc-admin-row__price",children:[i.jsx("span",{className:"svc-admin-row__price-label",children:"Starting"}),i.jsx("strong",{children:O(e.starting_price)})]}),i.jsx("button",{type:"button",className:`
                            svc-admin-row__visibility
                            ${e.visible?"svc-admin-row__visibility--visible":""}
                          `,onClick:()=>C(e),disabled:N===e.id,title:e.visible?"Visible on public site":"Hidden from public site","aria-label":e.visible?`Hide ${e.name}`:`Show ${e.name}`,children:e.visible?i.jsx(U,{size:15}):i.jsx(L,{size:15})}),i.jsxs("div",{className:"svc-admin-row__actions",children:[i.jsxs("button",{type:"button",className:`\r
                              btn\r
                              btn--ghost-light\r
                              btn--sm\r
                              svc-admin-row__edit\r
                            `,onClick:()=>k(e),children:[i.jsx(w,{size:13}),"Edit"]}),i.jsx("button",{type:"button",className:"svc-admin-row__delete",onClick:()=>x(e),"aria-label":`Delete ${e.name}`,title:`Delete ${e.name}`,children:i.jsx(H,{size:14})})]})]},e.id))})]})]})}),c&&i.jsx(z,{title:`Delete "${c.name}"?`,body:"This cannot be undone.",confirmLabel:"Delete",danger:!0,onConfirm:I,onClose:()=>x(null)})]})}export{Z as default};
