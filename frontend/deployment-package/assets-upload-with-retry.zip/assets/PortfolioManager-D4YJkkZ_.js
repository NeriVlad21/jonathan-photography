import{i as R,l as uo,r as l,p as g,j as o,e as U,C as xo,B as bo}from"./index-ZwdCBnk2.js";import{u as vo}from"./useReasonDialog-C6eL57Ol.js";import{i as yo}from"./format-C7C3p2s4.js";import{E as G}from"./EmptyState-CwOvTTML.js";import{E as Z,M as jo}from"./Modal-ccbGtAJE.js";import{C as oo}from"./chevron-right-Cj6ZrVvO.js";import{P as eo}from"./plus-BEFK1lLT.js";import{E as io}from"./eye-DEQCkNaR.js";import{T as to}from"./trash-2-5jK_EI28.js";import"./AdminDialog-0MHyKvab.js";/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const No=R("CloudUpload",[["path",{d:"M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242",key:"1pljnt"}],["path",{d:"M12 12v9",key:"192myk"}],["path",{d:"m16 16-4-4-4 4",key:"119tzi"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const wo=R("FolderOpen",[["path",{d:"m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",key:"usdka0"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ko=R("Image",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",key:"1xmnt7"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ao=R("Star",[["polygon",{points:"12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2",key:"8f66p6"}]]);function Lo({readOnly:p=!1}){const{showToast:s}=uo(),[c,$]=l.useState(null),[v,z]=l.useState(null),[q,B]=l.useState(""),[d,k]=l.useState(null),[_,A]=l.useState(null),[u,I]=l.useState({title:"",description:"",location:"",shoot_date:""}),[m,y]=l.useState(null),[x,V]=l.useState(!1),[j,E]=l.useState([]),[W,M]=l.useState({}),[F,K]=l.useState(null),O=l.useRef(null),[f,P]=l.useState(null),[D,Q]=l.useState("");l.useEffect(()=>{document.title="Admin — Portfolio",T()},[]);function T(){g.categories(!0).then(e=>{$(Array.isArray(e)?e:[])}).catch(()=>{$([])})}function S(){if(!v){k([]);return}k(null),A(null),y(null),g.allShoots().then(e=>{const i=Array.isArray(e)?e.filter(a=>Number(a.category_id)===Number(v)):[];k(i)}).catch(()=>{k([])})}l.useEffect(()=>{v&&S()},[v]);function C(){if(!_){y([]);return}y(null),g.imagesForShoot(_).then(e=>{y(Array.isArray(e)?e:[])}).catch(()=>{y([])})}l.useEffect(()=>{_&&C()},[_]);const ro=async e=>{e.preventDefault();const i=q.trim();if(i)try{const a=await g.createCategory({name:i});B(""),await T(),z(a.id),s("Category created.")}catch(a){s(a.message,"error")}},no=async(e,i)=>{$(a=>a.map(t=>t.id===e.id?{...t,name:i}:t));try{await g.updateCategory({...e,name:i})}catch(a){s(a.message,"error"),T()}},lo=async e=>{if(e.preventDefault(),!(!u.title.trim()||!v))try{const i=await g.createShoot({...u,category_id:v});I({title:"",description:"",location:"",shoot_date:""}),await S(),A(i.id),s("Shoot created.")}catch(i){s(i.message,"error")}},Y=async e=>{try{await g.updateShoot({...e,visible:e.visible?0:1,category_id:e.category_id}),S()}catch(i){s(i.message,"error")}},so=e=>{const i=Array.from(e.target.files||[]);if(!i.length||!_)return;const a=i.map(t=>({id:`${t.name}:${t.size}:${t.lastModified}`,file:t,title:"",caption:"",error:""}));E(t=>{const h=new Set(t.map(r=>r.id));return[...t,...a.filter(r=>!h.has(r.id))]}),O.current&&(O.current.value="")},L=(e,i)=>{E(a=>a.map(t=>t.id===e?{...t,...i,error:""}:t))},po=async()=>{if(x||!_||j.length===0)return;V(!0);let e=0;const i=new Set;for(const a of j){if(!a.caption.trim()){i.add(a.id),L(a.id,{error:"Add a short description of this photo."});continue}const t=new FormData;t.append("original",a.file),t.append("shoot_id",_),t.append("title",a.title.trim()),t.append("caption",a.caption.trim());try{await g.uploadImage(t),e+=1,E(h=>h.filter(r=>r.id!==a.id))}catch(h){i.add(a.id),L(a.id,{error:h.message||"Upload failed. Please retry this photo."})}}V(!1),e&&(s(`${e} photo${e===1?"":"s"} uploaded.`),C(),S()),i.size&&s(`${i.size} photo${i.size===1?"":"s"} still need attention. Failed files remain in the queue; successful files were saved.`,"error")},co=async e=>{try{await g.updateImage({id:e.id,is_cover:!0}),C()}catch(i){s(i.message,"error")}},mo=async e=>{const i=W[e.id]||{},a=(i.title??e.title??"").trim(),t=(i.caption??e.caption??"").trim();if(!t){s("Add a short description of what is shown in the photo.","error");return}K(e.id);try{await g.updateImage({id:e.id,title:a,caption:t}),s("Photo description saved."),M(h=>{const r={...h};return delete r[e.id],r}),C()}catch(h){s(h.message,"error")}finally{K(null)}},ho=async e=>{try{await g.updateImage({...e,visible:e.visible?0:1}),C()}catch(i){s(i.message,"error")}},fo=async()=>{if(f)try{f.type==="category"&&(await g.deleteCategory(f.id),v===f.id&&(z(null),A(null),k(null),y(null)),T()),f.type==="shoot"&&(await g.deleteShoot(f.id),_===f.id&&(A(null),y(null)),S()),f.type==="image"&&(await g.deleteImage(f.id),C(),S()),s("Deleted."),P(null)}catch(e){s(e.message,"error")}},b=c==null?void 0:c.find(e=>e.id===v),n=d==null?void 0:d.find(e=>e.id===_),J=(m==null?void 0:m.filter(e=>!!e.visible).length)||0,[go,_o]=vo(),X=(e,i)=>{var h;const a=e==="PORTFOLIO_SHOOT",t=(h=a?d:m)==null?void 0:h.find(r=>r.id===i);go({title:a?"Flag this portfolio shoot":"Flag this portfolio photo",summary:[{label:a?"Shoot":"Photo",value:(t==null?void 0:t.title)||(t==null?void 0:t.caption)||`#${i}`},{label:"Current state",value:(t==null?void 0:t.visible)===!1||Number(t==null?void 0:t.visible)===0?"Hidden · no open flag":"Published · no open flag"}],onSubmit:async r=>{Q(`${e}-${i}`);try{const N=await bo.createFlag({entity_type:e,entity_id:i,reason:r});a?k(H=>H.map(w=>w.id===i?{...w,open_flag_count:1,latest_flag_reason:r}:w)):y(H=>H.map(w=>w.id===i?{...w,open_flag_count:1,latest_flag_reason:r}:w)),s(N.message)}finally{Q("")}}})};return o.jsxs(o.Fragment,{children:[_o,o.jsx("style",{children:`

        /*
        ============================================================
        PORTFOLIO MANAGER
        ============================================================
        */

        .portfolio-admin {
          --portfolio-border:
            var(--c-hairline);

          --portfolio-muted:
            var(--c-gray);

          width: 100%;
        }

        /*
        ============================================================
        HEADER
        ============================================================
        */

        .portfolio-admin__header {
          display: flex;
          align-items: flex-end;
          justify-content: space-between;

          gap: 30px;

          margin-bottom: 28px;
        }

        .portfolio-admin__eyebrow {
          display: block;

          margin-bottom: 7px;

          color:
            var(--portfolio-muted);

          /*
            Typography intentionally inherited
            from your existing admin styles.
          */
        }

        .portfolio-admin__title {
          margin: 0;

          /*
            IMPORTANT:
            Do not define a font here.
            This allows AdminLayout's existing
            typography to remain in control.
          */
        }

        .portfolio-admin__stats {
          display: flex;
          align-items: center;

          gap: 24px;

          color:
            var(--portfolio-muted);
        }

        .portfolio-admin__stat strong {
          display: block;

          margin-bottom: 3px;

          color:
            var(--c-text);

          /*
            No custom font declaration.
            No custom letter spacing.
          */
        }

        /*
        ============================================================
        WORKSPACE
        ============================================================
        */

        .portfolio-admin__workspace {
          display: grid;

          grid-template-columns:
            230px
            300px
            minmax(0, 1fr);

          min-height: 650px;

          overflow: hidden;

          border:
            1px solid
            var(--portfolio-border);

          background:
            var(--c-bg, #fff);
        }

        /*
        ============================================================
        SIDEBARS
        ============================================================
        */

        .portfolio-admin__sidebar {
          min-width: 0;

          border-right:
            1px solid
            var(--portfolio-border);
        }

        .portfolio-admin__sidebar--shoots {
          background:
            rgba(
              0,
              0,
              0,
              0.015
            );
        }

        .portfolio-admin__sidebar-header {
          display: flex;
          align-items: center;
          justify-content: space-between;

          min-height: 58px;

          padding:
            0 16px;

          border-bottom:
            1px solid
            var(--portfolio-border);
        }

        .portfolio-admin__sidebar-title {
          margin: 0;

          /*
            Existing typography is inherited.
          */
        }

        .portfolio-admin__count {
          color:
            var(--portfolio-muted);
        }

        /*
        ============================================================
        CATEGORY LIST
        ============================================================
        */

        .portfolio-admin__list {
          padding: 8px;
        }

        .portfolio-admin__list-item {
          position: relative;

          display: flex;
          align-items: center;
          justify-content: space-between;

          width: 100%;

          min-height: 48px;

          padding:
            8px 10px;

          margin-bottom: 2px;

          border: 0;

          background:
            transparent;

          color:
            var(--c-text);

          text-align: left;

          cursor: pointer;

          /*
            Only visual transitions.
          */

          transition:
            background 0.2s ease,
            color 0.2s ease;
        }

        .portfolio-admin__list-item:hover {
          background:
            rgba(
              0,
              0,
              0,
              0.035
            );
        }

        .portfolio-admin__list-item.active {
          background:
            var(--c-text);

          color:
            var(--c-bg, #fff);
        }

        .portfolio-admin__list-item-main {
          display: flex;
          align-items: center;

          min-width: 0;

          gap: 9px;
        }

        .portfolio-admin__list-item-icon {
          flex: 0 0 auto;
        }

        .portfolio-admin__list-item-open {
          display: grid;
          flex: 0 0 auto;
          place-items: center;
          width: 32px;
          height: 32px;
          margin: -6px 0 -6px -6px;
          padding: 0;
          border: 0;
          border-radius: 4px;
          background: transparent;
          color: inherit;
          cursor: pointer;
        }

        .portfolio-admin__list-item input {
          min-width: 0;

          width: 100%;

          border: 0;

          outline: 0;

          background:
            transparent;

          color:
            inherit;

          font: inherit;
        }

        /*
        ============================================================
        STATUS
        ============================================================
        */

        .portfolio-admin__status {
          display: inline-flex;

          align-items: center;

          flex: 0 0 auto;

          padding:
            3px 6px;

          border:
            1px solid
            rgba(
              128,
              128,
              128,
              0.3
            );

          /*
            No custom typography.
          */
        }

        .portfolio-admin__status--hidden {
          opacity: 0.7;
        }

        /*
        ============================================================
        ADD CATEGORY
        ============================================================
        */

        .portfolio-admin__add {
          display: flex;

          gap: 6px;

          padding:
            10px 8px 8px;
        }

        .portfolio-admin__add input {
          min-width: 0;

          flex: 1;

          height: 38px;

          padding:
            0 10px;

          border:
            1px solid
            var(--portfolio-border);

          background:
            transparent;

          color:
            var(--c-text);

          outline: none;

          font: inherit;
        }

        .portfolio-admin__add input:focus {
          border-color:
            var(--c-text);
        }

        /*
        ============================================================
        SHOOT LIST
        ============================================================
        */

        .portfolio-admin__shoot {
          display: flex;

          align-items: center;
          justify-content: space-between;

          width: 100%;

          gap: 12px;

          min-height: 58px;

          padding:
            10px 12px;

          border: 0;

          border-bottom:
            1px solid
            var(--portfolio-border);

          background:
            transparent;

          color:
            var(--c-text);

          text-align: left;

          cursor: pointer;

          transition:
            background 0.2s ease;
        }

        .portfolio-admin__shoot:hover {
          background:
            rgba(
              0,
              0,
              0,
              0.035
            );
        }

        .portfolio-admin__shoot.active {
          background:
            rgba(
              0,
              0,
              0,
              0.06
            );
        }

        .portfolio-admin__shoot-info {
          min-width: 0;
        }

        .portfolio-admin__shoot-title {
          display: block;

          overflow: hidden;

          text-overflow: ellipsis;

          white-space: nowrap;
        }

        .portfolio-admin__shoot-meta {
          display: flex;

          align-items: center;

          gap: 8px;

          margin-top: 4px;

          color:
            var(--portfolio-muted);
        }

        /*
        ============================================================
        MAIN PANEL
        ============================================================
        */

        .portfolio-admin__main {
          min-width: 0;

          background:
            var(--c-bg, #fff);
        }

        .portfolio-admin__main-header {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap: 20px;

          min-height: 58px;

          padding:
            0 20px;

          border-bottom:
            1px solid
            var(--portfolio-border);
        }

        .portfolio-admin__main-heading {
          min-width: 0;
        }

        .portfolio-admin__main-heading h2 {
          margin: 0;

          overflow: hidden;

          text-overflow: ellipsis;

          white-space: nowrap;
        }

        .portfolio-admin__main-heading p {
          margin:
            4px 0 0;

          color:
            var(--portfolio-muted);
        }

        /*
        ============================================================
        MAIN CONTROLS
        ============================================================
        */

        .portfolio-admin__controls {
          display: flex;
          align-items: center;

          gap: 8px;

          flex: 0 0 auto;
        }

        .portfolio-admin__control-button {
          display: inline-flex;

          align-items: center;
          justify-content: center;

          gap: 6px;

          min-height: 32px;

          padding:
            0 10px;

          border:
            1px solid
            var(--portfolio-border);

          background:
            transparent;

          color:
            var(--c-text);

          cursor: pointer;

          transition:
            background 0.2s ease,
            border-color 0.2s ease;
        }

        .portfolio-admin__control-button:hover {
          background:
            rgba(
              0,
              0,
              0,
              0.04
            );

          border-color:
            var(--c-text);
        }

        .portfolio-admin__control-button--danger {
          color:
            #B3261E;

          border-color:
            rgba(
              179,
              38,
              30,
              0.3
            );
        }

        /*
        ============================================================
        TOOLBAR
        ============================================================
        */

        .portfolio-admin__toolbar {
          display: flex;

          align-items: center;
          justify-content: space-between;

          gap: 16px;

          padding:
            12px 20px;

          border-bottom:
            1px solid
            var(--portfolio-border);
        }

        .portfolio-admin__toolbar-note {
          color:
            var(--portfolio-muted);
        }

        /*
        ============================================================
        UPLOAD
        ============================================================
        */

        .portfolio-admin__upload {
          position: relative;

          display: flex;

          align-items: center;
          justify-content: center;

          min-height: 100px;

          margin:
            18px 20px;

          padding:
            20px;

          border:
            1px dashed
            var(--portfolio-border);

          background:
            rgba(
              0,
              0,
              0,
              0.012
            );

          color:
            var(--portfolio-muted);

          text-align: center;

          cursor: pointer;

          transition:
            border-color 0.2s ease,
            background 0.2s ease;
        }

        .portfolio-admin__upload:hover {
          border-color:
            var(--c-text);

          background:
            rgba(
              0,
              0,
              0,
              0.025
            );
        }

        .portfolio-admin__upload-icon {
          display: block;

          margin-bottom: 8px;

          color:
            var(--c-text);
        }

        .portfolio-admin__upload-title {
          color:
            var(--c-text);
        }

        .portfolio-admin__upload-subtitle {
          margin-top: 5px;

          color:
            var(--portfolio-muted);
        }

        /*
        ============================================================
        IMAGE GRID
        ============================================================
        */

        .portfolio-admin__images {
          display: grid;

          grid-template-columns:
            repeat(
              3,
              minmax(0, 1fr)
            );

          gap: 1px;

          padding:
            0 20px 20px;
        }

        .portfolio-admin__image {
          position: relative;
          min-width: 0;
          overflow: visible;
          background: #fff;
          border: 1px solid var(--portfolio-border);
        }

        .portfolio-admin__image-preview {
          position: relative;
          aspect-ratio: 1 / 1;
          overflow: hidden;
          background: #f2f2f2;
        }

        .portfolio-admin__image img {
          display: block;

          width: 100%;
          height: 100%;

          object-fit: cover;

          transition:
            transform 0.45s ease,
            opacity 0.25s ease;
        }

        .portfolio-admin__image:hover .portfolio-admin__image-preview img {
          transform:
            scale(1.025);
        }

        /*
        ============================================================
        IMAGE OVERLAY
        ============================================================
        */

        .portfolio-admin__image-overlay {
          position: absolute;

          inset: 0;

          display: flex;

          flex-direction: column;

          justify-content: space-between;

          padding: 10px;

          background:
            linear-gradient(
              to bottom,
              rgba(
                0,
                0,
                0,
                0.32
              ),
              transparent 30%,
              transparent 65%,
              rgba(
                0,
                0,
                0,
                0.64
              )
            );

          opacity: 0;

          transition:
            opacity 0.25s ease;
        }

        .portfolio-admin__image:hover .portfolio-admin__image-overlay,
        .portfolio-admin__image:focus-within .portfolio-admin__image-overlay {
          opacity: 1;
        }

        .portfolio-admin__image-cover {
          align-self: flex-start;

          display: inline-flex;

          align-items: center;

          gap: 5px;

          padding:
            5px 7px;

          background:
            rgba(
              255,
              255,
              255,
              0.92
            );

          color:
            #111;
        }

        .portfolio-admin__image-actions {
          display: flex;

          align-items: center;

          gap: 5px;
        }

        .portfolio-admin__image-action {
          display: inline-flex;

          align-items: center;
          justify-content: center;

          min-width: 28px;
          min-height: 28px;

          padding:
            0 7px;

          border: 0;

          background:
            rgba(
              0,
              0,
              0,
              0.68
            );

          color: #fff;

          cursor: pointer;

          transition:
            background 0.2s ease;
        }

        .portfolio-admin__image-action:hover {
          background:
            rgba(
              0,
              0,
              0,
              0.88
            );
        }

        .portfolio-admin__image-action--danger {
          background:
            rgba(
              179,
              38,
              30,
              0.85
            );
        }

        /*
        ============================================================
        EMPTY / PLACEHOLDER
        ============================================================
        */

        .portfolio-admin__placeholder {
          min-height: 400px;

          display: flex;

          align-items: center;
          justify-content: center;

          padding: 40px;
        }

        .portfolio-admin__shoot-form {
          margin:
            12px 8px 8px;

          padding:
            14px;

          border:
            1px solid
            var(--portfolio-border);

          background:
            rgba(
              0,
              0,
              0,
              0.015
            );
        }

        .portfolio-admin__form-title {
          margin:
            0 0 12px;
        }

        .portfolio-admin__form {
          display: flex;

          flex-direction: column;

          gap: 7px;
        }

        .portfolio-admin__form input,
        .portfolio-admin__form textarea {
          width: 100%;

          padding:
            9px 10px;

          border:
            1px solid
            var(--portfolio-border);

          background:
            transparent;

          color:
            var(--c-text);

          outline: none;

          font: inherit;
        }

        .portfolio-admin__form textarea {
          min-height: 65px;

          resize: vertical;
        }

        .portfolio-admin__form input:focus,
        .portfolio-admin__form textarea:focus {
          border-color:
            var(--c-text);
        }

        /*
        ============================================================
        RESPONSIVE
        ============================================================
        */

        @media (max-width: 1100px) {

          .portfolio-admin__workspace {
            grid-template-columns:
              200px
              260px
              minmax(0, 1fr);
          }

          .portfolio-admin__images {
            grid-template-columns:
              repeat(
                2,
                minmax(0, 1fr)
              );
          }

        }

        @media (max-width: 850px) {

          .portfolio-admin__workspace {
            grid-template-columns:
              190px
              minmax(0, 1fr);
          }

          .portfolio-admin__sidebar--shoots {
            grid-column: 1 / -1;

            border-right: 0;

            border-top:
              1px solid
              var(--portfolio-border);
          }

          .portfolio-admin__main {
            grid-column: 1 / -1;
          }

          .portfolio-admin__sidebar:first-child {
            grid-row: 1;
          }

          .portfolio-admin__sidebar--shoots {
            grid-row: 2;
          }

          .portfolio-admin__main {
            grid-row: 3;
          }

        }

        @media (max-width: 600px) {

          .portfolio-admin__header {
            align-items: flex-start;

            flex-direction: column;

            gap: 16px;
          }

          .portfolio-admin__stats {
            width: 100%;

            justify-content: space-between;
          }

          .portfolio-admin__workspace {
            display: flex;

            flex-direction: column;
          }

          .portfolio-admin__sidebar,
          .portfolio-admin__sidebar--shoots {
            border-right: 0;
          }

          .portfolio-admin__sidebar-header {
            min-height: 52px;
          }

          .portfolio-admin__list {
            display: flex;

            overflow-x: auto;

            gap: 4px;

            padding:
              8px;
          }

          .portfolio-admin__list-item {
            flex: 0 0 auto;

            width: auto;

            min-width: 120px;
          }

          .portfolio-admin__add {
            padding:
              8px;
          }

          .portfolio-admin__images {
            grid-template-columns:
              repeat(
                2,
                minmax(0, 1fr)
              );

            padding:
              0 10px 10px;
          }

          .portfolio-admin__upload {
            margin:
              12px 10px;
          }

          .portfolio-admin__main-header {
            padding:
              10px;
          }

          .portfolio-admin__toolbar {
            padding:
              10px;
          }

        }

        /*
        ============================================================
        REDUCED MOTION
        ============================================================
        */

        @media (
          prefers-reduced-motion: reduce
        ) {

          .portfolio-admin__list-item,
          .portfolio-admin__control-button,
          .portfolio-admin__upload,
          .portfolio-admin__image img,
          .portfolio-admin__image-overlay {
            transition: none;
          }

        }

      `}),o.jsxs("div",{className:"admin-content portfolio-admin",children:[o.jsxs("header",{className:"portfolio-admin__header",children:[o.jsxs("div",{children:[o.jsx("span",{className:"portfolio-admin__eyebrow",children:"Content Management"}),o.jsx("h2",{className:"display",children:p?"Portfolio Oversight":"Portfolio"})]}),o.jsxs("div",{className:"portfolio-admin__stats",children:[o.jsxs("div",{className:"portfolio-admin__stat",children:[o.jsx("strong",{children:(c==null?void 0:c.length)||0}),"Categories"]}),o.jsxs("div",{className:"portfolio-admin__stat",children:[o.jsx("strong",{children:(d==null?void 0:d.length)||0}),"Shoots"]}),o.jsxs("div",{className:"portfolio-admin__stat",children:[o.jsx("strong",{children:J}),"Visible Photos"]})]})]}),o.jsxs("div",{className:"portfolio-admin__workspace",children:[o.jsxs("aside",{className:"portfolio-admin__sidebar",children:[o.jsxs("div",{className:"portfolio-admin__sidebar-header",children:[o.jsx("h2",{className:"portfolio-admin__sidebar-title",children:"Categories"}),o.jsx("span",{className:"portfolio-admin__count",children:(c==null?void 0:c.length)||0})]}),c===null&&o.jsx("div",{style:{padding:20},children:o.jsx(U,{label:"Loading…"})}),c&&c.length===0&&o.jsx("div",{style:{padding:20},children:o.jsx(G,{title:"No categories yet."})}),c&&c.length>0&&o.jsx("div",{className:"portfolio-admin__list",children:c.map(e=>{const i=v===e.id,a=()=>z(e.id);return o.jsxs("div",{className:`portfolio-admin__list-item ${i?"active":""}`,onClick:a,children:[o.jsxs("span",{className:"portfolio-admin__list-item-main",children:[o.jsx("button",{type:"button",className:"portfolio-admin__list-item-open",onClick:t=>{t.stopPropagation(),a()},"aria-pressed":i,"aria-label":`Show shoots in ${e.name}`,children:o.jsx(wo,{size:14,"aria-hidden":"true"})}),p?o.jsx("span",{children:e.name}):o.jsx("input",{"aria-label":`Category name: ${e.name}`,value:e.name,onFocus:a,onClick:t=>t.stopPropagation(),onChange:t=>!p&&no(e,t.target.value)})]}),!e.visible&&o.jsx("span",{className:"portfolio-admin__status portfolio-admin__status--hidden",children:"Hidden"}),i&&o.jsx(oo,{size:14,"aria-hidden":"true"})]},e.id)})}),!p&&o.jsxs("form",{onSubmit:ro,className:"portfolio-admin__add",children:[o.jsx("input",{type:"text","aria-label":"New category name",placeholder:"New category",value:q,onChange:e=>B(e.target.value)}),o.jsx("button",{type:"submit",className:"btn btn--sm btn--primary",title:"Add category","aria-label":"Add category",children:o.jsx(eo,{size:14})})]})]}),o.jsxs("aside",{className:"portfolio-admin__sidebar portfolio-admin__sidebar--shoots",children:[o.jsxs("div",{className:"portfolio-admin__sidebar-header",children:[o.jsx("h2",{className:"portfolio-admin__sidebar-title",children:b?b.name:"Shoots"}),o.jsx("span",{className:"portfolio-admin__count",children:(d==null?void 0:d.length)||0})]}),!b&&o.jsx("div",{className:"portfolio-admin__placeholder",style:{minHeight:240},children:o.jsx("p",{style:{color:"var(--c-gray)",margin:0,textAlign:"center"},children:"Select a category to manage its shoots."})}),b&&d===null&&o.jsx("div",{style:{padding:20},children:o.jsx(U,{label:"Loading…"})}),b&&d&&d.length===0&&o.jsx("div",{style:{padding:12},children:o.jsx(G,{title:"No shoots yet.",body:"Create the first shoot below."})}),b&&d&&d.length>0&&o.jsx("div",{children:d.map(e=>o.jsxs("button",{type:"button",className:`
                          portfolio-admin__shoot
                          ${_===e.id?"active":""}
                        `,onClick:()=>A(e.id),children:[o.jsxs("span",{className:"portfolio-admin__shoot-info",children:[o.jsx("span",{className:"portfolio-admin__shoot-title",children:e.title}),o.jsxs("span",{className:"portfolio-admin__shoot-meta",children:[o.jsx(xo,{size:10}),e.image_count||0," ","photos",!e.visible&&o.jsxs(o.Fragment,{children:[o.jsx("span",{children:"·"}),"Hidden"]}),Number(e.open_flag_count)>0&&o.jsxs(o.Fragment,{children:[o.jsx("span",{children:"·"}),o.jsx("strong",{title:e.latest_flag_reason,children:"Flagged"})]})]})]}),o.jsx(oo,{size:13})]},e.id))}),b&&!p&&o.jsxs("div",{className:"portfolio-admin__shoot-form",children:[o.jsx("h3",{className:"portfolio-admin__form-title",children:"New Shoot"}),o.jsxs("form",{onSubmit:lo,className:"portfolio-admin__form",children:[o.jsx("input",{type:"text",placeholder:"Shoot title",required:!0,value:u.title,onChange:e=>I({...u,title:e.target.value})}),o.jsx("input",{type:"text",placeholder:"Location",value:u.location,onChange:e=>I({...u,location:e.target.value})}),o.jsx("input",{type:"date",value:u.shoot_date,onChange:e=>I({...u,shoot_date:e.target.value})}),o.jsx("textarea",{placeholder:"Description",value:u.description,onChange:e=>I({...u,description:e.target.value})}),o.jsxs("button",{type:"submit",className:"btn btn--sm btn--primary",children:[o.jsx(eo,{size:13}),"Add Shoot"]})]})]})]}),o.jsxs("div",{className:"portfolio-admin__main",children:[!n&&o.jsx("div",{className:"portfolio-admin__placeholder",children:o.jsxs("div",{style:{textAlign:"center",maxWidth:360},children:[o.jsx(ko,{size:30,strokeWidth:1.2,style:{marginBottom:12,opacity:.5}}),o.jsx("h2",{style:{margin:"0 0 8px"},children:"Select a shoot"}),o.jsx("p",{style:{margin:0,color:"var(--c-gray)",lineHeight:1.6},children:"Choose a shoot from the list to upload, organize, and manage its photographs."})]})}),n&&o.jsxs(o.Fragment,{children:[o.jsxs("div",{className:"portfolio-admin__main-header",children:[o.jsxs("div",{className:"portfolio-admin__main-heading",children:[o.jsx("h2",{children:n.title}),o.jsxs("p",{children:[b==null?void 0:b.name,n.location?` · ${n.location}`:""]})]}),o.jsxs("div",{className:"portfolio-admin__controls",children:[p&&o.jsx("button",{type:"button",className:"portfolio-admin__control-button is-flag",disabled:D===`PORTFOLIO_SHOOT-${n.id}`||Number(n.open_flag_count)>0,onClick:()=>X("PORTFOLIO_SHOOT",n.id),children:D===`PORTFOLIO_SHOOT-${n.id}`?"Flagging…":Number(n.open_flag_count)>0?"Flagged":"Flag shoot"}),!p&&o.jsxs("label",{className:"portfolio-admin__control-button",title:"Publish or hide shoot",children:[n.visible?o.jsx(io,{size:13}):o.jsx(Z,{size:13}),o.jsx("input",{type:"checkbox",checked:!!n.visible,onChange:()=>Y(n),style:{display:"none"}}),o.jsx("span",{onClick:()=>Y(n),children:n.visible?"Published":"Hidden"})]}),!p&&o.jsxs("button",{type:"button",className:`\r
                        portfolio-admin__control-button\r
                        portfolio-admin__control-button--danger\r
                      `,onClick:()=>P({type:"shoot",id:n.id,label:n.title}),children:[o.jsx(to,{size:13}),"Delete"]})]})]}),o.jsxs("div",{className:"portfolio-admin__toolbar",children:[o.jsx("span",{className:"portfolio-admin__toolbar-note",children:m===null?"Loading photos…":`${m.length} photo${m.length!==1?"s":""} in this shoot`}),m&&m.length>0&&o.jsxs("span",{className:"portfolio-admin__toolbar-note",children:[J," ","visible"]})]}),!p&&o.jsxs("div",{className:"portfolio-admin__upload",onClick:()=>{var e;return!x&&((e=O.current)==null?void 0:e.click())},role:"button",tabIndex:x?-1:0,onKeyDown:e=>{var i;!x&&(e.key==="Enter"||e.key===" ")&&(e.preventDefault(),(i=O.current)==null||i.click())},"aria-disabled":x,children:[o.jsxs("div",{children:[o.jsx(No,{size:23,className:"portfolio-admin__upload-icon"}),o.jsx("div",{className:"portfolio-admin__upload-title",children:"Add photographs"}),o.jsx("div",{className:"portfolio-admin__upload-subtitle",children:"Select one or more JPG, PNG, or WEBP files. Add a description to each photo before uploading."})]}),o.jsx("input",{ref:O,type:"file",accept:`\r
                      image/jpeg,\r
                      image/png,\r
                      image/webp\r
                    `,multiple:!0,hidden:!0,onChange:so})]}),!p&&j.length>0&&o.jsxs("section",{className:"portfolio-upload-queue","aria-label":"Photos ready to upload",children:[o.jsx("h3",{children:"Describe each photo"}),o.jsx("p",{children:"Descriptions appear with the photo on its story page. Uploads run one at a time; failed files stay here for retry."}),j.map(e=>o.jsxs("div",{className:"portfolio-upload-queue__item",children:[o.jsxs("div",{className:"portfolio-upload-queue__file",children:[o.jsx("strong",{children:e.file.name}),o.jsxs("span",{children:[(e.file.size/(1024*1024)).toFixed(2)," MB"]}),o.jsx("button",{type:"button",className:"portfolio-upload-queue__remove",disabled:x,onClick:()=>E(i=>i.filter(a=>a.id!==e.id)),children:"Remove"})]}),o.jsxs("label",{children:["Photo title ",o.jsx("span",{children:"(optional)"}),o.jsx("input",{maxLength:160,value:e.title,disabled:x,placeholder:"e.g. The couple’s first dance",onChange:i=>L(e.id,{title:i.target.value})})]}),o.jsxs("label",{children:["What is happening in this photo? ",o.jsx("span",{children:"(required)"}),o.jsx("textarea",{maxLength:2e3,required:!0,value:e.caption,disabled:x,placeholder:"Describe the moment, people, or setting shown.",onChange:i=>L(e.id,{caption:i.target.value})})]}),e.error&&o.jsx("p",{className:"portfolio-upload-queue__error",role:"alert",children:e.error})]},e.id)),o.jsx("button",{type:"button",className:"btn btn--sm btn--primary",disabled:x||j.some(e=>!e.caption.trim()),onClick:po,children:x?"Uploading photos one at a time…":`Upload ${j.length} photo${j.length===1?"":"s"}`})]}),m===null&&o.jsx("div",{style:{padding:"30px 20px"},children:o.jsx(U,{label:"Loading photos…"})}),m&&m.length===0&&o.jsx("div",{style:{padding:"15px 20px 40px"},children:o.jsx(G,{title:"No photos yet.",body:"Upload the first photograph above."})}),m&&m.length>0&&o.jsx("div",{className:"portfolio-admin__images",children:m.map(e=>o.jsxs("article",{className:"portfolio-admin__image",children:[o.jsxs("div",{className:"portfolio-admin__image-preview",children:[o.jsx("img",{src:yo(e.image_path),alt:e.title||e.caption||"Portfolio photograph",style:{opacity:e.visible?1:.35}}),o.jsxs("div",{className:"portfolio-admin__image-overlay",children:[e.is_cover&&o.jsxs("span",{className:"portfolio-admin__image-cover",children:[o.jsx(ao,{size:10}),"Cover"]}),Number(e.open_flag_count)>0&&o.jsx("span",{className:"portfolio-admin__image-cover",title:e.latest_flag_reason,children:"Flagged"}),o.jsx("div",{}),o.jsxs("div",{className:"portfolio-admin__image-actions",children:[p&&o.jsx("button",{type:"button",className:"portfolio-admin__image-action is-flag",disabled:D===`PORTFOLIO_IMAGE-${e.id}`||Number(e.open_flag_count)>0,onClick:()=>X("PORTFOLIO_IMAGE",e.id),children:D===`PORTFOLIO_IMAGE-${e.id}`?"Flagging…":Number(e.open_flag_count)>0?"Flagged":"Flag photo"}),!p&&o.jsx("button",{type:"button",className:"portfolio-admin__image-action",onClick:()=>co(e),title:"Set as cover",children:o.jsx(ao,{size:12})}),!p&&o.jsx("button",{type:"button",className:"portfolio-admin__image-action",onClick:()=>ho(e),title:e.visible?"Hide photo":"Show photo",children:e.visible?o.jsxs(o.Fragment,{children:[o.jsx(Z,{size:12}),"Hide"]}):o.jsxs(o.Fragment,{children:[o.jsx(io,{size:12}),"Show"]})}),!p&&o.jsx("button",{type:"button",className:`\r
                                    portfolio-admin__image-action\r
                                    portfolio-admin__image-action--danger\r
                                  `,onClick:()=>P({type:"image",id:e.id,label:"this photo"}),title:"Delete photo",children:o.jsx(to,{size:12})})]})]})]}),!p&&(()=>{const i=W[e.id]||{},a=i.title??e.title??"",t=i.caption??e.caption??"",h=a!==(e.title||"")||t!==(e.caption||"");return o.jsxs("div",{className:"portfolio-admin__image-description",children:[o.jsxs("label",{children:["Photo title ",o.jsx("span",{children:"(optional)"}),o.jsx("input",{maxLength:160,value:a,disabled:F===e.id,onChange:r=>M(N=>({...N,[e.id]:{...N[e.id],title:r.target.value}}))})]}),o.jsxs("label",{children:["What is happening in this photo? ",o.jsx("span",{children:"(required)"}),o.jsx("textarea",{maxLength:2e3,value:t,disabled:F===e.id,placeholder:"Describe the moment, people, or setting shown.",onChange:r=>M(N=>({...N,[e.id]:{...N[e.id],caption:r.target.value}}))})]}),o.jsx("button",{type:"button",className:"btn btn--sm btn--outline",disabled:!h||F===e.id||!t.trim(),onClick:()=>mo(e),children:F===e.id?"Saving…":h?"Save photo text":t?"Description saved":"Add description"})]})})()]},e.id))})]})]})]})]}),f&&o.jsx(jo,{title:`
            Delete ${f.type==="category"?"category":f.type==="shoot"?"shoot":"photo"} "${f.label}"?
          `,body:f.type!=="image"?"This will also delete everything inside it. This cannot be undone.":"This cannot be undone.",confirmLabel:"Delete",danger:!0,onConfirm:fo,onClose:()=>P(null)})]})}export{Lo as default};
