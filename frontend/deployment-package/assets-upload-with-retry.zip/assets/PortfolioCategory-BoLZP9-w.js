import{f as v,r as a,p as h,j as t,L as w,e as E}from"./index-ZwdCBnk2.js";import{E as j}from"./EditorialImage-CZAsaQMl.js";import{E as N}from"./EmptyState-CwOvTTML.js";import"./format-C7C3p2s4.js";function k(){var g;const{category:n}=v(),[r,p]=a.useState(null),[m,x]=a.useState([]),c=a.useRef([]);a.useEffect(()=>{let o=!1;return p(null),c.current=[],h.imagesByCategory(n).then(e=>{o||p(Array.isArray(e)?e:[])}).catch(()=>{o||p([])}),h.categories().then(e=>{o||x(Array.isArray(e)?e:[])}).catch(()=>{}),()=>{o=!0}},[n]);const s=((g=m.find(o=>o.slug===n))==null?void 0:g.name)||n;a.useEffect(()=>{document.title=`Jonathan Photography — ${s}`},[s]);const f=()=>typeof window>"u"?3:window.innerWidth<=600?1:window.innerWidth<=900?2:3,[l,u]=a.useState(f);a.useEffect(()=>{const o=()=>{u(f())};return window.addEventListener("resize",o),()=>{window.removeEventListener("resize",o)}},[]);const y=a.useMemo(()=>{if(!r||r.length===0)return[];const o=Array.from({length:l},()=>[]);return r.forEach((e,i)=>{o[i%l].push({image:e,originalIndex:i})}),o},[r,l]);a.useEffect(()=>{if(!r||r.length===0)return;const o=c.current.filter(Boolean);if(!o.length)return;if(!("IntersectionObserver"in window)){o.forEach(i=>{i.classList.add("portfolio-photo--visible")});return}const e=new IntersectionObserver(i=>{i.forEach(d=>{d.isIntersecting&&(d.target.classList.add("portfolio-photo--visible"),e.unobserve(d.target))})},{threshold:.08,rootMargin:"0px 0px -8% 0px"});return o.forEach(i=>{e.observe(i)}),()=>{e.disconnect()}},[r,l]);const b=({image:o,originalIndex:e})=>t.jsxs("article",{ref:i=>{c.current[e]=i},className:"portfolio-photo",children:[t.jsx(j,{src:o.image_path,alt:o.title||`${s} photograph ${e+1}`}),o.caption&&t.jsx("p",{className:"portfolio-photo__caption",children:o.caption})]},o.id);return t.jsxs("section",{className:"portfolio-category-page",children:[t.jsx("style",{children:`

        /*
        ============================================================
        PAGE
        ============================================================
        */

        .portfolio-category-page {
          width: 100%;
          min-height: 100vh;

          margin: 0;
          padding: 0;

          background:
            var(--c-bg, #fff);
        }

        /*
        ============================================================
        HEADER
        ============================================================
        */

        .portfolio-category-header {
          width: 100%;

          padding:
            clamp(95px, 10vw, 135px)
            28px
            26px;

          position: relative;
          z-index: 10;
        }

        .portfolio-category-header-inner {
          display: flex;

          align-items: flex-end;
          justify-content: space-between;

          gap: 30px;
        }

        /*
          Back link
        */

        .portfolio-category-back {
          display: inline-flex;

          align-items: center;

          color:
            var(--c-gray);

          text-decoration: none;

          text-transform: uppercase;

          font-size: 0.68rem;

          letter-spacing: 2.5px;

          white-space: nowrap;

          transition:
            color 0.25s ease;
        }

        .portfolio-category-back:hover {
          color:
            var(--c-text);
        }

        /*
        ============================================================
        GALLERY
        ============================================================
        */

        .portfolio-gallery {
          width: 100%;

          display: grid;

          grid-template-columns:
            repeat(
              3,
              minmax(0, 1fr)
            );

          gap: 0;

          margin: 0;
          padding: 0;
        }

        /*
        ============================================================
        INDEPENDENT COLUMNS
        ============================================================
        */

        .portfolio-gallery-column {
          width: 100%;

          display: flex;

          flex-direction: column;

          gap: 0;

          margin: 0;
          padding: 0;
        }

        /*
        ============================================================
        PHOTO
        ============================================================
        */

        .portfolio-photo {
          width: 100%;

          position: relative;

          margin: 0;
          padding: 0;

          overflow: hidden;

          opacity: 0;

          transform:
            translateY(65px)
            scale(0.985);

          transition:
            opacity 1s
              cubic-bezier(
                0.22,
                1,
                0.36,
                1
              ),

            transform 1.15s
              cubic-bezier(
                0.22,
                1,
                0.36,
                1
              );

          will-change:
            opacity,
            transform;
        }

        .portfolio-photo__caption {
          margin: 0;
          padding: 12px 16px 18px;
          color: var(--c-gray);
          font-size: 0.82rem;
          line-height: 1.55;
        }

        .portfolio-photo--visible {
          opacity: 1;

          transform:
            translateY(0)
            scale(1);
        }

        /*
        ============================================================
        EDITORIAL IMAGE
        ============================================================
        */

        .portfolio-photo
        .editorial-image {
          width: 100%;

          margin: 0;
          padding: 0;
        }

        .portfolio-photo
        .editorial-image img {
          display: block;

          width: 100%;
          height: auto;

          margin: 0;
          padding: 0;

          object-fit: cover;

          transition:
            transform 1.4s
              cubic-bezier(
                0.22,
                1,
                0.36,
                1
              );

          will-change:
            transform;
        }

        .portfolio-photo--portrait
        .editorial-image {
          aspect-ratio: 3 / 4;
        }

        .portfolio-photo--landscape
        .editorial-image {
          aspect-ratio: 4 / 3;
        }

        .portfolio-photo--portrait
        .editorial-image img,
        .portfolio-photo--landscape
        .editorial-image img {
          height: 100%;
          object-fit: cover;
        }

        /*
        ============================================================
        HOVER
        ============================================================
        */

        .portfolio-photo:hover
        .editorial-image img {
          transform:
            scale(1.025);
        }

        /*
        ============================================================
        NUMBER
        ============================================================
        */

        .portfolio-photo-index {
          position: absolute;

          left: 14px;
          bottom: 12px;

          z-index: 3;

          color: #fff;

          font-size: 0.62rem;

          letter-spacing: 2px;

          line-height: 1;

          opacity: 0;

          transform:
            translateY(8px);

          transition:
            opacity 0.35s ease,
            transform 0.35s ease;

          pointer-events: none;

          text-shadow:
            0 2px 10px
            rgba(
              0,
              0,
              0,
              0.45
            );
        }

        .portfolio-photo:hover
        .portfolio-photo-index {
          opacity: 1;

          transform:
            translateY(0);
        }

        /*
        ============================================================
        TABLET
        ============================================================
        */

        @media (max-width: 900px) {

          .portfolio-gallery {
            grid-template-columns:
              repeat(
                2,
                minmax(0, 1fr)
              );
          }

          .portfolio-category-header {
            padding-left: 20px;
            padding-right: 20px;
          }

        }

        /*
        ============================================================
        MOBILE
        ============================================================
        */

        @media (max-width: 600px) {

          .portfolio-category-header {
            padding-top: 100px;
            padding-bottom: 22px;
          }

          /*
            Keep your ORIGINAL display font.
          */

          .portfolio-category-header-inner {
            align-items: flex-start;

            flex-direction: column;

            gap: 18px;
          }

          .portfolio-gallery {
            grid-template-columns: 1fr;
          }

          .portfolio-photo-index {
            opacity: 1;
          }

        }

        /*
        ============================================================
        REDUCED MOTION
        ============================================================
        */

        @media (
          prefers-reduced-motion: reduce
        ) {

          .portfolio-photo {
            opacity: 1;

            transform: none;

            transition: none;
          }

          .portfolio-photo
          .editorial-image img {
            transition: none;
          }

          .portfolio-category-back {
            transition: none;
          }

        }

      `}),t.jsx("header",{className:"portfolio-category-header",children:t.jsxs("div",{className:"portfolio-category-header-inner",children:[t.jsx(w,{to:"/portfolio",className:"portfolio-category-back",children:"← Work"}),t.jsx("h1",{className:"display",style:{fontSize:"clamp(3rem, 6vw, 5.5rem)",margin:"10px 0 0 0",textTransform:"capitalize",lineHeight:"1.1"},children:s})]})}),r===null&&t.jsx("div",{style:{padding:"60px 20px 120px"},children:t.jsx(E,{label:"Loading gallery…"})}),r&&r.length===0&&t.jsx("div",{style:{padding:"20px 20px 120px"},children:t.jsx(N,{title:"No photographs published yet.",body:"This gallery is being updated — check back soon."})}),r&&r.length>0&&t.jsx("div",{className:"portfolio-gallery",children:y.map((o,e)=>t.jsx("div",{className:"portfolio-gallery-column",children:o.map(b)},e))})]})}export{k as default};
